library(testthat)
library(palab)

test_check("palab", reporter ="summary")
