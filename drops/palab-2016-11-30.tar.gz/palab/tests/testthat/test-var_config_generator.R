context("Generating the var_config information")

library(readr)

# Reading in all of the required input dataframes and output summaries
custom_inputs <- suppressMessages(
  read_csv("var_config_generator_custom_inputs.csv")
)

custom_output <- suppressMessages(
  read_csv("var_config_generator_custom_outputs.csv")
)

q_ims_inputs <- suppressMessages(read_csv("mtcars.csv"))
q_ims_output <- suppressMessages(read_csv("var_config_generated.csv"))

test_that("Customs inputs result in custom summary", {
  generated_custom_output <- get_output_df(custom_inputs)
  expect_equal(generated_custom_output, custom_output)
})

test_that("Q-IMS inputs results in generated output", {
  generated_q_ims_output <- get_output_df(q_ims_inputs)
  expect_equal(generated_q_ims_output, q_ims_output)
})

test_that("The main function is writing to a file", {
  generated_output <- var_config_generator(
    input_csv = "mtcars.csv",
    output = "test")
  expect_equal(generated_output, q_ims_output)
})

unlink("test.csv")
