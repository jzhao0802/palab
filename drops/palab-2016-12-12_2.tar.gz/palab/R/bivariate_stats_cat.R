#' Bivariate Statistics for categorical outcomes
#'
#' This function will produce a summary of how each variable varies with a
#' categorical outcome variable. This will help the user to flag associations
#' between the independent variables and outcome variable that may not be
#' compatible with the subsequent modelling approach. The user can choose to
#' not include some of the input variables in the analysis by prefixing those
#' column names with "o_"
#'
#' @param input A dataframe of the transformed output from
#' \code{\link{read_transform}}
#' Any variable columns starting with "o_" will not be included in the analysis
#' @param var_config A summary dataframe describing the input types. The
#' function \code{var_config_generator} provides a template for this, which
#' needs to be checked by the user before use
#' @param outcome A character string of the outcome, or dependent, variable
#' @param output A character string that will provide the prefix to the output
#' files of the 2 returned dataframe summaries.
#' @param output_dir A character string of the path to the directory where the
#' output file is to be saved. The separator for the directories must be "/",
#' and not "\\" that is common on the Windows operating system
#' Default is current directory
#' @param count An integer value that states the maximum number of unique values
#' of the outcome variable without a warning being raised
#' @return A list with the 2 summary dataframes:
#' \describe{
#'   \item{cat}{The summary for the categorical variables}
#'   \item{num}{The summary for the numerical variables}
#' }
#' @examples
#' \dontrun{
#' bivariate_stats_cat(input = transformed_df, var_config = var_config_df,
#'                     outcome = "vs", output = "mt_cars", output_dir = "data",
#'                     count = 5)
#' }
#' @export bivariate_stats_cat
bivariate_stats_cat <- function(input, var_config, outcome, output = "",
                                output_dir = ".", count = 5) {

  # Performing some checks of the inputs
  if (missing(input) || !is.data.frame(input)) {
    stop("A dataframe is required for the 'input'argument")
  }

  if (missing(var_config) || !is.data.frame(var_config)) {
    stop("A dataframe is required for the 'var_config'argument")
  }

  if (missing(outcome)) {
    stop("A character string value must be given for the 'outcome' argument")
  }

  if (!is.character(outcome) || length(outcome) != 1) {
    stop("'outcome' argument must be a character string")
  }

  if (!is.character(output) || length(output) != 1) {
    stop("'output' argument must be a character string")
  }

  if (!is.character(output_dir) || length(output_dir) != 1) {
    stop("'output_dir' argument must be a character string of the save path")
  }

  if (!is.numeric(count) || count %% 1 != 0 || length(count) != 1) {
    stop("'count' argument must be a numeric whole number")
  }

  # Removing any possible factor columns from the input dataframes
  # Using a function from a different file
  input <- df_remove_factors(input)
  var_config <- df_remove_factors(var_config)

  # Removing any unwanted columns that have been prefixed with 'o_'
  input <- input %>%
    dplyr::select_(~-starts_with("o_"))

  # Throwing an error if the outcome is not in the dataframe
  if (!(outcome %in% colnames(input))) {
    wrong_outcome_message <- sprintf(
      "'%s' is not a variable in the input data", outcome
    )
    stop(wrong_outcome_message)
  }

  # Raising a warning if the outcome var has too many levels
  # Function from different file
  check_level_count(input, outcome, count, "lt")

  ## First completing the summary for the categorical variables

  # Next function from 'get_categorical_or_numerical_variables.R' file
  # Getting the subset of variables that are categorical
  input_categorical <- get_categorical_variables(input, var_config)

  # Checking that the outcome variable is included - and raising a warning
  # if it isn't, because it should be classed as a categorical variable
  if (!(outcome %in% colnames(input_categorical))) {
    outcome_warning_categorical <- sprintf(
      "The outcome variable '%s' is not classified as a categorical variable",
      outcome
    )
    input_categorical <- dplyr::bind_cols(input_categorical, input[outcome])
    warning(outcome_warning_categorical)
  }

  # Getting the categorical summary
  cat_summary <- get_bivariate_cat_cat_summary(
    input_categorical = input_categorical,
    outcome = outcome
  )

  ## Now doing the summary for the numerical variable

  # Get numerical varibles and add on the outcome varible column
  # If this add on DOES NOT have to be done, then a warning will be raised as
  # the outcome variable SHOULD NOT feature in the numerical variables
  input_numerical <- get_numerical_variables(
    input = input,
    var_config = var_config
  )

  if (!(outcome %in% colnames(input_numerical))) {
    input_numerical <- dplyr::bind_cols(input_numerical,
                                        input[outcome])
  }

  # Getting the numerical summary
  num_summary <- get_bivariate_cat_num_summary(
    input_numerical = input_numerical,
    outcome = outcome
  )

  # Checking the directories and file names and then saving

  # Checking that the directory doesn't end in '/'
  output_dir <- file.path(output_dir)

  # Checking if the output_dir exists, and making it if it doesn't
  if (!dir.exists(output_dir)) {
    dir.create(output_dir)
  }

  # Checking that the output file doesn't end in ".csv"
  if (tools::file_ext(output) == "csv") {
    output <- tools::file_path_sans_ext(output)
  }

  # Adding the suffices to the end of the files
  cat_cat_file <- file.path(
    output_dir,
    paste0(output, "bivar_stats_y_cat_x_cat.csv")
  )

  cat_num_file <- file.path(
    output_dir,
    paste0(output, "bivar_stats_y_cat_x_num.csv")
  )

  # Writing the outputs to the files
  readr::write_csv(cat_summary, cat_cat_file)
  readr::write_csv(num_summary, cat_num_file)


  list(cat = cat_summary, num = num_summary)
}

#' Get the bivariate summary for the y-cat, x-cat information
#'
#' This function returns the bivariate statistics and information for the
#' categorical variables when the outcome variable is also a categorical
#' variable
#'
#' @param input_categorical A dataframe of the information from the categorical
#' variables - the output from \code{get_categorical_variables}
#' @param outcome A character string of the variable that is to be used as the
#' outcome variable
#' @return A dataframe containing the count and proportion information for the
#' different levels of the categorical variables, at all of the different levels
#' of the outcome variable
#'
get_bivariate_cat_cat_summary <- function(input_categorical, outcome) {
  # Getting the order of the columns to keep continuous after reshaping
  variable_order <- colnames(input_categorical)

  # Getting the gathered summary data for the cat output
  cat_gathered_summary <- get_gathered_summary_df(
    input = input_categorical,
    outcome = outcome
  )

  # Using the gathered summary to get the categorical summary information
  # The count summary:
  cat_cat_count_summary <- get_level_count_information(
    summary_input = cat_gathered_summary,
    outcome = outcome
  )

  # Getting the level proportion summary
  cat_cat_level_proportion_summary <- get_proportion_information(
    summary_input = cat_gathered_summary,
    outcome = outcome,
    divisor_column = "Total_outcome_level",
    prefix = "Proportion of Level_"
  )

  # Getting the outcome proportion summary
  cat_cat_outcome_proportion_summary <- get_proportion_information(
    summary_input = cat_gathered_summary,
    outcome = outcome,
    divisor_column = "Total_variable_level",
    prefix = "Proportion of Outcome_"
  )

  # In the following procedures, the first 2 columns feature in all of the
  # outputs so far, so these have to be removed to prevent duplication when
  # the outputs are combined together
  repeated_column_index <- which(
    colnames(cat_cat_count_summary) %in% c("Categorical variable", "Level")
  )

  # Combining these dataframes together
  combined_cat_summary <- dplyr::bind_cols(
    cat_cat_count_summary,
    cat_cat_level_proportion_summary[-repeated_column_index],
    cat_cat_outcome_proportion_summary[-repeated_column_index]
  )

  # Getting the Categorical variable column back as a character datatype
  combined_cat_summary <- combined_cat_summary %>%
    dplyr::mutate_(`Categorical variable` =
                     ~as.character(`Categorical variable`))

  # 'Zipping' together the output columns into the correct order
  variable_level_columns <-
    colnames(cat_cat_count_summary)[repeated_column_index]

  count_columns <-
    colnames(cat_cat_count_summary)[-repeated_column_index]

  level_prop_columns <-
    colnames(cat_cat_level_proportion_summary)[-repeated_column_index]

  outcome_prop_columns <-
    colnames(cat_cat_outcome_proportion_summary)[-repeated_column_index]

  cat_zipped_columns <- c(rbind(count_columns,
                                level_prop_columns,
                                outcome_prop_columns))
  cat_correct_columns <- c(variable_level_columns, cat_zipped_columns)

  cat_summary_correct_order <- combined_cat_summary[cat_correct_columns]

  cat_summary_correct_order
}

#' Get the bivariate summary for the y-cat, x-num information
#'
#' This function gets the required summaries of the numerical variables
#' for the different levels of the outcome varible. Importantly, the input to
#' this function must contain the outcome variable, which SHOULD be a
#' categorical variable. A warning will have been raised if this is not the
#' case, as in those cases, \code{bivariate_stats_num} should be used
#'
#' @param input_numerical A dataframe containing the values for the numerical
#' variables, plus the information on the outcome variable, which should be
#' categorical and has therefore been added beforehand without a warning
#' @param outcome A character string of the name of the outcome variable
#' @return A dataframe with the complete y-cat, x-num summary information
#'
get_bivariate_cat_num_summary <- function(input_numerical, outcome) {

  # Getting the number of observations as this is needed for the calculations
  n_obs <- nrow(input_numerical)

  # Getting the index of the outcome variable for the gathering function
  outcome_index <- which(colnames(input_numerical) == outcome)

  # Gathering the information around the outcome variable, and setting these
  # variable to be ordered factors so that the correct order is kept
  gathered_input_numerical <- input_numerical %>%
    tidyr::gather_(key_col = "Variable",
            value_col = "Value",
            gather_cols = colnames(input_numerical)[-outcome_index]) %>%
    dplyr::mutate_(Variable = ~factor(Variable, levels = unique(Variable)))

  # Calculating all the required summary statistics in one operation
  all_stats_df <- gathered_input_numerical %>%
    dplyr::group_by_(.dots = c(outcome, "Variable")) %>%
    dplyr::summarise_(NonMissing = ~sum(!is.na(Value)),
                      NonMissingPrp = ~round((NonMissing / n_obs), digits = 2),
                      Missing = ~sum(is.na(Value)),
                      MissingPrp = ~round((Missing/ n_obs), digits = 2),
                      `Mean outcome` = ~mean(Value, na.rm = TRUE),
                      SD = ~sd(Value, na.rm = TRUE),
                      Min = ~min(Value, na.rm = TRUE),
                      P1 = ~stats::quantile(Value, 0.01, na.rm = TRUE),
                      P5 = ~stats::quantile(Value, 0.05, na.rm = TRUE),
                      P10 = ~stats::quantile(Value, 0.1, na.rm = TRUE),
                      P25 = ~stats::quantile(Value, 0.25, na.rm = TRUE),
                      P_50 = ~stats::quantile(Value, 0.5, na.rm = TRUE),
                      P_75 = ~stats::quantile(Value, 0.75, na.rm = TRUE),
                      P_90 = ~stats::quantile(Value, 0.9, na.rm = TRUE),
                      P_95 = ~stats::quantile(Value, 0.95, na.rm = TRUE),
                      P_99 = ~stats::quantile(Value, 0.99, na.rm = TRUE),
                      Max = ~max(Value, na.rm = TRUE))

  # Gathering these data to incorporate level information into the columns
  all_stats_df_gathered <- all_stats_df %>%
    tidyr::gather_(key_col = "Aggregation",
                   value_col = "Aggregation_value",
                   gather_cols = colnames(all_stats_df)[-c(1, 2)]) %>%
    dplyr::arrange_(outcome)

  # Uniting the Aggregation and outcome information to get the column names
  all_stats_df_gathered_correct_names <- all_stats_df_gathered %>%
    tidyr::unite_(col = "temp",
                  from = c("Aggregation", outcome)) %>%
    dplyr::mutate_(temp = ~factor(temp, levels = unique(temp)))

  # Finally spreading this dataframe out into the columns and converting
  # the Variable column back to a character datatype
  bivariate_cat_num_summary <- all_stats_df_gathered_correct_names %>%
    tidyr::spread_(key_col = "temp",
                   value_col = "Aggregation_value") %>%
    dplyr::mutate_(Variable = ~as.character(Variable))

  bivariate_cat_num_summary
}


#' Prepare the input varibles for making the cat summary
#'
#' This function reshapes the input data to get it ready for creating the
#' cat summary. This just provides the count summary and does not calculate
#' any proportions. Those will occur in a later function
#'
#' @param input The information on the categorical subset of the original data
#' @param outcome The variable that will be used as the outcome variable
#' @return A dataframe with the following columns:
#' \describe{
#'   \item{Categorical variable}{The names of all the input variables}
#'   \item{outcome_var}{The values of the outcome variable from the data}
#'   \item{Total_outcome_level}{The number of times the outcome variable has
#'   of each of its levels}
#'   \item{Level}{The values of the different variable levels}
#'   \item{Count}{The number of times each input varible level appears at the
#'   different levels of the outcome variable}
#'   \item{Total_variable_level}{The number of times each outcome variable level
#'   appears at the different levels of each of the input variables}
#' }
#'
get_gathered_summary_df <- function(input, outcome) {

  # Getting the index of where the outcome variable is in the column names
  # And checking that there is only 1 of these columns
  outcome_index <- which(colnames(input) == outcome)

  # Gathering the inputs around the outcome variable
  gathered_input <- input %>%
    tidyr::gather_(key_col = "Categorical variable",
                   value_col = "Level",
                   gather_cols = colnames(input)[-outcome_index]) %>%
    dplyr::mutate_(`Categorical variable` =
                     ~factor(`Categorical variable`,
                             levels = unique(`Categorical variable`)))

  # Getting the total number of each outcome level for the variables
  total_outcome_level_df <- gathered_input %>%
    dplyr::group_by_(.dots = c("`Categorical variable`", outcome)) %>%
    dplyr::summarise_(Total_outcome_level = ~n()) %>%
    dplyr::ungroup()

  # Getting the total number of different levels of the non-outcome variables
  total_variable_level_df <- gathered_input %>%
    dplyr::group_by_(.dots = c("`Categorical variable`", "Level")) %>%
    dplyr::summarise_(Total_variable_level = ~n()) %>%
    dplyr::ungroup() %>%
    stats::na.omit()

  # Getting the number of non-outcome variable levels for each level of
  # outcome the outcome variable
  variable_outcome_count_df <- gathered_input %>%
    dplyr::group_by_(.dots = c("`Categorical variable`", "Level", outcome)) %>%
    dplyr::summarise_(Count = ~n()) %>%
    dplyr::ungroup()

  # Joining all of this information together. This takes 3 stages that make
  # the joins on different criteria
  variable_outcome_count_total_outcome_level_df <- dplyr::inner_join(
    total_outcome_level_df,
    variable_outcome_count_df,
    by = c("Categorical variable", outcome)
  )

  variable_outcome_count_df_total_variable_level_df <- dplyr::inner_join(
    total_variable_level_df,
    variable_outcome_count_df,
    by = c("Categorical variable", "Level")
  )

  variable_outcome_summary <- dplyr::inner_join(
    variable_outcome_count_total_outcome_level_df,
    variable_outcome_count_df_total_variable_level_df,
    by = c("Categorical variable", outcome, "Level", "Count")
  )

  # Returning this summary
  variable_outcome_summary
}

#' Get all the counts of variables at the different levels of the outcome
#'
#' This function provides the summaries of the counts for the different levels
#' of all the variables that appear at each level of the outcome, or dependent
#' variable.
#'
#' @param summary_input A dataframe of the gathered information on the
#' categorical variables that was created by \code{get_gathered_summary_df}
#' @param outcome The column name in \code{summary_input} that represents the
#' outcome variable
#' @param prefix A character string of the prefix that will be given to the
#' column names in the summary output. Default "Count_"
#' @return A dataframe with the count summary of the categorical variables
#' for every level of the outcome variable
#'
get_level_count_information <- function(summary_input, outcome,
                                        prefix = "Count_") {

  # Selecting the correct columns
  count_input <- summary_input %>%
    dplyr::mutate_(count_column = ~paste0(prefix, .[[outcome]])) %>%
    dplyr::select_(.dots = c("`Categorical variable`",
                             "Level",
                             "count_column",
                             "Count"))

  # Spreading this output
  count_spread <- count_input %>%
    tidyr::spread_(key_col = "count_column",
                   value_col = "Count",
                   fill = 0)

  count_spread
}

#' Get the proportion summary of variables at each level of the outcome variable
#'
#' This function is very similar to \code{get_level_count_information}. Returns
#' either the proportion of the outcome variable at each level of the input
#' variables: \eqn{P(outcome = Y | variable = X)} or the proportion of the
#' input variable levels at each level of the outcome varible:
#' \eqn{P(variable = X | outcome = Y)}, depending on the divisor column that
#' is entered
#'
#' @param summary_input A dataframe of the gathered information on the
#' categorical variables that was created by \code{get_gathered_summary_df}
#' @param outcome The column name in \code{summary_input} that represents the
#' outcome variable
#' @param divisor_column A character string of which column to divide the
#' variable counts by. Use \code{"Total_outcome_level"} to get
#' \eqn{P(outcome = Y | variable = X)} or use \code{"Total_variable_level"} to
#' get \eqn{P(variable = X | outcome = Y)}
#' @param prefix A character string of the prefix that will be given to the
#' column names in the summary output
#' @return A dataframe with the relevant proporion summaries
#'
get_proportion_information <- function(summary_input, outcome,
                                             divisor_column, prefix) {

  # Creating the proportion level value and adding the prefix to the outcome
  # then selecting the required columns
  prop_df <- summary_input %>%
    dplyr::mutate_(prop_column = ~paste0(prefix, .[[outcome]])) %>%
    dplyr::mutate_(Prop_level = ~round((Count / .[[divisor_column]]),
                                       digits = 2)) %>%
    dplyr::select_(.dots = c("`Categorical variable`",
                             "Level",
                             "prop_column",
                             "Prop_level"))

  # Spreading this output
  prop_spread <- prop_df %>%
    tidyr::spread_(key_col = "prop_column",
                   value_col = "Prop_level",
                   fill = 0)

  prop_spread
}
