#' Keeping only the categorical variables
#'
#' This function keeps only the categorical variables from the \code{var_config}
#' dataframe which also feature in the \code{input} dataframe
#'
#' @param input A dataframe of the transformed output from \code{read_transform}
#' @param var_config A summary dataframe describing the input types. The
#' function \code{var_config_generator} provides a template for this, which
#' needs to be checked by the user before use
#' @return A subset of \code{input} with only the categorical inputs
#'
get_categorical_variables <- function(input, var_config) {

  # Keeping only those variables in var_config that are in input and
  # are categorical
  var_config_categorical <- var_config %>%
    dplyr::filter_(~Column %in% colnames(input)) %>%
    dplyr::filter_(~tolower(Type) == "categorical")

  # Keeping only these variables from the input and returning the dataframe
  output <- input %>%
    dplyr::select_(.dots = var_config_categorical$Column)

  output
}

#' Keeping only the numerical variables
#'
#' This function keeps only the numerical variables from the \code{var_config}
#' dataframe which also feature in the \code{input} dataframe
#'
#' @param input A dataframe of the transformed output from \code{read_transform}
#' @param var_config A summary dataframe describing the input types. The
#' function \code{var_config_generator} provides a template for this, which
#' needs to be checked by the user before use
#' @return A subset of \code{input} with only the numerical inputs
#'
get_numerical_variables <- function(input, var_config) {

  # Keeping only those variables in var_config that are in input and
  # are numerical
  var_config_numerical <- var_config %>%
    dplyr::filter_(~Column %in% colnames(input)) %>%
    dplyr::filter_(~tolower(Type) == "numerical")

  # Keeping only these variables from the input and returning the dataframe
  output <- input %>%
    dplyr::select_(.dots = var_config_numerical$Column)

  output
}

#' Keeping only the key variable
#'
#' This function keeps only the key variable from the \code{var_config}
#' dataframe which also feature in the \code{input} dataframe
#'
#' @param input A dataframe of the transformed output from \code{read_transform}
#' @param var_config A summary dataframe describing the input types. The
#' function \code{var_config_generator} provides a template for this, which
#' needs to be checked by the user before use
#' @return A subset of \code{input} with only the key variable inputs
#'
get_key_variable <- function(input, var_config) {

  # Keeping only the variable in var_config that is in the input columns
  # and is a key variable
  var_config_key <- var_config %>%
    dplyr::filter_(~Column %in% colnames(input)) %>%
    dplyr::filter_(~tolower(Type) == 'key')

  output <- input %>%
    dplyr::select_(.dots = var_config_key$Column)

  output
}
