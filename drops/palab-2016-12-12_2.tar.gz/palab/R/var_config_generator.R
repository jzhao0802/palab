#' Read and parse data types from input .csv file
#'
#' This function will read in the data from a .csv file, and classify the
#' inputs as either 'numerical', 'categorical', or 'other'. The output will
#' still require a manual check, and one of the inputs must be manually
#' defined as the 'key' variable. The saved file will contain the following
#' columns:
#' \describe{
#'   \item{Column}{Same as the column headers from the input file}
#'   \item{Type}{One of the three categories listed above}
#'   \item{NumUniqueValues}{The number of unique values in each column from
#'   the input file}
#' }
#' @param input_csv The path and name of the .csv file containing the data.
#' The first line of this file must contain the column names, and there must
#' not be any row names present
#' @param output The name given to the output .csv file
#' @param output_dir The path to the directory where the output file is saved.
#' This must be written using "/" to separate the directories, and not "\\" as
#' is practice on the Windows operating system.
#' @param sample_rows An integer value representing how many lines of data
#' should be read in from the file for parsing. Default 1000
#' @importFrom dplyr %>%
#' @return NULL
#' @examples
#' \dontrun{
#' var_config_generator(input_csv = "mtcars.csv",
#'   output = "var_config_template.csv", output_dir = "data")
#' }
#' @export var_config_generator
#'
var_config_generator <- function(input_csv, output = "",
                                 output_dir = ".", sample_rows = 1000) {

  # Checking that an input file is present
  if (missing(input_csv)) {
    stop("You need to enter a value for the 'input_csv' file")
  }

  if (!is.character(input_csv) || length(input_csv) != 1) {
    stop("'input_csv' argument must be a charater string")
  }

  if (!is.character(output) || length(output) != 1) {
    stop("'output' argument must be a character string")
  }

  if (!is.character(output_dir) || length(output_dir) != 1) {
    stop("'output_dir' argument must be a character string of the save path")
  }

  if (!is.numeric(sample_rows) || sample_rows %% 1 != 0 ||
      length(sample_rows) != 1) {
    stop("'sample_rows' argument must be a numeric whole number")
  }

  # Reading in the data silently
  input_df <- suppressMessages(readr::read_csv(input_csv,
                                               guess_max = sample_rows))

  # Getting the summary information from the helper function
  output_df <- get_output_df(input_df)

  # Checking the output_dir and output and then saving
  output_dir <- file.path(output_dir)

  # Checking that the output dir exists and making it if not
  if (!dir.exists(output_dir)) {
    dir.create(output_dir)
  }

  if (tools::file_ext(output) == "csv") {
    output_body <- tools::file_path_sans_ext(output)
    output <- paste0(output_body, "varconfig.csv")
  } else {
    output <- paste0(output, "varconfig.csv")
  }

  # Saving the information to the file
  save_name <- file.path(output_dir, output)
  readr::write_csv(output_df, save_name)

  output_df
}

#' Getting summary output from the input dataframe
#'
#' This function gets the required output from the input dataframe, and returns
#' the summary output information. This is done for testing purposes
#'
#' @param input_df A dataframe containing the input information
#' @return The summary information as a tibble data_frame
#'
get_output_df <- function(input_df) {
  # Getting the number of unique entries for each column
  # and reshaping the dataframe to output format
  gather_columns <- colnames(input_df)
  output_df <- input_df %>%
    dplyr::summarise_all(n_distinct) %>%
    tidyr::gather_(key_col = "Column",
                   value_col = "NumUniqueValues",
                   gather_cols = gather_columns)


  # Getting the R column datatypes
  column_dtypes <- vapply(input_df, function(x) class(x)[1], "")

  # Adapting these datatypes to the required datatypes
  ims_dtypes <- ifelse(column_dtypes %in% c("integer", "numeric"), "numerical",
                       ifelse(column_dtypes == "character", "categorical",
                              "other"))
  output_df$Type <- ims_dtypes
  output_df <- output_df[c("Column", "Type", "NumUniqueValues")]

  output_df
}

utils::globalVariables("n_distinct")
