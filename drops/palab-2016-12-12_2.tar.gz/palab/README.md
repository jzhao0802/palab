# palabs
This is the QuintilesIMS project package