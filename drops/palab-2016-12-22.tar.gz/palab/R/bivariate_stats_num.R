#' Bivariate Statistics for numerical outcomes
#'
#' This function calculates the bivariate summaries when the outcome variable
#' is a numerical variable. This returns the information on the correlation
#' scores and decile information between the numerical variables and the outcome
#' variable, together with the summary statistics of the outcome variable for
#' the different levels of the categorical variables. For the categorical
#' variables, it will also provide a level of 'relative risk' by taking the
#' ratio of the mean values of the outcome variable at the different levels of
#' the categorical input varibles, using the lowest values of the categorical
#' inputs as the 'baseline'
#'
#' @param input A dataframe of the transformed output from \code{read_transform}
#' @param var_config_csv A summary dataframe describing the input types. The
#' function \code{\link{var_config_generator}} provides a template for this,
#' which needs to be checked by the user before use. The first column
#' must have the header \code{Column} and the second must have \code{Type}
#' @param outcome A character string with the name of the outcome variable. An
#' error will be thrown if this does not feature in \code{input}. This
#' variable should also be referred to as a 'numerical' in
#' \code{var_config_csv}; a warning will be given if this is not the case
#' @param output A character string of the prefix that will be given to the
#' file where the outputs will be saved.
#' @param output_dir A character string of the path to the directory where the
#' output file is to be saved. The separator for the directories must be "/",
#' and not "\\" that is common on the Windows operating system
#' Default is current directory
#' @param count An integer value that states the maximum number of unique values
#' of the outcome variable without a warning being raised
#' @param correlation_warning Boolean. States if a warning about the Spearman
#' correlation p-values is to be given or not. Default TRUE
#' @return A list of 3 dataframes containing the bivariate summary statistics:
#' \describe{
#'   \item{num}{The summary statistics with the numerical input variables}
#'   \item{cat}{The summary statistics with the categorical input variables}
#'   \item{rr}{The relative risk statistics from the categorical variables}
#' }
#' @examples
#' \dontrun{
#' bivariate_stats_num(input = transformed_df, var_config_csv = var_config_csv,
#'                     outcome = "mpg", output = "mt_cars", output_dir = "data",
#'                     count = 5, correlation_warning = TRUE)
#' }
#' @export bivariate_stats_num
#'
bivariate_stats_num <- function(input, var_config_csv, outcome, output = "",
                                output_dir = ".", count = 5,
                                correlation_warning = TRUE) {

  # Performing some checks of the inputs
  if (missing(input) || !is.data.frame(input)) {
    stop("A dataframe is required for the 'input'argument")
  }

  if (missing(var_config_csv) || !is.character(var_config_csv) ||
      length(var_config_csv) != 1) {
    stop("'var_config_csv' must be a character string input")
  }

  if (!file.exists(var_config_csv)) {
    var_config_file_error <- sprintf(
      "No 'var_config_csv' file found at '%s'", var_config_csv
    )
    stop(var_config_file_error)
  }

  if (missing(outcome)) {
    stop("A character string value must be given for the 'outcome' argument")
  }

  if (!is.character(outcome) || length(outcome) != 1) {
    stop("'outcome' argument must be a character string")
  }

  if (!is.character(output) || length(output) != 1) {
    stop("'output' argument must be a character string")
  }

  if (!is.character(output_dir) || length(output_dir) != 1) {
    stop("'output_dir' argument must be a character string of the save path")
  }

  if (!is.numeric(count) || count %% 1 != 0 || length(count) != 1) {
    stop("'count' argument must be a numeric whole number")
  }

  # Loading in the var_config dataframe and checking column names
  var_config <- suppressMessages(readr::read_csv(var_config_csv))
  if (!all(colnames(var_config) %in% c("Column", "Type"))) {
    stop(
    "The column names for the var_config dataframe must be 'Column' and 'Type'"
  )
  }
  # Removing any possible factor columns from the input dataframes
  # Using a function from a different file
  input <- df_remove_factors(input)
  var_config <- df_remove_factors(var_config)

  # Throwing an error if the outcome is not in the dataframe
  if (!(outcome %in% colnames(input))) {
    wrong_outcome_message <- sprintf(
      "'%s' is not a variable in the input data", outcome
    )
    stop(wrong_outcome_message)
  }

  # Raising a warning if the outcome var has too many levels
  # Function from different file
  check_level_count(input, outcome, count, "gt")

  ## First completing the summary for the numerical variables

  # Next function from 'get_categorical_or_numerical_variables.R' file
  # Getting the subset of variables that are categorical
  input_numerical <- get_numerical_variables(input, var_config)

  # Raising a warning if the outcome variable is in the categorical dataset
  # as it should be a numerical variable
  # Adding the column of the outcome variable if it is not
  if (!(outcome %in% colnames(input_numerical))) {
    output_warning_numerical <- sprintf(
      "The outcome variable '%s' is not classified as a numerical variable",
      outcome
    )
    warning(output_warning_numerical)
    input_numerical <- dplyr::bind_cols(input_numerical,
                                        input[outcome])
  }

  # Getting the correlation summaries
  num_correlations <- get_numerical_correlation_information(
    input = input_numerical,
    outcome = outcome,
    give_warning = correlation_warning
  )

  # Getting the decile summaries
  num_deciles <- get_mean_decile_information(
    input = input_numerical,
    outcome = outcome
  )

  # Merging these together to get the numerical summary
  num_summary <- dplyr::inner_join(
    num_correlations,
    num_deciles,
    by = "Variable name"
  )

  ## Now doing the categorical summary
  input_categorical <- get_categorical_variables(input, var_config)

  # Checking to see if this has the outcome variable. It SHOULD NOT, but a
  # warning will already have been given if this is the case
  if (!(outcome %in% colnames(input_categorical))) {
    input_categorical <- dplyr::bind_cols(input_categorical,
                                          input[outcome])
  }

  cat_summary <- get_bivariate_num_cat_summary(
    input = input_categorical,
    outcome = outcome
  )

  # Getting the relative risk summary, using the same dataframe as above
  relative_risk_summary <- get_relative_risk_summary(
    input = input_categorical,
    outcome = outcome
  )

  # Checking the output variables before saving to a file
  # Checking that the directory doesn't end in "/"
  output_dir <- file.path(output_dir)

  # Checking if the output_dir exists, and making it if it doesn't
  if (!dir.exists(output_dir)) {
    dir.create(output_dir)
  }

  # Checking that the output file doesn't end in ".csv"

  if (tools::file_ext(output) == "csv") {
    output <- tools::file_path_sans_ext(output)
  }

  # Adding the suffixes to the ends of the files
  num_num_file <- file.path(
    output_dir,
    paste0(output, "bivar_stats_y_num_x_num.csv")
  )

  num_cat_file <- file.path(
    output_dir,
    paste0(output, "bivar_stats_y_num_x_cat.csv")
  )

  relative_risk_file <- file.path(
    output_dir,
    paste0(output, "RR_stats_y_num_x_cat.csv")
  )

  # Writing the outputs to the files
  readr::write_csv(num_summary, num_num_file)
  readr::write_csv(cat_summary, num_cat_file)
  readr::write_csv(relative_risk_summary, relative_risk_file)

  list(num = num_summary, cat = cat_summary, rr = relative_risk_summary)
}



#' Get the Pearson and Spearman correlation stats from the numerical variables
#'
#' This function calculates the correlation information using both Pearson's
#' and Spearman's correlation coefficients of the relationship between the
#' numerical input variables and the outcome variable. Of note, the results
#' from the Spearman calculations can result in a warning about non-exact
#' p-values if there are any ties in the rankings of the input variables. By
#' default, these warnings are maintained, but they can be supressed if desired
#'
#' @param input A dataframe of the numerical subset of the original data
#' @param outcome A character string of the outcome variable
#' @param give_warning Boolean. States if a warning about the Spearman
#' correlations is to be given or not. Default TRUE
#' @return A dataframe with the correlation input information
#'
get_numerical_correlation_information <- function(input, outcome,
                                                  give_warning = TRUE) {

  # Getting the gathered input information
  input_gathered <- get_bivariate_gathered_num_num(input, outcome)

  # Getting the information on the Pearson's correlation and p-value
  # This makes use of the broom package to get the cor.test output into
  # a dataframe, which allows for use wihing dplyr
  input_pearson <- input_gathered %>%
    dplyr::group_by_("`Variable name`") %>%
    dplyr::do_(~broom::tidy(stats::cor.test(
      .[[outcome]],
      .$Value,
      method = "pearson"))[c("estimate", "p.value")]) %>%
    dplyr::ungroup()

  # Getting the correct rounding to desired decimal places
  input_pearson_rounded <- input_pearson %>%
    dplyr::mutate_(estimate = ~round(estimate, digits = 2),
                   p.value = ~round(p.value, digits = 5))

  # Remaining the columns correctly
  pearson_summary <- input_pearson_rounded %>%
    dplyr::rename_("Pearson's correlation coefficient" = "estimate",
                   "P-value of Pearson's correlation coefficient" = "p.value")

  # Now getting the information on the Spearman's correlations
  if (give_warning) {
    input_spearman <- input_gathered %>%
      dplyr::group_by_("`Variable name`") %>%
      dplyr::do_(~broom::tidy(stats::cor.test(
        .[[outcome]],
        .$Value,
        method = "spearman"))[c("estimate", "p.value")]) %>%
      dplyr::ungroup()
  } else {
    suppressWarnings(
    input_spearman <- input_gathered %>%
      dplyr::group_by_("`Variable name`") %>%
      dplyr::do_(~broom::tidy(stats::cor.test(
        .[[outcome]],
        .$Value,
        method = "spearman"))[c("estimate", "p.value")]) %>%
      dplyr::ungroup()
    )
  }


  # Getting the correct number of decimal places
  input_spearman_rounded <- input_spearman %>%
    dplyr::mutate_(estimate = ~round(estimate, digits = 2),
                   p.value = ~round(p.value, digits = 5))

  # Renaming these columns correctly
  spearman_summary <- input_spearman_rounded %>%
    dplyr::rename_("Spearman's correlation coefficient" = "estimate",
                   "P-value of Spearman's correlation coefficient" = "p.value")

  # Joining these two together, and then getting the variable column back to
  # being a character datatype
  correlation_summary <- pearson_summary %>%
    dplyr::inner_join(spearman_summary, by = "Variable name") %>%
    dplyr::mutate_(`Variable name` = ~as.character(`Variable name`))

  correlation_summary
}

#' Get the outcome means per decile summary
#'
#' This function gets the mean values of the outcome for the different decile
#' groupings of the numerical input variables
#'
#' @param input A dataframe of the numerical subset of the original data
#' @param outcome A character string of the outcome variable
#' @return A dataframe with the decile information of the outcome variable
#'
get_mean_decile_information <- function(input, outcome) {

  # Getting the gathered information
  input_gathered <- get_bivariate_gathered_num_num(input, outcome)

  # Setting the probability vector used to calculate the break points for
  # the binning of the input variables into the quantiles/deciles
  decile_breaks <- seq(from = 0, to = 1, by = 0.1)

  # Binning the different input values into their relevant quantiles. Of note,
  # the quantile calculation is right-FALSE, meaning that the results give a
  # left-open/right-closed interval. Also, the include.lowest value is set to
  # TRUE. As this is now right-FALSE, this refers to the highest value of a set
  # which with therefore assigned to the last quantile (10th decile in this
  # case). For more information, read more from ?stats::quantile
  dots <- list(~.bincode(Value, stats::quantile(Value, decile_breaks,
                                                na.rm = TRUE),
                         right = FALSE, include.lowest = TRUE))
  input_quantile_binned <- input_gathered %>%
    dplyr::group_by_("`Variable name`") %>%
    dplyr::mutate_(.dots = setNames(dots, c("quants"))) %>%
    dplyr::ungroup()

  # Getting the mean values of the outcome variable for each decile of the
  # input variables. This also has to make use of the interp function from the
  # lazyeval package, as the variable to summarise on is a character string
  means_per_decile <- input_quantile_binned %>%
    dplyr::group_by_(.dots = c("`Variable name`", "quants")) %>%
    dplyr::summarise_(dmeans = lazyeval::interp(~mean(var),
                                                var = as.name(outcome))) %>%
    dplyr::ungroup()

  # Doing the rounding to 2 decimal places
  means_per_decile_rounded <- means_per_decile %>%
    dplyr::mutate_(dmeans = ~round(dmeans, digits = 2))

    # Spreading these data out into wide format, and then renaming the columns
    spread_means_per_decile <- means_per_decile_rounded %>%
      dplyr::select_(.dots = c("`Variable name`", "dmeans", "quants")) %>%
      tidyr::spread_(key_col = "quants",
                     value_col = "dmeans")

    spread_means_per_decile_correct_columns <- spread_means_per_decile %>%
      dplyr::rename_("Mean outcome in 1st decile" = "`1`",
                     "Mean outcome in 2nd decile" = "`2`",
                     "Mean outcome in 3rd decile" = "`3`",
                     "Mean outcome in 4th decile" = "`4`",
                     "Mean outcome in 5th decile" = "`5`",
                     "Mean outcome in 6th decile" = "`6`",
                     "Mean outcome in 7th decile" = "`7`",
                     "Mean outcome in 8th decile" = "`8`",
                     "Mean outcome in 9th decile" = "`9`",
                     "Mean outcome in 10th decile" = "`10`")

    # Getting the variable name column back as a character datatype
    decile_means_summary <- spread_means_per_decile_correct_columns %>%
      dplyr::mutate_(`Variable name` = ~as.character(`Variable name`))

    decile_means_summary
}

#' Get the gathered information for the Bivariate num/num stats
#'
#' This function returns the gathered information for the numerical variables
#' around the outcome variable. It is a separate function as it is used multiple
#' times by other functions in this file
#'
#' @param input A dataframe of the numerical subset of the original data
#' @param outcome A character string of the outcome variable name
#' @return A dataframe of the gathered information. A key difference is that
#' the column containing the names of the input numerical variables now has
#' factor datatypes. This is to aid with the ordering of the outcome after the
#' summary stats have been calculated
#'
get_bivariate_gathered_num_num <- function(input, outcome) {
  # Getting the index of the outcome variable for the gathering function
  outcome_index <- which(colnames(input) == outcome)

  # Gathering this information around the outcome variable and removing NAs
  # Also, the column holding the variables is converted to being an ordered
  # factor datatype so that the correct order is preserved
  input_gathered <- input %>%
    tidyr::gather_(key_col = "Variable name",
                   value_col = "Value",
                   gather_cols = colnames(input)[-outcome_index]) %>%
    dplyr::mutate_(`Variable name` = ~factor(
      `Variable name`,
      levels = unique(`Variable name`)
    )) %>%
    stats::na.omit()

  input_gathered
}

#' Get the bivariate summary statistics for the y-num, x-cat variables
#'
#' This function calculates all of the bivariate statistics for the y-cat/x-num
#' output. One thing to check is that the input dataframe contains the
#' information for the outcome variable. This should have been added in
#' advance because the outcome variable should be numerical and the input
#' variables are numerical. A warning will have been raised if this is not the
#' case
#'
#' @param input A dataframe of the categorical subset of the original data, but
#' with the addition of the information of the outcome variable, which should
#' be numerical
#' @param outcome A character string of the outcome variable to use
#' @return A dataframe of the numerical summaries of the outcome variable for
#' the categorical variables
#'
get_bivariate_num_cat_summary <- function(input, outcome) {

  # Double checking that the outcome is in the input dataframe
  if (!(outcome %in% colnames(input))) {
    stop(
  "The outcome variable has not been included with the categorical information"
  )
  }

  # Gathering the input around the outcome variable and setting the categorical
  # variable column to be an ordered factor to preserve the ordering
  # This uses a helper function, as this information is also required for the
  # relative risk calculations
  gathered_input <- get_bivariate_gathered_num_cat(input, outcome)

  # Getting all of the summaries in one operation
  all_num_cat_stats <- gathered_input %>%
    dplyr::group_by_(.dots = c("`Categorical variable`", "Level")) %>%
    dplyr::summarise_(
      `Mean outcome` = lazyeval::interp(~mean(var, na.rm = TRUE),
                                        var = as.name(outcome)),
      `SD outcome` = lazyeval::interp(~sd(var, na.rm = TRUE),
                                      var = as.name(outcome)),
      `Minimum outcome` = lazyeval::interp(~min(var, na.rm = TRUE),
                                           var = as.name(outcome)),
      `1st percentile outcome` =
        lazyeval::interp(~stats::quantile(var, 0.01, na.rm = TRUE),
                         var = as.name(outcome)),
      `5th percentile outcome` =
        lazyeval::interp(~stats::quantile(var, 0.05, na.rm = TRUE),
                         var = as.name(outcome)),
      `10th percentile outcome` =
        lazyeval::interp(~stats::quantile(var, 0.1, na.rm = TRUE),
                         var = as.name(outcome)),
      `25th percentile outcome` =
        lazyeval::interp(~stats::quantile(var, 0.25, na.rm = TRUE),
                         var = as.name(outcome)),
      `50th percentile outcome` =
        lazyeval::interp(~stats::quantile(var, 0.5, na.rm = TRUE),
                         var = as.name(outcome)),
      `75th percentile outcome` =
        lazyeval::interp(~stats::quantile(var, 0.75, na.rm = TRUE),
                         var = as.name(outcome)),
      `90th percentile outcome` =
        lazyeval::interp(~stats::quantile(var, 0.9, na.rm = TRUE),
                         var = as.name(outcome)),
      `95th percentile outcome` =
        lazyeval::interp(~stats::quantile(var, 0.95, na.rm = TRUE),
                         var = as.name(outcome)),
      `99th percentile outcome` =
        lazyeval::interp(~stats::quantile(var, 0.99, na.rm = TRUE),
                         var = as.name(outcome)),
      `Maximum outcome` = lazyeval::interp(~max(var, na.rm = TRUE),
                                       var = as.name(outcome))
    ) %>%
    dplyr::ungroup()

  # Getting the categorical variable column back to character datatype
  num_cat_summary <- all_num_cat_stats %>%
    dplyr::mutate_(`Categorical variable` =
                     ~as.character(`Categorical variable`))

  num_cat_summary
}

#' Get the Relative Risk summaries for the categorical variables
#'
#' This function calculates the Relative Risks of the means of the outcome
#' variable for the different levels of the input categorical variables.
#' The outcome mean for the lowest value of the categorical variables is
#' always assumed to be the 'baseline' value that the RRs are calculated from
#'
#' @param input A dataframe of the categorical subset of the original data, but
#' with the addition of the information of the outcome variable, which should
#' be numerical
#' @param outcome A character string of the outcome variable to use
#' @return A dataframe with the Relative Risk information
#'
get_relative_risk_summary <- function(input, outcome) {

  # Getting the gathered information
  gathered_input <- get_bivariate_gathered_num_cat(input, outcome)

  # Getting the information on all of the means. Also, the ordering is vital
  # here so that the baseline for the relative risk is calculated correctly
  # It is then arranged using the Categorical Variable (which is an ordered
  # factor) and the Level information
  all_means <- gathered_input %>%
    dplyr::group_by_(.dots = c("`Categorical variable`", "Level")) %>%
    dplyr::summarise_(outcome_mean = lazyeval::interp(
      ~mean(var, na.rm = TRUE), var = as.name(outcome))) %>%
    dplyr::arrange_(.dots = c("`Categorical variable`", "Level")) %>%
    dplyr::ungroup()

  # Getting the 'baseline' means, which are now represented by the first
  # row of the categorical variables, as this represents the lowest levels
  baseline_means <- all_means %>%
    dplyr::group_by_("`Categorical variable`") %>%
    dplyr::filter_(~row_number() == 1) %>%
    dplyr::ungroup()

  # This now has to be joined back to all the original data with a left join
  # The missing values that are introduced also have to be filled in downward
  all_means_with_baseline <- all_means %>%
    dplyr::left_join(baseline_means,
                     by = c("Categorical variable", "Level"),
                     suffix = c("_original", "_baseline")) %>%
    tidyr::fill_("outcome_mean_baseline")

  # Now getting the relative risks by dividing the original with the baseline
  relative_risk_summary <- all_means_with_baseline %>%
    dplyr::mutate_(
      `Relative Risk` = ~outcome_mean_original / outcome_mean_baseline
    ) %>%
    dplyr::select_(.dots = c("`Categorical variable`",
                             "Level",
                             "`Relative Risk`"))

  # Getting the categorical variable back to being a character datatype
  relative_risk_summary <- relative_risk_summary %>%
    dplyr::mutate_(`Categorical variable` =
                     ~as.character(`Categorical variable`))

  relative_risk_summary
}

#' Get the gathered information for the Bivariate num/cat stats
#'
#' This function returns the gathered information for the categorical variables
#' around the outcome variable. It is a separate function as it is used multiple
#' times by other functions in this file
#'
#' @param input A dataframe of the categorical subset of the original data,
#' which also has the information of the outcome variable
#' @param outcome A character string of the outcome variable name
#' @return A dataframe of the gathered information. A key difference is that
#' the column containing the names of the input numerical variables now has
#' factor datatypes. This is to aid with the ordering of the outcome after the
#' summary stats have been calculated
#'
get_bivariate_gathered_num_cat <- function(input, outcome) {

  # Getting the index of the outcome variable for the gathering function
  outcome_index <- which(colnames(input) == outcome)

  # Gathering the input around the outcome variable and setting the categorical
  # variable column to be an ordered factor to preserve the ordering
  gathered_input <- input %>%
    tidyr::gather_(key_col = "Categorical variable",
                   value_col = "Level",
                   gather_cols = colnames(input)[-outcome_index]) %>%
    dplyr::mutate_(`Categorical variable` = ~factor(
      `Categorical variable`, levels = unique(`Categorical variable`)
    )) %>%
    stats::na.omit()

  gathered_input
}

utils::globalVariables("setNames")
