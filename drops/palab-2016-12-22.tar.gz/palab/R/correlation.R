#' Get the correlation information between all of the input variables
#'
#' This function will read in the dummified information, that was the output
#' from \code{\link{dummy_vars}}. All of the inputs should therefore be
#' numeric datatypes, and an error will be thrown if this is not the case.
#'
#' @param input A dataframe with numeric variables and coded dummy variables
#' from the categorical variables. This will have been the output from
#' \code{\link{dummy_vars}}
#' @param method Default \code{spearman}. A character string of the following
#' values:
#' \describe{
#'   \item{spearman}{States that a Spearman correlation should be performed}
#'   \item{pearson}{States that a Pearson correlation should be performed}
#' }
#' @param output A character string that provides the prefix for the all of the
#' output files
#' @param output_dir A character string of the path to the directory where the
#' output file is to be saved. The separator for the directories must be "/",
#' and not "\\" that is common on the Windows operating system
#' Default is current directory
#' @param correlation_warning Boolean. States if a warnings that can occur
#' during the correlation calculations should be hidden or not
#' @return A dataframe of the correlation summary containing the following
#' columns:
#' \describe{
#'   \item{Variable1}{The name of variable 1}
#'   \item{Variable2}{The name of variable 2}
#'   \item{Correlation}{The unadjusted correlation coefficient}
#'   \item{AbsCorrelation}{The absolute value of the unadjusted correlation
#'   coefficient}
#'   \item{P-Value}{The p-value of the correlation coefficient}
#'   \item{FDR_BH_P-Value}{The p-value after a Benjamini-Hochberg FDR
#'   multiple comparison correction}
#'   \item{FDR_BHY_P-Value}{The p-value after a Benjamini-Hochberg-Yekutieli FDR
#'   multiple comparison correction}
#'   \item{Bonferroni_P-Value}{The p-value after a Bonferroni multiple
#'   comparison correction}
#' }
#' @param output_csv A boolean to indicate if the outputs should be written
#' to the output file. Default FALSE
#' @export correlation
#'
correlation <- function(input, method = "spearman", output = "",
                        output_dir = ".", correlation_warning = TRUE,
                        output_csv = FALSE) {
# Performing some checks on the inputs
  if (missing(input) || !is.data.frame(input)) {
    stop("A dataframe is required for the 'input'argument")
  }

  # Checking that method is either 'spearman' or 'pearson'
  if (!(method %in% c("spearman", "pearson"))) {
    stop("The 'method' argument must be either 'spearman' or 'pearson'")
  }

  if (!is.character(output) || length(output) != 1) {
    stop("'output' argument must be a character string")
  }

  if (!is.character(output_dir) || length(output_dir) != 1) {
    stop("'output_dir' argument must be a character string of the save path")
  }

  if (!is.logical(output_csv) || length(output_csv) != 1 || is.na(output_csv)) {
    stop("'output_csv' argument must be a single value of TRUE or FALSE")
  }

  # Check the data types are numeric, or change them if they can be changed
  input <- non_numeric_check(input)

  # Getting all of the pairwise combinations of the columns names, without
  # any duplications of pairings
  pairwise_combinations <- utils::combn(colnames(input), 2, simplify = FALSE)

  # Getting the basic, unordered correlation information
  correlation_df <- dplyr::bind_rows(
    lapply(pairwise_combinations, get_correlation_correlation_information,
           df = input, cor_method = method,
           correlation_warning = correlation_warning)
  )

  # Ordering by descending AbsCorrelation and then adding the additional
  # information
  dots <- list(~stats::p.adjust(`P-Value`, method = "BH"),
               ~stats::p.adjust(`P-Value`, method = "BY"),
               ~stats::p.adjust(`P-Value`, method = "bonferroni"))
  correlation_df <- correlation_df %>%
    dplyr::arrange_(~desc(AbsCorrelation)) %>%
    dplyr::mutate_(.dots = setNames(dots, c("FDR_BH_P-Value",
                                            "FDR_BHY_P-Value",
                                            "Bonferroni_P-Value")))


  # Writing all the information to the output files if required
  if (output_csv) {
    output_dir <- file.path(output_dir)

    # Checking if the output_dir exists, and making it if it doesn't
    if (!dir.exists(output_dir)) {
      dir.create(output_dir, recursive = TRUE)
    }

    if (tools::file_ext(output) == "csv") {
      output <- tools::file_path_sans_ext(output)
    }

    correlation_output <- paste0(output, "correlation.csv")
    correlation_path <- file.path(output_dir, correlation_output)

    readr::write_csv(correlation_df, correlation_path)
  }

  correlation_df

}

#' Check for non numeric inputs
#'
#' This function simply throws an error if any columns in a dataframe do not
#' contain numeric information, or data that can be coerced to numerics without
#' any NAs being made. If thrown, the error message will also contain the names
#' of the columns to aid in debugging
#'
#' @param input A dataframe
#' @return An error if any columns contain non-numeric information or a
#' dataframe that is either the same as the input, or has any columns that can
#' be coerced to numerics, as numerics
#'
non_numeric_check <- function(input) {
  # Checking that all of the inputs are either numeric inputs, or can be
  # converted to numeric inputs
  non_numerics <- suppressWarnings(
    vapply(input, function(x) {!all(is.na(as.numeric(x)))}, TRUE)
  )
  non_numerics_index <- which(!non_numerics)

  if (length(non_numerics_index) > 0) {
    non_numeric_vars <- colnames(input)[non_numerics_index]
    non_numeric_var_string <- paste(
      paste0("'", non_numeric_vars, "'"),
      collapse = ", "
    )
    non_numeric_error <- sprintf(
      "Column(s): %s contain non-numeric information", non_numeric_var_string
    )
    stop(non_numeric_error)
  }

  # Coercing to numerics if needed
  dtype_non_numeric <- vapply(input, is.numeric, TRUE)
  change_index <- which(!dtype_non_numeric)

  input[change_index] <- dplyr::as_data_frame(
    lapply(input[change_index], as.numeric)
  )

  input
}

#' Get all base correlations for the pairwise combinations of variables
#'
#' This functions gets the "base" information for the correlations. This means
#' that only the initial p-values are calculated, with no adjustments made for
#' multiple comparisons. These further calculations are made in the main
#' function. It only deals with a single pair of variables and therefore only
#' returns a dataframe with a single row of information, and is called in the
#' main function via 'lapply'
#'
#' @param variable_pair A character vector consisting of 2 elements which are 2
#' of the variables in the input dataframe
#' @param df The dataframe containing all of the dummified numeric variables
#' @param cor_method A character string. Either 'pearson' or 'spearman'
#' @param correlation_warning Boolean. As the correlation calculations can
#' sometimes produce various warnings, this determines if these are shown to the
#' user or not
#'
get_correlation_correlation_information <- function(variable_pair, df,
                                                    cor_method,
                                                    correlation_warning) {

  # Make sure that the variable_pair are in the data frame columns
  if (!(all(variable_pair %in% colnames(df)))) {
    wrong_vars <- paste0("'", variable_pair, "'")
    wrong_var_string <- paste(wrong_vars, collapse = ", ")
    wrong_var_message <- sprintf(
      "One or both of %s are not in the dataframe columns", wrong_var_string
    )
    stop(wrong_var_message)
  }

  # Isolating only the pair of variables in question
  variable_pair_df <- dplyr::data_frame(
    Variable1 = variable_pair[1],
    Variable2 = variable_pair[2]
  )

  correlation_df <- df %>%
    dplyr::select_(.dots = variable_pair)

  if (correlation_warning) {
    correlation_df <- correlation_df %>%
      dplyr::do_(~broom::tidy(stats::cor.test(
        .[[variable_pair[1]]],
        .[[variable_pair[2]]],
         method = cor_method))[c("estimate", "p.value")])
  } else {
    suppressWarnings(
      correlation_df <- correlation_df %>%
        dplyr::do_(~broom::tidy(stats::cor.test(
          .[[variable_pair[1]]],
          .[[variable_pair[2]]],
          method = cor_method))[c("estimate", "p.value")])
    )
  }

    correlation_df <- correlation_df %>%
      dplyr::rename_(
        Correlation = ~estimate,
        `P-Value` = ~p.value
      ) %>%
      dplyr::mutate_(AbsCorrelation = ~abs(Correlation)) %>%

      # Getting the columns into the desired order
      dplyr::select_(.dots = c("Correlation",
                               "AbsCorrelation",
                               "`P-Value`"))

  # Combining this with the variable pair information
  variables_with_correlations <- dplyr::bind_cols(
    variable_pair_df,
    correlation_df
  )

  variables_with_correlations
}























