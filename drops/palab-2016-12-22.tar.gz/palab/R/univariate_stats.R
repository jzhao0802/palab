#' Perform univariate descriptive statistics
#'
#' This function will produce a summary of each variable in the input dataset.
#' It will help the user understand the data better and spot any issues with
#' the variables
#'
#' @param input A dataframe of the transformed output from
#' \code{\link{read_transform}}
#' @param var_config_csv A summary dataframe describing the input types. The
#' function \code{\link{var_config_generator}} provides a template for this,
#' which needs to be checked by the user before use. The first column
#' must have the header \code{Column} and the second must have \code{Type}
#' @param output A character string that will provide the prefix to the output
#' files of the 3 returned dataframe summaries and the problem summary if any of
#' the variables are completely missing or only contain 1 unique value
#' @param output_dir A character string of the path to the directory where the
#' output file is to be saved. The separator for the directories must be "/",
#' and not "\\" that is common on the Windows operating system
#' Default is current directory
#' @return A list of 4 dataframes containing the desired univariate stats
#' \describe{
#'   \item{cat}{The summary dataframe of the categorical variables}
#'   \item{melted}{The full frequency table with all levels for all variables}
#'   \item{numerical}{The summary dataframe of the numerical variables}
#'   \item{problems}{A summary of 'problem' variables: those that are either
#'   100% missing, or only contain 1 unique value. If this is not empty, then
#'   it will be written to a file with the same name as \code{output}, but with
#'   the suffix 'problems.csv'}
#' }
#' @examples
#' \dontrun{
#' univariate_stats(input = transformed_df, var_config_csv = var_config_csv,
#'                  output = "univar_summary", output_dir = "data")
#' }
#' @export univariate_stats
#'
univariate_stats <- function(input, var_config_csv, output = "",
                             output_dir = '.') {

  # Checking the inputs
  if (missing(input) || !is.data.frame(input)) {
    stop("A dataframe is required for the 'input' argument")
  }

  if (missing(var_config_csv) || !is.character(var_config_csv) ||
      length(var_config_csv) != 1) {
    stop("'var_config_csv' must be a character string input")
  }

  if (!file.exists(var_config_csv)) {
    var_config_file_error <- sprintf(
      "No 'var_config_csv' file found at '%s'", var_config_csv
    )
    stop(var_config_file_error)
  }

  if (!is.character(output) || length(output) != 1) {
    stop("'output' argument must be a character string")
  }

  if (!is.character(output_dir) || length(output_dir) != 1) {
    stop("'output_dir' argument must be a character string of the save path")
  }

  # Loading in the var_config dataframe and checking column names
  var_config <- suppressMessages(readr::read_csv(var_config_csv))
  if (!all(colnames(var_config) %in% c("Column", "Type"))) {
    stop(
    "The column names for the var_config dataframe must be 'Column' and 'Type'"
  )
  }

  # Convert factors to character if they are present
  # This uses a function from a different file
  input <- df_remove_factors(input)
  var_config <- df_remove_factors(var_config)

  # Getting the problem report
  problem_report <- get_problem_summary(input)
  problem_df <- problem_report$report
  all_na_variables <- problem_report$all_na
  problem_variable_count <- length(all_na_variables)

  # Removing problem variables if there are any
  if (problem_variable_count > 0) {
    surviving_columns <- colnames(input)[!(colnames(input)
                                           %in% all_na_variables)]
    input <- input %>%
      dplyr::select_(.dots = surviving_columns)
    warning_message <- sprintf(
      "%d variable(s) have been removed due to all NA values",
      problem_variable_count
    )
    warning(warning_message)
  }

  # 2 next functions from: 'get_categorical_or_numerical_variables.R' file
  # Getting the subset of variables that are categorical
  input_categorical <- get_categorical_variables(input, var_config)

  # Getting the subset that is numerical
  input_numerical <- get_numerical_variables(input, var_config)

  # Getting the 2 summary dataframes from the categorical variables
  categorical_summaries <- create_categorical_summary(input_categorical)
  categorical_cat_output <- categorical_summaries$cat
  categorical_melted_output <- categorical_summaries$melted

  # Getting the numerical summary
  numerical_summary <- get_numerical_summary(input_numerical)



  # Checking the output variables before saving to a file

  # Checking that the directory doesn't end in "/"
  output_dir <- file.path(output_dir)

  # Checking if the output_dir exists, and making it if it doesn't
  if (!dir.exists(output_dir)) {
    dir.create(output_dir)
  }

  # Checking that the output file doesn't end in ".csv"

  if (tools::file_ext(output) == "csv") {
    output <- tools::file_path_sans_ext(output)
  }

  # Attaching the suffixes to the outputs and making the paths
  categorical_cat_output_file <- file.path(
    output_dir,
    paste0(output, "univar_stats_x_cat.csv")
  )
  categorical_melted_output_file <- file.path(
    output_dir,
    paste0(output, "univar_stats_x_cat_melted.csv")
  )
  numerical_summary_file <- file.path(
    output_dir,
    paste0(output, "univar_stats_x_cat.csv")
  )
  problem_df_file <- file.path(
    output_dir,
    paste0(output, "univar_stats_problems.csv")
  )

  # Writing all of these
  readr::write_csv(categorical_cat_output, categorical_cat_output_file)
  readr::write_csv(categorical_melted_output, categorical_melted_output_file)
  readr::write_csv(numerical_summary, numerical_summary_file)

  if (nrow(problem_df) > 0) {
    readr::write_csv(problem_df, problem_df_file)
    warning_message <- sprintf("Problem variables, see output in: %s",
                               problem_df_file)
    warning(warning_message)
  }

  # Returning all of the variables
  list(cat = categorical_cat_output,
       melted = categorical_melted_output,
       numerical = numerical_summary,
       problems = problem_df)
}

#' Get the cat and melted information for the categorical data
#'
#' This function makes use of 2 other helper functions that break up the
#' task into the information on the missing values with the unique level counts
#' and the summaries of the different values in the levels. These are then
#' combined to get the desired outputs
#'
#' @param input The information on the categorical subset of the original data
#' @return A list containing the 2 output dataframes
#' \describe{
#'   \item{cat}{The total information for the cat.csv file}
#'   \item{melted}{The total information for melted.csv file}
#' }
#'
create_categorical_summary <- function(input) {

  # Getting the information for the missing values and the counts of the
  # unique levels
  missing_and_level_count <- get_categorical_missing_info_and_level_number(
    input
  )

  # Getting the information for the summaries of the different levels
  # This process was done separately as it required more processing steps
  level_summary <- get_categorical_level_information(input)

  # Combining the cat information dataframes
  # and removing the Variable column from the levels dataframe
  missing_and_level_count_cat <- missing_and_level_count$cat
  level_summary_cat <- level_summary$cat
  level_summary_cat <- dplyr::select_(level_summary_cat, ~-Variable)
  categorical_output <- missing_and_level_count_cat %>%
    dplyr::bind_cols(level_summary_cat)

  # Combining the melted information dataframes
  # This has to be done with baseR "rbind" as dplyr cannot deal with
  # the different data types in the Level column
  missing_and_level_count_melted <- missing_and_level_count$melted
  level_summary_melted <- level_summary$melted

  melted_categorical_output <- rbind(missing_and_level_count_melted,
                                     level_summary_melted)

  list(cat = categorical_output, melted = melted_categorical_output)
}

#' Get information on missing values and the number of levels
#'
#' This function creates the information for the first 6 values needed in the
#' cat.csv output
#' @param input The information on the categorical subset of the original data
#' @return A list containing two dataframes.
#' \describe{
#'   \item{cat}{The information for the cat output}
#'   \item{melted}{The information for the melted output}
#' }
#'
get_categorical_missing_info_and_level_number <- function(input) {

  # Getting the order of the variables as this will be altered by dplyr
  order_df <- dplyr::data_frame(Variable = colnames(input))

  # Gathering the data in preparation for grouping operations
  input_gathered <- input %>%
    tidyr::gather_(key_col = "Variable",
                   value_col = "value",
                   gather_cols = colnames(input))

  # Getting the required inputs by grouping on the variable
  missing_and_level_info <- input_gathered %>%
    dplyr::group_by_("Variable") %>%
    dplyr::summarise_(
      `Non-missing, N` = ~sum(!is.na(value)),
      `Non-missing, prop` = ~`Non-missing, N` / n(),
      `Missing, N` = ~sum(is.na(value)),
      `Missing, prop` = ~`Missing, N` / n(),
      `Number of levels` = ~n_distinct(value, na.rm = TRUE)
    ) %>%
    dplyr::ungroup()

  # Getting the correct order of the variables
  missing_and_level_info_ordered <- dplyr::inner_join(order_df,
                                                      missing_and_level_info,
                                                      by = "Variable")

  # Using elements of this dataframe to make the start of the melted output
  melted_non_missing <- missing_and_level_info_ordered %>%
    dplyr::mutate_(Level = ~"non-missing",
                  Count = ~`Non-missing, N`,
                  Proportion = ~`Non-missing, prop`) %>%
    dplyr::select_(~Variable,
                  ~`Number of levels`,
                  ~Level,
                  ~Count,
                  ~Proportion)

  melted_missing <- missing_and_level_info_ordered %>%
    dplyr::mutate_(Level = ~"missing",
                  Count = ~`Missing, N`,
                  Proportion = ~`Missing, prop`) %>%
    dplyr::select_(~Variable,
                  ~`Number of levels`,
                  ~Level,
                  ~Count,
                  ~Proportion)

  # Combining these into the single dataframe
  missing_and_level_info_ordered_melted <- melted_non_missing %>%
    dplyr::bind_rows(melted_missing)

  # Returning both of these in a list

  list(cat = missing_and_level_info_ordered,
       melted = missing_and_level_info_ordered_melted)
}

#' Get the summary information of the levels of the categorical variables
#'
#' This function summarises the information on the different levels for
#' the categorical variables
#'
#' @param input The information on the categorical subset of the original data
#' @return A list containing two dataframes.
#' \describe{
#'   \item{cat}{The information for the cat output}
#'   \item{melted}{The information for the melted output}
#' }
get_categorical_level_information <- function(input) {

  # Getting the order of the variables as this will be altered by dplyr
  order_df <- dplyr::data_frame("Variable" = colnames(input))

  # Gathering and preparing all the input values required
  gather_columns <- colnames(input)
  summary_input <- input %>%
    tidyr::gather_(key_col = "Variable",
                   value_col = "value",
                   gather_cols = gather_columns) %>%
    dplyr::group_by_(.dots = c("Variable", "value")) %>%
    dplyr::summarise_(value_count = ~n()) %>%
    stats::na.omit() %>%
    dplyr::arrange_(.dots = c("Variable", "value")) %>%
    dplyr::mutate_(level_number = ~row_number()) %>%
    dplyr::ungroup() %>%
    dplyr::group_by_("Variable") %>%
    dplyr::mutate_(total_count = ~sum(value_count)) %>%
    dplyr::ungroup() %>%
    dplyr::mutate_(obs_prop_value = ~value_count / total_count,
           level_cnames = ~sprintf("Level%d value", level_number),
           obs_n_cnames = ~sprintf("Obs in level%d, N", level_number),
           obs_prop_cnames = ~sprintf("Obs in level%d, prop", level_number))

  # Spreading the information for the level values
  level_values <- summary_input %>%
    dplyr::select_(.dots = c("Variable", "value", "level_cnames")) %>%
    tidyr::spread_(key_col = "level_cnames",
                  value_col = "value")

  ## Of note, for the next summary, the fill value MUST be an integer, as this
  #  is count information and is needed to pass the unit tests

  # Spreading the information for the observation counts in levels
  observation_counts <- summary_input %>%
    dplyr::select_(.dots = c("Variable", "obs_n_cnames", "value_count")) %>%
    tidyr::spread_(key_col = "obs_n_cnames",
                   value_col = "value_count",
                   fill = as.integer(0))

  # Spreading the information on the observation proportions
  observation_proportion <- summary_input %>%
    dplyr::select_(.dots = c("Variable", "obs_prop_cnames",
                             "obs_prop_value")) %>%
    tidyr::spread_(key_col = "obs_prop_cnames",
                   value_col = "obs_prop_value",
                   fill = 0)

  # Getting the information on the column names into the correct order
  level_values_cnames <- colnames(level_values)[-1]
  observation_counts_cnames <- colnames(observation_counts)[-1]
  observation_proportion_cnames <- colnames(observation_proportion)[-1]
  assembled_names <- rbind(level_values_cnames,
                           observation_counts_cnames,
                           observation_proportion_cnames)
  correct_order_names <- c("Variable", assembled_names)

  # Combining the columns of these dataframes, only keeping the Variable
  # column in the first dataframe
  all_level_info_dataframe <- cbind(
    level_values,
    observation_counts[observation_counts_cnames],
    observation_proportion[observation_proportion_cnames]
  )

  # Getting the columns into the correct order
  all_level_info_dataframe <- all_level_info_dataframe[correct_order_names]

  # Getting the rows into the correct order
  level_info_df_ordered_cat <- dplyr::inner_join(order_df,
                                                 all_level_info_dataframe,
                                                 by = "Variable")

  # Using the summary_input to make the melted dataframe with additional
  # level count information
  input_summary_extra <- summary_input %>%
    dplyr::group_by_("Variable") %>%
    dplyr::mutate_(`Number of levels` = ~max(level_number)) %>%
    dplyr::ungroup()

  level_info_df_melted <- input_summary_extra %>%
    dplyr::mutate_(Level = ~value,
                   Count = ~value_count,
                   Proportion = ~obs_prop_value) %>%
    dplyr::select_(.dots = c("Variable", "`Number of levels`", "Level",
                   "Count", "Proportion"))

  # Getting this into order
  level_info_df_ordered_melted <- order_df %>%
    dplyr::inner_join(level_info_df_melted, by = "Variable")

  # Returning these 2 dataframes as a list
  list(cat = level_info_df_ordered_cat, melted = level_info_df_ordered_melted)
}

#' Get the summary information from the numerical variables
#'
#' This function will process the numerical inputs from the original data
#'
#' @param input A dataframe of the numerical subset of the original data
#' @return A dataframe of the required numerical summary information. Of note,
#' this MUST be a Base R data.frame, and not a data_frame used in the
#' tidyverse packages, as it contains duplicate column names
#'
get_numerical_summary <- function(input) {
  # Getting the order of the variables as this will be altered by dplyr
  order_df <- dplyr::data_frame("Variable" = colnames(input))

  # Getting all the unique summaries in one operation
  gather_columns <- colnames(input)
  numeric_summary <- input %>%
    tidyr::gather_(key_col = "Variable",
                   value_col = "value",
                   gather_cols = gather_columns) %>%
    dplyr::group_by_("Variable") %>%
    dplyr::summarise_(`Non-missing, N` = ~sum(!is.na(value)),
                      `Non-missing, prop` = ~`Non-missing, N` / n(),
                      `Missing, N` = ~sum(is.na(value)),
                      `Missing, prop` = ~`Missing, N` / n(),
                      Mean = ~mean(value, na.rm = TRUE),
                      `Standard deviation` = ~stats::sd(value, na.rm = TRUE),
                      Minimum = ~min(value, na.rm = TRUE),
                      P1 = ~stats::quantile(value, 0.01, na.rm = TRUE),
                      P5 = ~stats::quantile(value, 0.05, na.rm = TRUE),
                      P10 = ~stats::quantile(value, 0.1, na.rm = TRUE),
                      P25 = ~stats::quantile(value, 0.25, na.rm = TRUE),
                      P50 = ~stats::quantile(value, 0.5, na.rm = TRUE),
                      P75 = ~stats::quantile(value, 0.75, na.rm = TRUE),
                      P90 = ~stats::quantile(value, 0.9, na.rm = TRUE),
                      P95 = ~stats::quantile(value, 0.95, na.rm = TRUE),
                      P99 = ~stats::quantile(value, 0.99, na.rm = TRUE),
                      Max = ~max(value, na.rm = TRUE),
                      P20 = ~stats::quantile(value, 0.2, na.rm = TRUE),
                      P30 = ~stats::quantile(value, 0.3, na.rm = TRUE),
                      P40 = ~stats::quantile(value, 0.4, na.rm = TRUE),
                      P60 = ~stats::quantile(value, 0.6, na.rm = TRUE),
                      P70 = ~stats::quantile(value, 0.7, na.rm = TRUE),
                      P80 = ~stats::quantile(value, 0.8, na.rm = TRUE))


  # Getting the variables back into the original order
  numeric_summary_variable_order <- order_df %>%
    dplyr::inner_join(numeric_summary, by = "Variable")

  # The required output requires duplicated names for the columns, so it has
  # to be created with a BaseR data.frame, and not a tibble data_frame
  numeric_summary_variable_order_df <- as.data.frame(
    numeric_summary_variable_order, check.names = FALSE
  )

  column_name_order <- c(
    "Variable",
    "Non-missing, N",
    "Non-missing, prop",
    "Missing, N",
    "Missing, prop",
    "Mean",
    "Standard deviation",
    "Minimum",
    "P1",
    "P5",
    "P10",
    "P25",
    "P50",
    "P75",
    "P90",
    "P95",
    "P99",
    "Max",
    "P10",
    "P20",
    "P30",
    "P40",
    "P50",
    "P60",
    "P70",
    "P80",
    "P90"
  )

  numeric_summary_variable_and_column_order_df <-
    numeric_summary_variable_order_df[column_name_order]

  colnames(numeric_summary_variable_and_column_order_df) <- column_name_order

  numeric_summary_variable_and_column_order_df
}

#' Produce a summary of problem variables in the data
#'
#' This function calculates if any of the variables are either 100% missing
#' or contain only 1 unique value.
#'
#' @param input A dataframe of all the input variables
#' @return A dataframe with the columns \code{Variable} and \code{Problem}.
#' If there are no problem variables, then this will just be empty
#'
get_problem_summary <- function(input) {

    # Starting with a blank report data_frame
  report_df <- dplyr::data_frame(Variable = character(), Problem = character())

  # Getting information on columns that contain only missing information
  totally_missing <- vapply(input, function(x) all(is.na(x)), TRUE)
  missing_variables <- colnames(input)[totally_missing]

  if (any(totally_missing)) {
    missing_df <- dplyr::data_frame(Variable = missing_variables,
                                    Problem = "Variable is 100% missing")
    report_df <- dplyr::bind_rows(report_df, missing_df)
  }

  # Getting information on columns that only contain one value
  all_same_value <- vapply(
    input,
    function(x) length(unique(x)) == 1 & !all(is.na(x)),
    TRUE
  )


  if (any(all_same_value)) {
    all_same_variables <- colnames(input)[all_same_value]
    all_same_df <- dplyr::data_frame(
      Variable = all_same_variables,
      Problem = "Variable has only 1 unique value"
    )
    report_df <- dplyr::bind_rows(report_df, all_same_df)
  }

  list(report = report_df, all_na = missing_variables)
}
