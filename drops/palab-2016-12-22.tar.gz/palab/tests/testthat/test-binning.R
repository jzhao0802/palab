context("Binning the continuous/numerical variables")

library(readr)
suppressMessages(library(dplyr))

# Reading in the information required for the analysis
transformed_data <- suppressMessages(
  read_csv('transformed_data.csv')
)

# Testing the functions
test_that("An error occurs if binning_config_csv contains wrong variables", {
  expect_error(binning(
    transformed_data,
    "var_config.csv",
    "binning_config_wrong_variable.csv"
  ), "'llamas' values in binning_config_csv not in the numerical input data")
})

test_that("An error occurs if NumBins has any non-integers", {
  expect_error(binning(
    transformed_data,
    "var_config.csv",
    "binning_config_non_integer_numbin.csv"
  ), "'mpg' contain non-integer 'NumBin' information")
})

test_that("An error occurs if Method column contains values not 'q' or 'r'", {
  expect_error(binning(
    transformed_data,
    "var_config.csv",
    "binning_config_wrong_method.csv"
  ), "'mpg' contain non valid entries for 'Method'")
})

test_that("An error occurs if the CutPoints column contains single numerics", {
  expect_error(binning(
    transformed_data,
    "var_config.csv",
    "binning_config_numeric_cutpoints.csv"
  ),
  "Check that the values in the CutPoints column are comma separated numbers")
})

test_that("An error occurs if CutPoints contain non-numeric information", {
  expect_error(binning(
    transformed_data,
    "var_config.csv",
    "binning_config_non_numeric_cutpoint.csv"
  ), "'mpg', 'wt' contain non-numeric CutPoints information")
})

test_that("An error occurs if CutPoints for quantiles are not 0-1 values", {
  expect_error(binning(
    transformed_data,
    "var_config.csv",
    "binning_config_wrong_quantile_cutoff.csv"
  ), "'hp', 'drat' contain values not between 0 and 1 for quantile purposes")
})

test_that("An error occurs if ReplaceVal contains values not 'm' or 'o'", {
  expect_error(binning(
    transformed_data,
    "var_config.csv",
    "binning_config_wrong_replaceval.csv"
  ), "'mpg', 'drat' contain non-valid entries for 'ReplaceVal'")
})


test_that("Error if there is not exclusive entries for Numbins or CutPoints", {
  expect_error(binning(
    transformed_data,
    "var_config.csv",
    "binning_config_wrong_numbins_and_cutpoints.csv"
  ),
"'mpg', 'drat' do not contain an exclusive entry for 'NumBins' or 'CutPoints'")
})

test_that("An error occurs if the output argument is not a character string", {
  expect_error(binning(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    binning_config_csv = "binning_config.csv",
    output = TRUE
  ), "'output' argument must be a character string")
  expect_error(binning(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    binning_config_csv = "binning_config.csv",
    output = 99
  ), "'output' argument must be a character string")
  expect_error(binning(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    binning_config_csv = "binning_config.csv",
    output = c("Hello", "World")
  ), "'output' argument must be a character string")
})

test_that("An error occurs if the output_dir is not a character string of the save path", {
  expect_error(binning(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    binning_config_csv = "binning_config.csv",
    output_dir = TRUE
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(binning(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    binning_config_csv = "binning_config.csv",
    output_dir = 99
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(binning(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    binning_config_csv = "binning_config.csv",
    output_dir = c("Hello", "World")
  ), "'output_dir' argument must be a character string of the save path")
})

test_that("The output_csv argument is a single logical value", {
  expect_error(binning(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    binning_config_csv = "binning_config.csv",
    output_csv = "Monkeys"
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(binning(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    binning_config_csv = "binning_config.csv",
    output_csv = c(FALSE, TRUE)
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(binning(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    binning_config_csv = "binning_config.csv",
    output_csv = NULL
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(binning(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    binning_config_csv = "binning_config.csv",
    output_csv = NA
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
})
