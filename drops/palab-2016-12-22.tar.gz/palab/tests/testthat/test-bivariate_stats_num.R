context("Testing Bivariate Statistics for Numerical Variables")

library(readr)
suppressMessages(library(dplyr))

## Loading in the required data for the tests
transformed_data <- suppressMessages(
  read_csv("transformed_data.csv")
)

transformed_data_numerical <- suppressMessages(
  read_csv("transformed_data_numerical.csv")
)

transformed_data_categorical <- suppressMessages(
  read_csv("transformed_data_categorical.csv")
)

expected_numerical_summary <- suppressMessages(
  read_csv("bivar_stats_y_num_x_num_test_input.csv")
)

expected_correlation_outcome <- suppressMessages(
  read_csv("bivar_stats_y_num_x_num_correlation_information.csv")
)

expected_decile_outcome <- suppressMessages(
  read_csv("bivar_stats_y_num_x_num_decile_information.csv")
)

# The following input requires some manipulation to get the lines into the
# same order as the output. This is because the output in the provided
# example file is a strange order that would require custom ordering to
# recreate
expected_categorical_summary <- suppressMessages(
  read_csv("bivar_stats_y_num_x_cat_test_input.csv")
)

expected_categorical_summary <- expected_categorical_summary %>%
  mutate_(`Categorical variable` =
            ~factor(`Categorical variable`,
                    levels = unique(`Categorical variable`))) %>%
  arrange_(.dots = c("`Categorical variable`", "Level")) %>%
  mutate_(`Categorical variable` =
            ~as.character(`Categorical variable`))

# This also needs to be as a baseR dataframe as the tests were failing
# with tidyverse data_frames
expected_categorical_summary <- as.data.frame(
  expected_categorical_summary
)

expected_relative_risk_summary <- suppressMessages(
  read_csv("rr_stats_y_num_x_cat_test_input.csv")
)

# Converting this to a baseR dataframe
expected_relative_risk_summary <- as.data.frame(
  expected_relative_risk_summary
)

## Performing the tests

test_that("The numerical summary is as expected", {
  numerical_summary <- bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    correlation_warning = FALSE
  )$num
  expect_equal(numerical_summary, expected_numerical_summary,
               tolerance = 1e-2)
})

test_that("The categorical summary is as expected", {
  categorical_summary <- bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    correlation_warning = FALSE
  )$cat

  # Converting to a baseR dataframe
  categorical_summary <- as.data.frame(categorical_summary)
  expect_equal(categorical_summary, expected_categorical_summary,
               tolerance = 1e-2)
})

test_that("Relative Risk output is expected", {
  relative_risk_summary <- bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    correlation_warning = FALSE
  )$rr
  # Converting to a baseR dataframe
  relative_risk_summary <- as.data.frame(relative_risk_summary)

  # expect_equivalent is being used here due to the $spec attribute in the
  # data that was read in, and not present in the calculated dataframe
  expect_equivalent(relative_risk_summary, expected_relative_risk_summary)

})

# Testing the user entered arguments
test_that("An error occurs if the input argument is not a dataframe", {
  expect_error(bivariate_stats_num(
    var_config_csv = "var_config.csv",
    outcome = "mpg"
  ), "A dataframe is required for the 'input'argument")
  expect_error(bivariate_stats_num(
    input = "not a dataframe",
    var_config_csv = "var_config.csv",
    outcome = "mpg"
  ), "A dataframe is required for the 'input'argument")
})

test_that("An error occurs if no var_config_csv is given", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    outcome = "vs"
  ), "'var_config_csv' must be a character string input")
})

test_that("An error occurs if var_config is not a character string", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config_csv = 32,
    outcome = "vs"
  ), "'var_config_csv' must be a character string input")

  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config_csv = c("Not", "cool", "at", "all"),
    outcome = "vs"
  ), "'var_config_csv' must be a character string input")
})

test_that("An error occurs if the var_config_csv file doesn't exist", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config_csv = "not_here.csv",
    outcome = "vs"
  ), "No 'var_config_csv' file found at 'not_here.csv'")
})

test_that("An error occurs is no outcome argument is provided",{
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv"
  ), "A character string value must be given for the 'outcome' argument")
})

test_that("An error occurs is the outcome argument is not a character string", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = c("Hello", "World")
  ), "'outcome' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = NA
  ), "'outcome' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = NULL
  ), "'outcome' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = 999
  ), "'outcome' argument must be a character string")
})

test_that("An error occurs if the output argument is not a character string", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    output = c("Hello", "World")
  ), "'output' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    output = NA
  ), "'output' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    output = NULL
  ), "'output' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    output = 999
  ), "'output' argument must be a character string")
})

test_that("An error occurs if output_dir argument is not a character string", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    output_dir = c("Hello", "World")
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    output_dir = NA
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    output_dir = NULL
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    output_dir = 999
  ), "'output_dir' argument must be a character string of the save path")
})

test_that("An error occurs if the count argument is not a whole number",{
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    count = c(1, 12)
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    count = NA
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    count = NULL
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    count = 87.4
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    outcome = "mpg",
    count = "bananas"
  ), "'count' argument must be a numeric whole number")
})


test_that("An error occurs if the outcome variable is not in the data", {
  expect_error(
    bivariate_stats_num(
      input = transformed_data,
      var_config_csv = "var_config.csv",
      outcome = "Dinosaurs"
    ), "'Dinosaurs' is not a variable in the input data"
  )
})

test_that("A warning occurs if the outcome variable is not numerical", {
  expect_warning(
    bivariate_stats_num(
      input = transformed_data,
      var_config_csv = "var_config.csv",
      outcome = "vs"
    ), "The outcome variable 'vs' is not classified as a numerical variable"
  )
})

test_that("The outcome for the correlation information is correct", {
  correlation_outcome <- get_numerical_correlation_information(
    input = transformed_data_numerical,
    outcome = "mpg",
    give_warning = FALSE
  )
  expect_equal(correlation_outcome, expected_correlation_outcome)
})

test_that("The outcome for the decile summary information is correct", {
  decile_outcome <- get_mean_decile_information(
    input = transformed_data_numerical,
    outcome = "mpg"
  )
  expect_equal(decile_outcome, expected_decile_outcome)
})

test_that("Error raised if outcome not present with categorical inputs", {
  expect_error(
    get_bivariate_num_cat_summary(
      input = transformed_data_categorical,
      outcome = "mpg"
    ),
   "The outcome variable has not been included with the categorical information"
  )
})


unlink("bivar_stats_y_num_x_cat.csv")
unlink("bivar_stats_y_num_x_num.csv")
unlink("RR_stats_y_num_x_cat.csv")
