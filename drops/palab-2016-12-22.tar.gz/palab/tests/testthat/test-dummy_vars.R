context("Creating the dummy variables from the categorical variables")

library(readr)
suppressMessages(library(dplyr))

# Reading in data
transformed_data <- suppressMessages(
  read_csv("transformed_data.csv")
)

expected_dummy_output <- suppressMessages(
  read_csv("dummyfied_test_input.csv")
)

var_config_df <- suppressMessages(
  read_csv("var_config.csv")
)

var_config_df_one_column <- suppressMessages(
  read_csv("var_config_one_column.csv")
)

var_config_wrong_column_name <- suppressMessages(
  read_csv("var_config_wrong_Column_name.csv")
)

test_that("The dummy variable column names are made correctly", {
  factor_input <- data_frame(
    one = as.factor(c(2, 4, 1, 3)),
    two = as.factor(c("satsumas", "bananas", "apples", "mangoes"))
  )
  dummy_one <- c("one_2_1", "one_3_1", "one_4_1")
  dummy_two <- c("two_bananas_apples", "two_mangoes_apples",
                 "two_satsumas_apples")
  output_one <- get_dummy_names("one", factor_input)$var_values
  output_two <- get_dummy_names("two", factor_input)$var_values
  expect_equal(dummy_one, output_one)
  expect_equal(dummy_two, output_two)
})

test_that("An error occurs if the input argument is missing or incorrect", {
  expect_error(dummy_vars(
    var_config_csv = "var_config.csv"
  ), "A dataframe is required for the 'input'argument")
  expect_error(dummy_vars(
    input = c(NA, 99),
    var_config_csv = "var_config.csv"
  ), "A dataframe is required for the 'input'argument")
  expect_error(dummy_vars(
    input = "not a dataframe",
    var_config_csv = "var_config.csv"
  ), "A dataframe is required for the 'input'argument")
})

test_that("An error occurs if no var_config_csv is given", {
  expect_error(dummy_vars(
    input = transformed_data
  ), "'var_config_csv' must be a character string input")
})

test_that("An error occurs if var_config is not a character string", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = 32
  ), "'var_config_csv' must be a character string input")

  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = c("Not", "cool", "at", "all")
  ), "'var_config_csv' must be a character string input")
})

test_that("An error occurs if the var_config_csv file doesn't exist", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "not_here.csv"
  ), "No 'var_config_csv' file found at 'not_here.csv'")
})

test_that("An error is thrown if var_config does not have 2 columns", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config_one_column.csv"
  ), "'var_config' dataframe does not contain 2 columns")
})

test_that("An error is thrown if var_config has wrongly named columns", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config_wrong_Column_name.csv"
  ), "The column names for the var_config dataframe must be 'Column' and 'Type'")
})

test_that("An error occurs if the output argument is not a character string", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output = TRUE
  ), "'output' argument must be a character string")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output = 99
  ), "'output' argument must be a character string")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output = c("Hello", "World")
  ), "'output' argument must be a character string")
})

test_that("An error occurs if the output_dir is not a character string of the save path", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output_dir = TRUE
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output_dir = 99
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output_dir = c("Hello", "World")
  ), "'output_dir' argument must be a character string of the save path")
})

test_that("The name_desc argument is a single logical value", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    name_desc = "Monkeys"
  ), "'name_desc' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    name_desc = c(FALSE, TRUE)
  ), "'name_desc' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    name_desc = NULL
  ), "'name_desc' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    name_desc = NA
  ), "'name_desc' argument must be a single value of TRUE or FALSE")
})

test_that("The output_csv argument is a single logical value", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output_csv = "Monkeys"
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output_csv = c(FALSE, TRUE)
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output_csv = NULL
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output_csv = NA
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
})
