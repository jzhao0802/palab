context("Checking the extreme values function")

library(readr)
suppressMessages(library(dplyr))

## Loading in the required information
transformed_data <- suppressMessages(
  read_csv("transformed_data.csv")
)

ex_val_thrsh <- suppressMessages(
  read_csv("ex_val_thrsh_test_input.csv")
)

ex_val_thrsh_wrong_columns <- suppressMessages(
  read_csv("ex_val_thrsh_test_input_wrong_columns.csv")
)

ex_val_thrsh_wrong_rows <- suppressMessages(
  read_csv("ex_val_thrsh_test_input_wrong_rows.csv")
)

ex_val_thrsh_wrong_column_names <- suppressMessages(
  read_csv("ex_val_thrsh_test_input_wrong_column_names.csv")
)

ex_val_thrsh_wrong_variables <- suppressMessages(
  read_csv("ex_val_thrsh_test_input_wrong_variables.csv")
)

expected_transformed_output_with_ex_val_thrsh <- suppressMessages(
  read_csv("ex_mtcars.csv", col_types = "cninnnnniiii")
)

expected_transformed_output_without_ex_val_thrsh <- suppressMessages(
  read_csv("ex_mtcars_no_ex_val_thrsh.csv", col_types = "cninnnnniiii")
)

# Converting these to a base data.frame
expected_transformed_output_with_ex_val_thrsh <-
  as.data.frame(expected_transformed_output_with_ex_val_thrsh)

expected_transformed_output_without_ex_val_thrsh <-
  as.data.frame(expected_transformed_output_without_ex_val_thrsh)

expected_ex_val_thrsh_out <- suppressMessages(
  read_csv("ex_val_thrsh_out_test_input.csv")
)


## Doing the tests

test_that("The transformed output for mtcars with ex_val_thrsh is correct", {
  transformed_output_list <- extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = "extreme_test",
    output_csv = TRUE
  )

  transformed_output <- transformed_output_list$data
  ex_val_output <- transformed_output_list$report

  # Converting the data data_frame to a base data.frame
  transformed_output <- as.data.frame(transformed_output)

  expect_equivalent(transformed_output,
               expected_transformed_output_with_ex_val_thrsh)
  expect_equal(ex_val_output, expected_ex_val_thrsh_out)
})

test_that("The transformed output for mtcars with no ex_val_thrsh is correct", {
  transformed_output_list <- extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    output = "extreme_test_no_ex_val_thrsh",
    output_csv = TRUE
  )

  transformed_output <- transformed_output_list$data

  # Converting the data data_frame to a base data.frame
  transformed_output <- as.data.frame(transformed_output)

  expect_equivalent(transformed_output,
                    expected_transformed_output_without_ex_val_thrsh)
})

test_that("An error occurs if the input argument is missing or incorrect", {
  expect_error(extreme_values(
    var_config_csv = "var_config.csv",
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = "extreme_test"
  ), "A dataframe is required for the 'input'argument")
  expect_error(extreme_values(
    input = c(NA, 99),
    var_config_csv = "var_config.csv",
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = "extreme_test"
  ), "A dataframe is required for the 'input'argument")
  expect_error(extreme_values(
    input = "not a dataframe",
    var_config_csv = "var_config.csv",
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = "extreme_test"
  ), "A dataframe is required for the 'input'argument")
})

test_that("An error occurs if no var_config_csv is given", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    outcome = "vs"
  ), "'var_config_csv' must be a character string input")
})

test_that("An error occurs if var_config is not a character string", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config_csv = 32,
    outcome = "vs"
  ), "'var_config_csv' must be a character string input")

  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config_csv = c("Not", "cool", "at", "all"),
    outcome = "vs"
  ), "'var_config_csv' must be a character string input")
})

test_that("An error occurs if the var_config_csv file doesn't exist", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config_csv = "not_here.csv",
    outcome = "vs"
  ), "No 'var_config_csv' file found at 'not_here.csv'")
})


test_that("An error occcurs if the pth argument is not numeric", {
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = "extreme_test",
    pth = "bananas"
  ), "The 'pth' argument must be a numeric between 0 and 1")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = "extreme_test",
    pth = NA
  ), "The 'pth' argument must be a numeric between 0 and 1")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = "extreme_test",
    pth = NULL
  ), "The 'pth' argument must be a numeric between 0 and 1")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = "extreme_test",
    pth = c(99, 76)
  ), "The 'pth' argument must be a numeric between 0 and 1")
})

test_that("An error occurs if the ex_val_thrsh file does not exist", {
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "bananas.csv"
  ), "The file: 'bananas.csv' does not exist")
})

test_that("An error occurs if the pth variable is not between 0 and 1", {
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = -0.2,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv"
  ), "The 'pth' argument must be between 0 and 1")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 1.2,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv"
  ), "The 'pth' argument must be between 0 and 1")
})

test_that("An error occurs if the output argument is not a character string", {
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = TRUE
  ), "'output' argument must be a character string")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = 99
  ), "'output' argument must be a character string")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output = c("Hello", "World")
  ), "'output' argument must be a character string")
})

test_that("An error occurs if the output_dir is not a character string of the save path", {
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output_dir = TRUE
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output_dir = 99
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output_dir = c("Hello", "World")
  ), "'output_dir' argument must be a character string of the save path")
})

test_that("The output_csv argument is a single logical value", {
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output_csv = "Monkeys"
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output_csv = c(FALSE, TRUE)
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output_csv = NULL
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(extreme_values(
    input = transformed_data,
    var_config_csv = "var_config.csv",
    pth = 0.99,
    ex_val_thrsh = "ex_val_thrsh_test_input.csv",
    output_csv = NA
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
})

test_that("Wrong column number in ex_val_thrsh results in an error", {
  expect_error(check_thrsh_df(
    thrsh_df = ex_val_thrsh_wrong_columns,
    file_name = "file_column.csv",
    input = transformed_data
  ), "The information in 'file_column.csv' does not contain 2 columns")
})

test_that("No row data in ex_val_thrsh results in an error", {
  expect_error(check_thrsh_df(
    thrsh_df = ex_val_thrsh_wrong_rows,
    file_name = "file_rows.csv",
    input = transformed_data
  ), "The information in 'file_rows.csv' does not contain any rows of data")
})

test_that("A warning is raised if the columns in thresh_df have wrong names", {
  expect_warning(check_thrsh_df(
    thrsh_df = ex_val_thrsh_wrong_column_names,
    file_name = "name.csv",
    input = transformed_data
  ),
"The column names in name.csv data have been changed to 'Variable' and 'Thrsh'")
})

test_that("Variables in thrsh_df not in the input result in an error", {
  expect_error(check_thrsh_df(
    thrsh_df = ex_val_thrsh_wrong_variables,
    file_name = "wv.csv",
    input = transformed_data
  ), sprintf(
  "The following variables in '%s' are not present in the input data: %s",
  "wv.csv", "'boomerang', 'kangaroos'"))
})

unlink("extreme_test_ex.csv")
unlink("extreme_test_no_ex_val_thrsh_ex.csv")
unlink("extreme_test_ex_val_thrsh_out.csv")
