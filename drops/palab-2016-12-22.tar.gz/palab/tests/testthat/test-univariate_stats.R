context("Generating univariate descriptive statistics")

library(readr)
suppressMessages(library(dplyr))

## This first section loads in the data used for the testing

# All input data
transformed_input <- suppressWarnings(
  suppressMessages(read_csv("transformed_data.csv"))
)

transformed_input_categorical <- suppressMessages(
  read_csv("transformed_data_categorical.csv")
)

transformed_input_numerical <- suppressMessages(
  read_csv("transformed_data_numerical.csv")
)

transformed_cyl_one_value_qsec_missing <- suppressMessages(
  read_csv("transformed_data_cyl_one_value_qsec_missing.csv")
)

# Categorical output data
output_categorical_missing_info_and_number_cat <- suppressMessages(
  read_csv("univar_stats_x_cat_missing_info_and_level_number_cat.csv")
)

output_categorical_missing_info_and_number_melted <- suppressMessages(
  read_csv("univar_stats_x_cat_missing_info_and_level_number_melted.csv")
)

output_categorical_level_information_cat <- suppressMessages(
  read_csv("univar_stats_x_cat_level_information_cat.csv")
)

output_categorical_level_information_melted <- suppressMessages(
  read_csv("univar_stats_x_cat_level_information_melted.csv")
)

output_categorical_total_cat <- suppressMessages(
  read_csv("univar_stats_x_cat_test_input.csv")
)

output_categorical_total_melted <- suppressMessages(
  read_csv("univar_stats_x_cat_melted_test_input.csv")
)

# Numerical output data
# Must be a BaseR dataframe due to duplicate column names
output_numerical <- suppressMessages(
  read.csv("univar_stats_x_num_test_input.csv", check.names = FALSE,
           stringsAsFactors = FALSE)
)

# Meta data files
var_config <- suppressMessages(read_csv("var_config.csv"))

# Problem outputs
cyl_qsec_problem <- suppressMessages(read_csv("cyl_qsec_problem_report.csv"))


## Starting the tests

# Checking that the output is correct when calling the main function
test_that("The main function returns the correct outputs", {
  all_summaries <- univariate_stats(
    input = transformed_input,
    var_config_csv = "var_config.csv"
  )

  # Extracting the elements out of the list
  cat_summary <- all_summaries$cat
  melted_summary <- all_summaries$melted
  numerical_summary <- all_summaries$numerical

  # Performing all the required rounding
  cat_num_indices <- vapply(cat_summary, class, "") == "numeric"
  melted_num_indices <- vapply(melted_summary, class, "") == "numeric"
  numeric_num_indices <- vapply(numerical_summary, class, "") == "numeric"

  cat_summary[cat_num_indices] <- round(cat_summary[cat_num_indices],
                                        digits = 2)
  melted_summary[melted_num_indices] <- round(
    melted_summary[melted_num_indices], digits = 2
  )
  numerical_summary[numeric_num_indices] <- round(
    numerical_summary[numeric_num_indices], digits = 2
  )

  output_categorical_total_cat[cat_num_indices] <- round(
    output_categorical_total_cat[cat_num_indices], digits = 2
  )

  output_categorical_total_melted[melted_num_indices] <- round(
    output_categorical_total_melted[melted_num_indices], digits = 2
  )

  output_numerical[numeric_num_indices] <- round(
    output_numerical[numeric_num_indices], digits = 2
  )

  # Now testing the equalities
  expect_equal(cat_summary, output_categorical_total_cat,
               tolerance = 1e-2)
  expect_equal(melted_summary, output_categorical_total_melted,
               tolerance = 1e-2)
  expect_equal(numerical_summary, output_numerical, tolerance = 1e-2)
})

# Testing the checking of the arguments
test_that("An error occurs if the input argument is not a data.frame", {
  expect_error(univariate_stats(input = "monkey",
                                var_config_csv = "var_config.csv"),
               "A dataframe is required for the 'input' argument")
})

test_that("An error occurs is no input parameter is given", {
  expect_error(univariate_stats(var_config_csv = "var_config.csv"),
               "A dataframe is required for the 'input' argument")
})

test_that("An error occurs if var_config_csv is not a character string", {
  expect_error(univariate_stats(
    input = transformed_input,
    var_config_csv = 12
  ), "'var_config_csv' must be a character string input")

  expect_error(univariate_stats(
    input = transformed_input,
    var_config_csv = c("var_config", "var_config")
  ), "'var_config_csv' must be a character string input")
})

test_that("An error occurs if no var_config_csv parameter is given", {
  expect_error(univariate_stats(
    input = transformed_input
  ), "'var_config_csv' must be a character string input")
})

test_that("An error occurs if the var_config_csv file does not exist", {
  expect_error(univariate_stats(
    input = transformed_input,
    var_config_csv = "supernatural_var_config.csv"
  ), "No 'var_config_csv' file found at 'supernatural_var_config.csv'")
})

test_that("Checking that var_config has the right column names", {
  expect_error(univariate_stats(
    input = transformed_input,
    var_config_csv = "var_config_wrong_Column_name.csv"
  ),
  "The column names for the var_config dataframe must be 'Column' and 'Type'")
})

test_that("An error occurs if the output argument is not a character string", {
  expect_error(univariate_stats(input = transformed_input,
                                var_config_csv = "var_config.csv",
                                output = c("Dinosaur", "Eggs")),
               "'output' argument must be a character string")
  expect_error(univariate_stats(input = transformed_input,
                                var_config_csv = "var_config.csv",
                                output = 987),
               "'output' argument must be a character string")
  expect_error(univariate_stats(input = transformed_input,
                                var_config_csv = "var_config.csv",
                                output = NA),
               "'output' argument must be a character string")
  expect_error(univariate_stats(input = transformed_input,
                                var_config_csv = "var_config.csv",
                                output = NULL),
               "'output' argument must be a character string")
})

test_that("An error occurs if output_dir argument is not a character string", {
  expect_error(univariate_stats(input = transformed_input,
                                var_config_csv = "var_config.csv",
                                output_dir = c("Dinosaur", "Eggs")),
            "'output_dir' argument must be a character string of the save path")
  expect_error(univariate_stats(input = transformed_input,
                                var_config_csv = "var_config.csv",
                                output_dir = 987),
            "'output_dir' argument must be a character string of the save path")
  expect_error(univariate_stats(input = transformed_input,
                                var_config_csv = "var_config.csv",
                                output_dir = NA),
            "'output_dir' argument must be a character string of the save path")
  expect_error(univariate_stats(input = transformed_input,
                                var_config_csv = "var_config.csv",
                                output_dir = NULL),
            "'output_dir' argument must be a character string of the save path")
})

# Testing the helper functions
test_that("The categorical subset is correctly selected", {
  subset_categorical <- get_categorical_variables(transformed_input, var_config)
  expect_equal(subset_categorical, transformed_input_categorical)
})

test_that("The numerical subset is correctly selected", {
  subset_numerical <- get_numerical_variables(transformed_input, var_config)
  expect_equal(subset_numerical, transformed_input_numerical)
})

test_that("Categorical missing information and level count data is correct", {
  subset_categorical <- get_categorical_variables(transformed_input, var_config)
  missing_info_and_level_count <- get_categorical_missing_info_and_level_number(
    subset_categorical
  )

  # Doing this for the cat output first
  missing_info_and_level_count_cat <- missing_info_and_level_count$cat

  # Rounding all the numerical values to 2 decimal places as this is how the
  # example files from Q-IMS have been saved
  numeric_indices_cat <- vapply(missing_info_and_level_count_cat,
                            class, "") == "numeric"

   missing_info_and_level_count_cat[numeric_indices_cat] <- round(
     missing_info_and_level_count_cat[numeric_indices_cat], digits = 2
   )

  expect_equal(missing_info_and_level_count_cat,
               output_categorical_missing_info_and_number_cat)

  # Now testing the melted output
  missing_info_and_level_count_melted <- missing_info_and_level_count$melted

  # Rounding all the numerical values to 2 decimal places as this is how the
  # example files from Q-IMS have been saved
  numeric_indices_melted <- vapply(missing_info_and_level_count_melted,
                            class, "") == "numeric"

  missing_info_and_level_count_melted[numeric_indices_melted] <- round(
    missing_info_and_level_count_melted[numeric_indices_melted], digits = 2
  )

  expect_equal(missing_info_and_level_count_cat,
               output_categorical_missing_info_and_number_cat)
})

test_that("Level information on the categorical variables is correct", {
  subset_categorical <- get_categorical_variables(transformed_input, var_config)
  level_information <- get_categorical_level_information(subset_categorical)

  # Testing the cat output first
  level_information_cat <- level_information$cat

  # Rounding all the numerical values to 2 decimal places as this is how the
  # example files from Q-IMS have been saved
  numeric_indices_cat <- vapply(level_information_cat,
                            class, "") == "numeric"
  level_information_cat[numeric_indices_cat] <- round(
    level_information_cat[numeric_indices_cat], digits = 2
  )
  expect_equal(level_information_cat,
               output_categorical_level_information_cat)

  # Now testing the melted output
  level_information_melted <- level_information$melted

  # Rounding all the numerical values to 6 decimal places as this is how the
  # example files from Q-IMS have been saved
  numeric_indices_melted <- vapply(level_information_melted,
                            class, "") == "numeric"
  level_information_melted[numeric_indices_melted] <- round(
    level_information_melted[numeric_indices_melted], digits = 2
  )

  # And making sure that this is done for the loaded file as well
  output_categorical_level_information_melted[numeric_indices_melted] <- round(
    output_categorical_level_information_melted[numeric_indices_melted],
    digits = 2
  )

  expect_equal(level_information_melted,
               output_categorical_level_information_melted)
})

test_that("All the information from the categorical variables is correct", {
  subset_categorical <- get_categorical_variables(transformed_input, var_config)

  all_categorical_information <- create_categorical_summary(subset_categorical)
  all_information_cat <- all_categorical_information$cat
  all_information_melted <- all_categorical_information$melted

  # Making sure that all dataframes have the same amount of decimal places
  numerical_indices_cat <- vapply(all_information_cat,
                                  class, "") == "numeric"

  all_information_cat[numerical_indices_cat] <- round(
    all_information_cat[numerical_indices_cat], digits = 2
  )

  output_categorical_total_cat[numerical_indices_cat] <- round(
    output_categorical_total_cat[numerical_indices_cat], digits = 2
  )

  numerical_indices_melted <- vapply(all_information_melted,
                                  class, "") == "numeric"

  all_information_melted[numerical_indices_melted] <- round(
    all_information_melted[numerical_indices_melted], digits = 2
  )

  output_categorical_total_melted[numerical_indices_melted] <- round(
    output_categorical_total_melted[numerical_indices_melted], digits = 2
  )

  expect_equal(all_information_cat, output_categorical_total_cat)
  expect_equal(all_information_melted, output_categorical_total_melted)

})

test_that("All the information from the numeric variable is correct", {
  subset_numeric <- get_numerical_variables(transformed_input, var_config)

  numerical_summary <- get_numerical_summary(subset_numeric)

  # Setting all of the decimal place to be 2
  numerical_indices <- vapply(numerical_summary, class, "") == "numeric"

  numerical_summary[numerical_indices] <- round(
    numerical_summary[numerical_indices], digits = 2
  )

  output_numerical[numerical_indices] <- round(
    output_numerical[numerical_indices], digits = 2
  )

  expect_equal(numerical_summary, output_numerical, tolerance = 1e-2)
})

# Testing the problem report dataframe
test_that("The problem report is returning the correct information", {
  cyl_qsec_problem_df_output <- get_problem_summary(
    transformed_cyl_one_value_qsec_missing
  )
  expect_equal(cyl_qsec_problem_df_output$report, cyl_qsec_problem)
})

# Cleaning up any files that were created during testing
unlink("univar_stats_x_cat.csv")
unlink("univar_stats_x_cat_melted.csv")
unlink("univar_stats_x_num.csv")
unlink("univar_stats_problems.csv")
