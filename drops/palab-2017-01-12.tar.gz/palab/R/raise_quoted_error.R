#' Getting the quoted column error messages
#'
#' This function is raised by another function if an error message is to be
#' called that gives information about any input columns that do not meet
#' any criteria, and musts therefore result in a graceful exit from the
#' program
#'
#' @param vec A character vector
#' @param message_suffix A character string that makes up the end of the error
#' message to be presented to the user
#' @return An error to the user. All of the entriex in \code{vec} are listed,
#' with single quotes around each one, followed by \code{message_suffix}
#'
raise_quoted_error <- function(vec, message_suffix) {
  wrong_quotes <- paste0("'", vec, "'")
  wrong_string <- paste(wrong_quotes, collapse = ", ")
  wrong_message <- sprintf(
    "%s %s",
    wrong_string, message_suffix
  )
  stop(wrong_message)
}
