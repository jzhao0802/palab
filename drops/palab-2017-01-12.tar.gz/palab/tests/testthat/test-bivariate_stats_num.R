context("Testing Bivariate Statistics for Numerical Variables")

## Loading in the required data for the tests
transformed_data <- suppressMessages(
  readr::read_csv("transformed_data.csv")
)

transformed_data_numerical <- suppressMessages(
  readr::read_csv("transformed_data_numerical.csv")
)

transformed_data_categorical <- suppressMessages(
  readr::read_csv("transformed_data_categorical.csv")
)

expected_numerical_summary <- suppressMessages(
  readr::read_csv("bivar_stats_y_num_x_num_test_input.csv")
)

expected_correlation_outcome <- suppressMessages(
  readr::read_csv("bivar_stats_y_num_x_num_correlation_information.csv")
)

expected_decile_outcome <- suppressMessages(
  readr::read_csv("bivar_stats_y_num_x_num_decile_information.csv")
)

# The following input requires some manipulation to get the lines into the
# same order as the output. This is because the output in the provided
# example file is a strange order that would require custom ordering to
# recreate
expected_categorical_summary <- suppressMessages(
  readr::read_csv("bivar_stats_y_num_x_cat_test_input.csv")
)

expected_categorical_summary <- expected_categorical_summary %>%
  dplyr::mutate_(`Categorical variable` =
                 ~factor(`Categorical variable`,
                         levels = unique(`Categorical variable`))) %>%
  dplyr::arrange_(.dots = c("`Categorical variable`", "Level")) %>%
  dplyr::mutate_(`Categorical variable` =
                 ~as.character(`Categorical variable`))

# This also needs to be as a baseR dataframe as the tests were failing
# with tidyverse data_frames
expected_categorical_summary <- as.data.frame(
  expected_categorical_summary
)

expected_relative_risk_summary <- suppressMessages(
  readr::read_csv("rr_stats_y_num_x_cat_test_input.csv")
)

# Converting this to a baseR dataframe
expected_relative_risk_summary <- as.data.frame(
  expected_relative_risk_summary
)

## Performing the tests

test_that("The numerical summary is as expected", {
  numerical_summary <- bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    correlation_warning = FALSE
  )$num
  expect_equal(numerical_summary, expected_numerical_summary,
               tolerance = 1e-2)
})

test_that("The categorical summary is as expected", {
  categorical_summary <- bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    correlation_warning = FALSE
  )$cat

  # Converting to a baseR dataframe
  categorical_summary <- as.data.frame(categorical_summary)
  expect_equal(categorical_summary, expected_categorical_summary,
               tolerance = 1e-2)
})

test_that("Relative Risk output is expected", {
  relative_risk_summary <- bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    correlation_warning = FALSE
  )$rr
  # Converting to a baseR dataframe
  relative_risk_summary <- as.data.frame(relative_risk_summary)

  # expect_equivalent is being used here due to the $spec attribute in the
  # data that was read in, and not present in the calculated dataframe
  expect_equivalent(relative_risk_summary, expected_relative_risk_summary)

})

# Testing the user entered arguments
test_that("An error occurs if the input argument is not a dataframe", {
  expect_error(bivariate_stats_num(
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg"
  ), "A dataframe is required for the 'input'argument")
  expect_error(bivariate_stats_num(
    input = "not a dataframe",
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg"
  ), "A dataframe is required for the 'input'argument")
})

test_that("An error occurs if no var_config is given", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    outcome_var = "mpg"
  ), "'var_config' must be a character string input")
})

test_that("An error occurs if var_config is not a character string", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = 32,
    outcome_var = "mpg"
  ), "'var_config' must be a character string input")

  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = c("Not", "cool", "at", "all"),
    outcome_var = "mpg"
  ), "'var_config' must be a character string input")
})

test_that("An error occurs if the var_config file doesn't exist", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "not_here.csv",
    outcome_var = "mpg"
  ), "No 'var_config' file found at 'not_here.csv'")
})

test_that("An error occurs if 'Column' and 'Type' are not in var_config", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_wrong_Column_name.csv",
    outcome_var = "mpg"
  ), "The var_config dataframe must contain the columns 'Column' and 'Type'")
})

test_that("An error occurs if there are no numerical variables", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key_all_cat.csv"
  ))
})

test_that("An error occurs is no outcome_var argument is provided",{
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv"
  ), "A character string must be given for the 'outcome_var' argument")
})

test_that("An error occurs is the outcome_var argument is not a character string", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = c("Hello", "World")
  ), "'outcome_var' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = NA
  ), "'outcome_var' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = NULL
  ), "'outcome_var' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = 999
  ), "'outcome_var' argument must be a character string")
})

test_that("An error occurs if the output argument is not a character string", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    output = c("Hello", "World")
  ), "'output' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    output = NA
  ), "'output' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    output = NULL
  ), "'output' argument must be a character string")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    output = 999
  ), "'output' argument must be a character string")
})

test_that("An error occurs if output_dir argument is not a character string", {
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    output_dir = c("Hello", "World")
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    output_dir = NA
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    output_dir = NULL
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    output_dir = 999
  ), "'output_dir' argument must be a character string of the save path")
})

test_that("An error occurs if the count argument is not a whole number",{
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    count = c(1, 12)
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    count = NA
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    count = NULL
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    count = 87.4
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_num(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "mpg",
    count = "bananas"
  ), "'count' argument must be a numeric whole number")
})


test_that("An error occurs if the outcome variable is not in the data", {
  expect_error(
    bivariate_stats_num(
      input = transformed_data,
      var_config = "var_config_generated_with_key.csv",
      outcome_var = "Dinosaurs"
    ), "'Dinosaurs' is not a variable in the input data"
  )
})

test_that("A warning occurs if the outcome variable is not numerical", {
  expect_warning(
    bivariate_stats_num(
      input = transformed_data,
      var_config = "var_config_generated_with_key.csv",
      outcome_var = "vs"
    ), "The outcome_var 'vs' is not classified as a numerical variable"
  )
})

test_that("The outcome for the correlation information is correct", {
  correlation_outcome <- get_numerical_correlation_information(
    input = transformed_data_numerical,
    outcome_var = "mpg",
    give_warning = FALSE
  )
  expect_equal(correlation_outcome, expected_correlation_outcome)
})

test_that("The outcome for the decile summary information is correct", {
  decile_outcome <- get_mean_decile_information(
    input = transformed_data_numerical,
    outcome_var = "mpg"
  )
  expect_equal(decile_outcome, expected_decile_outcome)
})

test_that("Error raised if outcome_var not present with categorical inputs", {
  expect_error(
    get_bivariate_num_cat_summary(
      input = transformed_data_categorical,
      outcome_var = "mpg"
    ),
   "The outcome_var has not been included with the categorical information"
  )
})


unlink("bivar_stats_y_num_x_cat.csv")
unlink("bivar_stats_y_num_x_num.csv")
unlink("RR_stats_y_num_x_cat.csv")
