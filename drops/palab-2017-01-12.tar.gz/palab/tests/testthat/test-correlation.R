context("The correlation function on the dummy variables")

# Loading in data
dummyfied_data <- suppressMessages(
  readr::read_csv("dummyfied_test_input.csv")
)

# The next file contains a column name with the problem variable Gender_F_-88
dummyfied_data_problem_column_header <- suppressMessages(
  readr::read_csv("dummyfied_test_input_problem_column_header.csv")
)

# The next two files should be the output from the no-problem variables
spearman_output <- suppressMessages(
  readr::read_csv("spearman_correlation_output.csv")
)

pearson_output <- suppressMessages(
  readr::read_csv("pearson_correlation_output.csv")
)

# The following are the output with the Gender_F_-88 column
spearman_output_problem_column <- suppressMessages(
  readr::read_csv("spearman_correlation_output_problem_column.csv")
)

pearson_output_problem_column <- suppressMessages(
  readr::read_csv("pearson_correlation_output_problem_column.csv")
)


# Carrying out the tests
test_that("The Spearman output is expected", {
  spearman_function_output <- correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    method = "spearman",
    correlation_warning = FALSE
  )
  expect_equal(spearman_output, spearman_function_output)
})

test_that("The Pearson output is expected", {
  pearson_function_output <- correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    method = "pearson",
    correlation_warning = FALSE
  )
  expect_equal(pearson_output, pearson_function_output)
})

test_that("The Spearman output is expected with the Gender_F_-88 column", {
  spearman_function_output <- correlation(
    input = dummyfied_data_problem_column_header,
    var_config = "var_config.csv",
    method = "spearman",
    correlation_warning = FALSE
  )
  expect_equal(spearman_output_problem_column, spearman_function_output)
})

test_that("The Pearson output is expected with the Gender_F_-88 column", {
  pearson_function_output <- correlation(
    input = dummyfied_data_problem_column_header,
    var_config = "var_config.csv",
    method = "pearson",
    correlation_warning = FALSE
  )
  expect_equal(pearson_output_problem_column, pearson_function_output)
})

test_that("An error occurs if the input argument is missing or incorrect", {
  expect_error(correlation(), "A dataframe is required for the 'input'argument")
  expect_error(extreme_values(input = c(NA, 99)),
               "A dataframe is required for the 'input'argument")
  expect_error(extreme_values(input = "not a dataframe"),
               "A dataframe is required for the 'input'argument")
})

test_that("Entering a wrong method results in an error", {
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    method = "so wrong"
  ), "The 'method' argument must be either 'spearman' or 'pearson'")
})

test_that("Data that cannot be coerced to numeric results in an error", {
  non_numeric_df <- dplyr::data_frame(
    one = seq(4),
    two = as.character(seq(5, 8)),
    three = c("apples", "pears", "bananas", "mangoes"),
    four = c("hello", "world", "galaxy", "universe")
  )
  expect_error(correlation(input = non_numeric_df,
                           var_config = "var_config.csv"),
               "Column(s): 'three', 'four' contain non-numeric information",
               fixed = TRUE)
})

test_that("An error occurs if the variable pair is not in the data", {
  wrong_var_pair_df <- dplyr::data_frame(
    one = seq(4),
    two = seq(2, 5),
    three = seq(3, 6),
    five = seq(4, 7)
  )
  expect_error(get_correlation_correlation_information(
    variable_pair = c("one", "four"),
    df = wrong_var_pair_df,
    cor_method = "pearson",
    correlation_warning = FALSE
  ), "One or both of 'one', 'four' are not in the dataframe columns",
  fixed = TRUE)
})

test_that("An error occurs if the output argument is not a character string", {
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    output = TRUE,
    correlation_warning = FALSE
  ), "'output' argument must be a character string")
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    output = 99,
    correlation_warning = FALSE
  ), "'output' argument must be a character string")
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    output = c("Hello", "World"),
    correlation_warning = FALSE
  ), "'output' argument must be a character string")
})

test_that("An error occurs if the output_dir is not a character string of the save path", {
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    output_dir = TRUE,
    correlation_warning = FALSE
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    output_dir = 99,
    correlation_warning = FALSE
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    output_dir = c("Hello", "World"),
    correlation_warning = FALSE
  ), "'output_dir' argument must be a character string of the save path")
})

test_that("The output_csv argument is a single logical value", {
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    output_csv = "Monkeys",
    correlation_warning = FALSE
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    output_csv = c(FALSE, TRUE),
    correlation_warning = FALSE
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    output_csv = NULL,
    correlation_warning = FALSE
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(correlation(
    input = dummyfied_data,
    var_config = "var_config.csv",
    output_csv = NA,
    correlation_warning = FALSE
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
})
