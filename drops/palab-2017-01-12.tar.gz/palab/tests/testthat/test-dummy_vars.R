context("Creating the dummy variables from the categorical variables")

# Reading in data
transformed_data <- suppressMessages(
  readr::read_csv("transformed_data.csv")
)

transformed_data_with_index_date <- suppressMessages(
  readr::read_csv("transformed_data_with_index_date.csv")
)

transformed_data_unique_cyl_vs <- suppressMessages(
  readr::read_csv("transformed_data_unique_cyl_vs.csv")
)

transformed_data_all_unique_categorical <- suppressMessages(
  readr::read_csv("transformed_data_all_categorical_unique.csv")
)

var_config_df <- suppressMessages(
  readr::read_csv("var_config_generated_with_key.csv")
)

var_config_df_one_column <- suppressMessages(
  readr::read_csv("var_config_one_column.csv")
)

var_config_wrong_column_name <- suppressMessages(
  readr::read_csv("var_config_wrong_Column_name.csv")
)

# Doing the tests
test_that("The function works correctly, and the var_config info is always written", {
  dummy_output <- dummy_vars(
    input = transformed_data,
    var_config = "var_config.csv",
    output = "dummy_vars_var_config_only"
  )
  dummy_var_config_from_file <- readr::read_csv(
    "dummy_vars_var_config_onlyvar_config_dummyfied.csv"
  )
  expect_equivalent(dummy_output$var_config, dummy_var_config_from_file)
})

test_that("All the output information is being written if specified", {
  dummy_output <- dummy_vars(
    input = transformed_data,
    var_config = "var_config.csv",
    output = "dummy_vars_all_outputs",
    output_csv = TRUE,
    name_desc = TRUE
  )
  dummyfied_info_from_file <- readr::read_csv(
    "dummy_vars_all_outputsdummyfied.csv"
  )
  dummy_var_config_from_file <- readr::read_csv(
    "dummy_vars_all_outputsvar_config_dummyfied.csv"
  )
  dummy_var_name_desc_info_from_file <- readr::read_csv(
    "dummy_vars_all_outputsname_desc_dummyfied.csv"
  )
  expect_equivalent(dummy_output$dummyfied, dummyfied_info_from_file)
  expect_equivalent(dummy_output$var_config, dummy_var_config_from_file)
  expect_equivalent(dummy_output$name_desc, dummy_var_name_desc_info_from_file)
})

test_that("Any 'other' variables are included in the output", {
  dummy_output_with_index_date <- dummy_vars(
    input = transformed_data_with_index_date,
    var_config = "var_config.csv",
    output = "dummy_vars_index_date"
  )
  dummyfied_info_from_file_index_date <- read.csv(
    "dummyfied_test_input_with_index_date.csv",
    stringsAsFactors = FALSE
  )
  expect_equivalent(dummyfied_info_from_file_index_date,
                    dummy_output_with_index_date$dummyfied)
})

test_that("The dummy variable column names are made correctly", {
  factor_input <- dplyr::data_frame(
    one = as.factor(c(2, 4, 1, 3)),
    two = as.factor(c("satsumas", "bananas", "apples", "mangoes"))
  )
  dummy_one <- c("one_2_1", "one_3_1", "one_4_1")
  dummy_two <- c("two_bananas_apples", "two_mangoes_apples",
                 "two_satsumas_apples")
  output_one <- get_dummy_names("one", factor_input)$var_values
  output_two <- get_dummy_names("two", factor_input)$var_values
  expect_equal(dummy_one, output_one)
  expect_equal(dummy_two, output_two)
})

test_that("An error occurs if the input argument is missing or incorrect", {
  expect_error(dummy_vars(
    var_config = "var_config_generated_with_key.csv"
  ), "A dataframe is required for the 'input'argument")
  expect_error(dummy_vars(
    input = c(NA, 99),
    var_config = "var_config_generated_with_key.csv"
  ), "A dataframe is required for the 'input'argument")
  expect_error(dummy_vars(
    input = "not a dataframe",
    var_config = "var_config_generated_with_key.csv"
  ), "A dataframe is required for the 'input'argument")
})

test_that("An error occurs if no var_config is given", {
  expect_error(dummy_vars(
    input = transformed_data
  ), "'var_config' must be a character string input")
})

test_that("An error occurs if var_config is not a character string", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = 32
  ), "'var_config' must be a character string input")

  expect_error(dummy_vars(
    input = transformed_data,
    var_config = c("Not", "cool", "at", "all")
  ), "'var_config' must be a character string input")
})

test_that("An error occurs if the var_config file doesn't exist", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "not_here.csv"
  ), "No 'var_config' file found at 'not_here.csv'")
})

test_that("An error occurs if 'Column' and 'Type' are not in var_config", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_wrong_Column_name.csv"
  ), "The var_config dataframe must contain the columns 'Column' and 'Type'")
})

test_that("An error occurs if the output argument is not a character string", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    output = TRUE
  ), "'output' argument must be a character string")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    output = 99
  ), "'output' argument must be a character string")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    output = c("Hello", "World")
  ), "'output' argument must be a character string")
})

test_that("An error occurs if there are no categorical variables", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key_all_num.csv"
  ), "There are no categorical variables present")
})

test_that("A warning occurs if any categorical column contain unique values", {
  expect_warning(dummy_vars(
    input = transformed_data_unique_cyl_vs,
    var_config = "var_config_generated_with_key.csv"
  ),
  "Column(s) 'cyl', 'vs' removed due to unique values (not possible for dummy vars)",
  fixed = TRUE
  )
})

test_that("An error occurs if all categorical columns contain unique values", {
  expect_error(dummy_vars(
    input = transformed_data_all_unique_categorical,
    var_config = "var_config_generated_with_key.csv"
  ), "All of the categorical variables contain only unique values")
})

test_that("An error occurs if the output_dir is not a character string of the save path", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    output_dir = TRUE
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    output_dir = 99
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    output_dir = c("Hello", "World")
  ), "'output_dir' argument must be a character string of the save path")
})

test_that("The name_desc argument is a single logical value", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    name_desc = "Monkeys"
  ), "'name_desc' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    name_desc = c(FALSE, TRUE)
  ), "'name_desc' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    name_desc = NULL
  ), "'name_desc' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    name_desc = NA
  ), "'name_desc' argument must be a single value of TRUE or FALSE")
})

test_that("The output_csv argument is a single logical value", {
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    output_csv = "Monkeys"
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    output_csv = c(FALSE, TRUE)
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    output_csv = NULL
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(dummy_vars(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    output_csv = NA
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
})

unlink("var_config_dummyfied.csv")
unlink("dummy_vars_var_config_onlyvar_config_dummyfied.csv")
unlink("dummy_vars_all_outputsdummyfied.csv")
unlink("dummy_vars_all_outputsvar_config_dummyfied.csv")
unlink("dummy_vars_all_outputsname_desc_dummyfied.csv")
unlink("dummy_vars_index_datevar_config_dummyfied.csv")
