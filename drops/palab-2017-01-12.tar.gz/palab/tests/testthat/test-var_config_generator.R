context("Generating the var_config information")

# Reading in all of the required input dataframes and output summaries
custom_inputs <- suppressMessages(
  readr::read_csv("var_config_generator_custom_inputs.csv")
)

custom_output <- suppressMessages(
  readr::read_csv("var_config_generator_custom_outputs.csv")
)

q_ims_inputs <- suppressMessages(readr::read_csv("mtcars.csv"))
q_ims_output <- suppressMessages(readr::read_csv("var_config_generated.csv"))

test_that("Customs inputs result in custom summary", {
  generated_custom_output <- get_output_df(custom_inputs)
  expect_equal(generated_custom_output, custom_output)
})

test_that("Q-IMS inputs results in generated output", {
  generated_q_ims_output <- get_output_df(q_ims_inputs)
  expect_equal(generated_q_ims_output, q_ims_output)
})

test_that("The main function is writing to a file", {
  generated_output <- var_config_generator(
    input_csv = "mtcars.csv",
    output = "test")
  expect_equal(generated_output, q_ims_output)
})

test_that("Errors occur when no input_csv argument is entered", {
  expect_error(var_config_generator(),
               "You need to enter a value for the 'input_csv' file")
})

test_that("Errors occur if input_csv is not a character string", {
  expect_error(var_config_generator(input_csv = c("hello", "world")),
               "'input_csv' argument must be a charater string")
  expect_error(var_config_generator(input_csv = 999),
               "'input_csv' argument must be a charater string")
  expect_error(var_config_generator(input_csv = NA))
})

test_that("Errors occur if output is not a character string", {
  expect_error(var_config_generator(input_csv = "mtcars.csv",
                                    output = 99),
               "'output' argument must be a character string")
  expect_error(var_config_generator(input_csv = "mtcars.csv",
                                    output = NA),
               "'output' argument must be a character string")
  expect_error(var_config_generator(input_csv = "mtcars.csv",
                                    output = c("Tom", "Jerry")),
               "'output' argument must be a character string")
})

test_that("Errors occur if output_dir is not a character string", {
  expect_error(
    var_config_generator(input_csv = "mtcars.csv",
                         output_dir = 99),
    "'output_dir' argument must be a character string of the save path")
  expect_error(
    var_config_generator(input_csv = "mtcars.csv",
                         output_dir = NA),
    "'output_dir' argument must be a character string of the save path")
  expect_error(
    var_config_generator(input_csv = "mtcars.csv",
                         output_dir = c("Tom", "Jerry")),
    "'output_dir' argument must be a character string of the save path")
})

test_that("Errors occur is sample_rows is not a numeric whole number", {
  expect_error(var_config_generator(input_csv = "mtcars.csv",
                                    sample_rows = "Zoo"),
               "'sample_rows' argument must be a numeric whole number")
  expect_error(var_config_generator(input_csv = "mtcars.csv",
                                    sample_rows = 99.9),
               "'sample_rows' argument must be a numeric whole number")
  expect_error(var_config_generator(input_csv = "mtcars.csv",
                                    sample_rows = c(12, 13)),
               "'sample_rows' argument must be a numeric whole number")
})

unlink("testvar_config.csv")




















