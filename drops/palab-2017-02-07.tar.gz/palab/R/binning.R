#' Assign numeric variable values to bins
#'
#' This function will assign the values of the numerical variables to histogram
#' like bins based on either their ranges or their quantiles. Other than the
#' first bin, all the bins are open-left, meaning that all the ranges are
#' defined as "greater-than/less-than-or-equal-to". The first bin is closed on
#' both ends to ensure than the minimum value of a variable is assigned to a
#' bin. For each observation, the function will either return the ordinal value
#' of the bin that the observation was assigned to, or the mean value of all the
#' observations in the same bin. All of these options can be set by the user at
#' the calling of the function
#'
#' @param input A dataframe of the transformed output from
#' \code{\link{read_transform}}
#' Any variable columns starting with "o_" will not be included in the analysis
#' @param var_config A summary dataframe describing the input types. The
#' function \code{\link{var_config_generator}} provides a template for this,
#' which needs to be checked by the user before use. The first column
#' must have the header \code{Column} and the second must have \code{Type}
#' @param binning_config_csv A character string providing the path to a csv file
#' containing information on the binning parameters. It must contain the
#' following columns, which are provided below together with the role of each
#' parameter
#' \describe{
#'   \item{Variable}{The name of the continuous variable for considering in
#'   each row. Each input variable can only feature once in this columns, and an
#'   error will be thrown otherwise. Any variable in the input data that does
#'   not feature in this column will not be considered for analysis}
#'   \item{NumBins}{A value is required here if the variable is to be binned
#'   into equal blocks based either on the range or quantiles of the variable
#'   (specified in the \code{method} column). If a specific set of non-equal
#'   splits is required, then these must be specified in the \code{cutpoints}
#'   column, and this column must remain either empty or 'NA'}
#'   \item{Method}{A single character, either 'q' or 'r'. This
#'   determines if the variable should be divided by its range of values, or
#'   into quartiles. If no entry is given, then the default is 'q'}
#'   \item{CutPoints}{A comma separated numeric vector providing the specific
#'   cutpoints that are to be used when creating the break points for the
#'   binning. This must be comma separated. Any other punctuation will result
#'   in an error. Of note, if the \code{method} column is set to 'q', then all
#'   of the values in \code{CutPoints} must be between 0 and 1}
#'   \item{ReplaceVal}{A character string, either 'm' or 'o' that states the
#'   type of summary of the variable in question. If 'm', then the mean of all
#'   the values in each bin will be returned; if 'o', then the ordinal value
#'   of each bin will be given. If no value is given, then 'm' will be the
#'   default}
#' }
#' @param prefix A character string of the prefix that will be given to the
#' file where the outputs will be saved
#' @param output_dir A character string of the path to the directory where the
#' output file is to be saved. The separator for the directories must be "/",
#' and not "\\" that is common on the Windows operating system
#' Default is current directory
#' @param output_csv A boolean to indicate if the outputs should be written
#' to the output file
#' @return A dataframe where all of the variables from \code{input} that
#' feature in the \code{Variable} column of the \code{binning_config_csv}
#' dataframe have been replaced by their binned values
#'
#' @export binning
#'
binning <- function(input, var_config, binning_config_csv, prefix = "",
                    output_dir = ".", output_csv = FALSE) {

  # Performing some checks on the inputs
  if (missing(input) || !is.data.frame(input)) {
    stop("A dataframe is required for the 'input'argument")
  }

  if (missing(var_config) || !is.character(var_config) ||
      length(var_config) != 1) {
    stop("'var_config' must be a character string input")
  }

  if (!file.exists(var_config)) {
    var_config_file_error <- sprintf(
      "No 'var_config' file found at '%s'", var_config
    )
    stop(var_config_file_error)
  }

  if (missing(binning_config_csv) || !is.character(binning_config_csv) ||
      length(binning_config_csv) != 1) {
    stop("'binning_config_csv' must be a character string input")
  }

  if (!file.exists(binning_config_csv)) {
    binning_config_file_error <- sprintf(
      "No 'binning_config_csv' file found at '%s'", binning_config_csv
    )
    stop(var_config_file_error)
  }

  if (!is.character(prefix) || length(prefix) != 1) {
    stop("'prefix' argument must be a character string")
  }

  if (!is.character(output_dir) || length(output_dir) != 1) {
    stop("'output_dir' argument must be a character string of the save path")
  }

  if (!is.logical(output_csv) || length(output_csv) != 1 || is.na(output_csv)) {
    stop("'output_csv' argument must be a single value of TRUE or FALSE")
  }

  # Loading in the var_config dataframe and checking column names
  var_config <- suppressMessages(readr::read_csv(var_config))
  if (!all(c("Column", "Type") %in% colnames(var_config))) {
    stop(
    "The var_config dataframe must contain the columns 'Column' and 'Type'"
    )
  }

  # Loading in the binning_config_csv dataframe and checking column names
  binning_df <- suppressMessages(readr::read_csv(
    binning_config_csv,
    col_types = "cnccc"
  ))
  binning_required_columns <- c(
    "Variable",
    "NumBins",
    "Method",
    "CutPoints",
    "ReplaceVal"
  )

  if (!all(colnames(binning_df) %in% binning_required_columns)) {
    raise_quoted_error(
      binning_required_columns,
      "must be the column headers in the binning_config_csv_file"
    )
  }

  # Removing the factors from the 3 dataframes
  input <- df_remove_factors(input)
  var_config <- df_remove_factors(var_config)
  binning_df <- df_remove_factors(binning_df)

  # Getting the numerical subset of the input variables
  input_numeric <- get_numerical_variables(input, var_config)

  # Checking all of the entries in the binning_df
  binning_df <- check_binning_config_dataframe(input_numeric, binning_df)

  # Getting the subset of numeric variables that feature in binning_df
  input_binned <- input_numeric[binning_df$Variable]

  # Getting the binned information for these variables
  binning_output_df <- dplyr::as_data_frame(
    unlist(
      lapply(
        colnames(input_binned),
        variable_binning,
        input_binned = input_binned,
        binning_df = binning_df
      ),
      recursive = FALSE
    )
  )

  # Assigning these binned values back into the original input dataframe
  # The input dataframe is being assigned a different variable name to avoid
  # calling a output variable 'input'
  # This implementation does not use any extra memory
  output_df <- input
  rm(input)
  output_df[colnames(binning_output_df)] <- binning_output_df

  # Writing all the information to the output files if required
  if (output_csv) {
    output_dir <- file.path(output_dir)

    # Checking if the output_dir exists, and making it if it doesn't
    if (!dir.exists(output_dir)) {
      dir.create(output_dir, recursive = TRUE)
    }

    if (tools::file_ext(prefix) == "csv") {
      prefix <- tools::file_path_sans_ext(prefix)
    }

    binning_output <- paste0(prefix, "binning.csv")
    binning_path <- file.path(output_dir, binning_output)

    readr::write_csv(output_df, binning_path)
  }

  output_df
}

#' Check the values of the binning config dataframe
#'
#' As so much of the \code{binning} function depends on the values in this
#' binning dataframe, it is vital that all of these make sense in order to avoid
#' downstream problems. The column names and the values of these columns will
#' be checked, and any errors will result in the program exiting gracefully
#'
#' @param input The dataframe of the numeric variables
#' @param binning_df The dataframe loaded in from binning_config_csv
#' @return A dataframe with the checked values. Any strings in the 'CutPoints'
#' column will be replaced by numeric vectors
#'
check_binning_config_dataframe <- function(input, binning_df) {

  # Checking for variables in the binning dataframe not in the input dataframe
  wrong_vars <- binning_df$Variable[!(binning_df$Variable %in% colnames(input))]

  if (length(wrong_vars) > 0) {
    raise_quoted_error(
      wrong_vars,
      "values in binning_config_csv not in the numerical input data"
    )
  }

  # Checking that all NumBins entries are integers
  if (any(binning_df$NumBins %% 1 != 0, na.rm = TRUE)) {
    wrong_num_df <- binning_df %>%
      dplyr::filter_(~!is.na(NumBins) & NumBins %% 1 != 0)

    wrong_num_bin_vars <- wrong_num_df$Variable
    raise_quoted_error(
      wrong_num_bin_vars,
      "contain non-integer 'NumBin' information"
    )
  }

  # Sorting out the Method column. Replacing NAs with 'q', and checking for
  # incorrect entries
  binning_df$Method[is.na(binning_df$Method)] <- "q"

  if (!all(binning_df$Method %in% c("q", "r"))) {
    wrong_method_df <- binning_df %>%
      dplyr::filter_(~!Method %in% c("q", "r"))

    raise_quoted_error(
      wrong_method_df$Variable,
      "contain non valid entries for 'Method'"
    )
  }

  # Checking that there is either an entry for NumBins or CutPoints but not both
  binning_numbins_cutpoints <- binning_df %>%
    dplyr::select_(.dots = c("NumBins", "CutPoints"))

  na_count <- apply(binning_numbins_cutpoints, 1, function(x) sum(is.na(x)))

  if (!all(na_count == 1)) {
    wrong_na_index <- which(na_count != 1)
    wrong_na_variables <- binning_df$Variable[wrong_na_index]
    raise_quoted_error(
      wrong_na_variables,
      "do not contain an exclusive entry for 'NumBins' or 'CutPoints'"
    )
  }

  # Checking any CutPoint values and replacing them with numeric vectors
  # instead of string. This uses another function as it is extensive
  binning_df <- cutpoint_checker(binning_df)

  # Sorting out the ReplaceVal column. Replacing NAs with 'm', and checking for
  # incorrect entries
  binning_df$ReplaceVal[is.na(binning_df$ReplaceVal)] <- "m"

  if (!all(binning_df$ReplaceVal %in% c("m", "o"))) {
    wrong_replaceval_df <- binning_df %>%
      dplyr::filter_(~!ReplaceVal %in% c("m", "o"))

    raise_quoted_error(
      wrong_replaceval_df$Variable,
      "contain non-valid entries for 'ReplaceVal'"
    )
  }

  binning_df
}

#' Check the values in the CutPoints column of the binning_config dataframe
#'
#' This function carries out a series of checks on the entries of the
#' CutPoints column of the binning information dataframe. These entries
#' represent the values that are to be used for any specific breakpoints to
#' create the bins. It is vital that these make logical sense in order to
#' prevent downstream errors. It checks that all of the values entered can be
#' coerced to a vector of numerics, and in the case of the quantile method, it
#' checks that all of these are between 0 and 1. If all of the tests pass, then
#' it will return a new dataframe with the entries in the CutPoints columns as
#' numeric vectors instead of comma separated character strings
#'
#' @param binning_df The dataframe loaded in from binning_config_csv
#' @return A new dataframe with the values in the CutPoints column replaced
#' with numeric vectors
#'
cutpoint_checker <- function(binning_df) {

  # First checking that the columns contain character strings
  if (!all(grepl(",", stats::na.omit(binning_df$CutPoints)))) {
    stop(
    "Check that the values in the CutPoints column are comma separated numbers"
    )
  }

  # Making a copy for when the data is returned, but without the CutPoints info
  cutpoint_index <- which(colnames(binning_df) == "CutPoints")
  binning_df_orig <- binning_df[-cutpoint_index]

  # Filtering out the rows with a cutpoint entry
  binning_df <- binning_df %>%
    dplyr::filter_(~!is.na(CutPoints))

  cutpoints_numeric <- suppressWarnings(
    lapply(strsplit(binning_df$CutPoints, split = ","), as.numeric)
  )

  # Checking for any NA values
  problem_variable_bool <- vapply(
    cutpoints_numeric,
    function(x) any(is.na(x)),
    TRUE
  )

  # Checking if there is any non-numeric information
  if (any(problem_variable_bool)) {
    problem_variables <- binning_df$Variable[problem_variable_bool]
    raise_quoted_error(
      problem_variables,
      "contain non-numeric CutPoints information"
    )
  }

  # Converting the cutpoints to numeric values from the string as this has
  # been shown to be possible
  binning_df$CutPoints <- cutpoints_numeric

  # Checking that all of the quantile information points make sense
  binning_df_quantile <- binning_df %>%
    dplyr::filter_(~Method == "q")

  non_quantile_number_bool <- vapply(
    binning_df_quantile$CutPoints,
    function(x) any(x < 0 | x > 1),
    TRUE
  )

  if (any(non_quantile_number_bool)) {
    problem_variables <- binning_df_quantile$Variable[non_quantile_number_bool]
    raise_quoted_error(
      problem_variables,
      "contain values not between 0 and 1 for quantile purposes"
    )
  }

  # If all of these tests are passed, then the dataframe can be returned
  # after joining back with the original dataframe and getting the correct order
  binning_df <- binning_df_orig %>%
    dplyr::left_join(binning_df,
                     by = c("Variable",
                            "NumBins",
                            "Method",
                            "ReplaceVal")) %>%
    dplyr::select_(.dots = c("Variable",
                             "NumBins",
                             "Method",
                             "CutPoints",
                             "ReplaceVal"))

  binning_df
}

#' Summarise the variables by bins based on different criteria
#'
#' This function actually carries out the process that creates the summaries
#' for the values in a single column of the input dataframe. As it applies to
#' only one column, it can be used in an 'lapply' version across the column
#' names of a dataframe to get the full summary. This function has to call on
#' two different helper functions depending on if the summaries are based on
#' ranges or quantiles
#'
#' @param var_name A character string of the variable column name
#' @param input_binned A dataframe containing the specific numeric variables
#' that are to be considered for binning summaries
#' @param binning_df A dataframe containing the binning config directions. This
#' should have passed a suite of tests on its contents, but additional tests
#' are added here
#' @return A list with the var_name as the name and the binned summary as the
#' contents
#'
variable_binning <- function(var_name, input_binned, binning_df) {

  # Getting the relevant row from the binning_df
  this_bin_variable_df <- binning_df %>%
    dplyr::filter_(~Variable == var_name)

  # Getting the binned values, using different functions for ranges or quantiles
  if (this_bin_variable_df$Method == "r") {
    binned_values <- range_bins(this_bin_variable_df,
                                input_binned[[var_name]])
  } else if (this_bin_variable_df$Method == "q") {
    binned_values <- quantile_bins(this_bin_variable_df,
                                   input_binned[[var_name]])
  } else {
    stop("WARNING!! The checking for Method inputs is not working")
  }

  binning_return_list <- list()
  binning_return_list[[var_name]] <- binned_values

  binning_return_list
}

#' Create the binning summary based on the value ranges
#'
#' This function gets the summary information when the bins are to be allocated
#' based on the ranges of the values
#'
#' @param bin_variable_df A dataframe, but only containing a single row from
#' the original \code{binning_config_csv} file that the concerns the variable
#' being summarised
#' @param values A numeric vector of the values from the input dataframe in
#' the column of the variable being summarised
#' @return A numeric vector of binned summary values based on value range
#'
range_bins <- function(bin_variable_df, values) {

  # Getting the break information from either NumBins or CutPoints
  if (!is.na(bin_variable_df$NumBins)) {

    # Getting either ordinal or mean binned information
    if (bin_variable_df$ReplaceVal == 'o') {

      # Setting manual break points for the .bincode function
      bin_breaks <- seq(min(values), max(values),
                        length.out = bin_variable_df$NumBins + 1)
      binned_values <- .bincode(values, bin_breaks, include.lowest = T)
    } else if (bin_variable_df$ReplaceVal == 'm') {

      # cut function can accept a number to make the breaks
      bin_factors <- cut(values, bin_variable_df$NumBins, include.lowest = T)
      binned_values <- tapply(values, bin_factors,
                              mean, na.rm = T)[bin_factors]
    } else {
      stop("WARNING!! The checking for the ReplaceVal inputs is not working")
    }
  } else {

    # This next section should never run
    if (is.na(bin_variable_df$CutPoints)) {
      stop("WARNING!! The checks for NumBins and CutPoints are not working")
    }

    # Adding -Inf and Inf to the bottom and top of the range CutPoints
    # otherwise values falling in the end bins would be assigned NA
    bin_breaks <- unique(c(-Inf, sort(bin_variable_df$CutPoints[[1]]), Inf))

    # Getting either ordinal or mean binned information
    if (bin_variable_df$ReplaceVal == 'o') {
      binned_values <- .bincode(values, bin_breaks)
    } else if (bin_variable_df$ReplaceVal == 'm') {
      bin_factors <- cut(values, bin_breaks)
      binned_values <- tapply(values, bin_factors,
                              mean, na.rm = T)[bin_factors]
    }
  }

  binned_values
}


#' Create the binning summary based on the value quantile
#'
#' This function gets the summary information when the bins are to be allocated
#' based on the quantiles of the values
#'
#' @param bin_variable_df A dataframe, but only containing a single row from
#' the original \code{binning_config_csv} file that the concerns the variable
#' being summarised
#' @param values A numeric vector of the values from the input dataframe in
#' the column of the variable being summarised
#' @return A numeric vector of binned summary values based on value quantiles
#'
quantile_bins <- function(bin_variable_df, values) {

  # Getting the break information from either NumBins or CutPoints
  if (!is.na(bin_variable_df$NumBins)) {

    # Setting the quantile probability break points to get the desired bins
    quantile_probs <- seq(0, 1, length.out = bin_variable_df$NumBins + 1)
    quantile_breaks <- stats::quantile(values, probs = quantile_probs,
                                       na.rm = TRUE)

    # Getting either ordinal or mean binned information
    if (bin_variable_df$ReplaceVal == 'o') {
      binned_values <- .bincode(values, quantile_breaks, include.lowest = T)
    } else if (bin_variable_df$ReplaceVal == 'm') {
      bin_factors <- cut(values, quantile_breaks, include.lowest = T)
      binned_values <- tapply(values, bin_factors, mean,
                              na.rm = T)[bin_factors]
    }
  } else {

    # This next section should never run
    if (is.na(bin_variable_df$CutPoints)) {
      stop("WARNING!! The checks for NumBins and CutPoints are not working")
    }

    # Adding 0 and 1 to the bottom and top of the quantile CutPoints
    # otherwise values falling in the end bind would be assigned NA
    quantile_probs <- unique(c(0, sort(bin_variable_df$CutPoints[[1]]), 1))
    quantile_breaks <- stats::quantile(values, probs = quantile_probs,
                                       na.rm = TRUE)

    # Getting either ordinal or mean binned information
    if (bin_variable_df$ReplaceVal == 'o') {
      binned_values <- .bincode(values, quantile_breaks, include.lowest = T)
    } else if (bin_variable_df$ReplaceVal == 'm') {
      bin_factors <- cut(values, quantile_breaks, include.lowest = T)
      binned_values <- tapply(values, bin_factors, mean,
                              na.rm = T)[bin_factors]
    }
  }

  binned_values
}
