#' Produce statistics for when the outcome is a flag
#'
#' This function produces a summary that is for situations where the outcome
#' variable is a 'flag' or a binary variable, and all of the input variables
#' are numerical. It creates a series of statistical summaries, some of which
#' are for the total range of values for each numerical variable, and the others
#' which are summarised at the 2 different levels of the outcome variable
#'
#' @param input A dataframe of the transformed output from
#' \code{\link{read_transform}}
#' @param var_config A character string of a file path to a csv file containing
#' a summary dataframe describing the input types. The function
#' \code{\link{var_config_generator}} provides a template for this, which needs
#' to be checked by the user before use. The first column must have the header
#' \code{Column} and the second must have \code{Type}
#' @param outcome_var A character string giving the column name of the variable
#' that is the outcome variable. This must contain only binary numeric values of
#' 0 and 1, and an error will be raised if this is not the case
#' @param prefix A character string that provides the prefix for the output
#' files
#' @param output_dir A character string of the path to the directory where the
#' output file is to be saved. The separator for the directories must be "/",
#' and not "\\" that is common on the Windows operating system
#' Default is current directory
#' @param correlation_warning Boolean. States if a warnings that can occur
#' during the correlation calculations should be hidden or not
#' @return A summary dataframe with all of the collected statistical summaries
#' @param output_csv A boolean to indicate if the outputs should be written
#' to the output file
#' @export bivar_stats_y_flag
#'
bivar_stats_y_flag <- function(input, var_config, outcome_var, prefix = "",
                              output_dir = ".", output_csv = FALSE,
                              correlation_warning = TRUE) {

# Performing some checks on the inputs
  if (missing(input) || !is.data.frame(input)) {
    stop("A dataframe is required for the 'input'argument")
  }

  if (missing(var_config) || !is.character(var_config) ||
      length(var_config) != 1) {
    stop("'var_config' must be a character string input")
  }

  if (!file.exists(var_config)) {
    var_config_file_error <- sprintf(
      "No 'var_config' file found at '%s'", var_config
    )
    stop(var_config_file_error)
  }

  if (!is.character(prefix) || length(prefix) != 1) {
    stop("'prefix' argument must be a character string")
  }

  if (!is.character(output_dir) || length(output_dir) != 1) {
    stop("'output_dir' argument must be a character string of the save path")
  }

  # Loading in the var_config dataframe and checking column names
  var_config <- suppressMessages(readr::read_csv(var_config))
  if (!all(c("Column", "Type") %in% colnames(var_config))) {
    stop(
    "The var_config dataframe must contain the columns 'Column' and 'Type'"
    )
  }

  # Removing any factors in both the input and var_config (just in case)
  input <- df_remove_factors(input)
  var_config <- df_remove_factors(var_config)

  # Checking the outcome_var parameter, and that it is in the input dataframe
  if (!is.character(outcome_var) || length(outcome_var) != 1) {
    stop("'outcome_var' argument must be a character string")
  }

  if (!outcome_var %in% colnames(input)) {
    outcome_var_name_error <- sprintf(
      "The 'outcome_var' value of '%s' is not in the input data",
      outcome_var
    )
    stop(outcome_var_name_error)
  }

  # Checking that the outcome variable is binary and raising an error if not
  outcome_var_values <- input[[outcome_var]]
  if (!all(outcome_var_values %in% c(0, 1))) {
    binary_outcome_var_error <- sprintf(
      "The values in the '%s' column contain values that are not 0 or 1",
      outcome_var
    )
    stop(binary_outcome_var_error)
  }

  # Getting the numerical subset of the input variables and including the
  # outcome_var
  numerical_df <- get_numerical_variables(input, var_config)
  numerical_outcome_df <- dplyr::bind_cols(
    numerical_df,
    input[outcome_var]
  )

  # Getting the summaries from the helper functions
  non_outcome_summary <- bivar_stats_flag_variable_summaries(numerical_df)
  outcome_summary <- bivar_stats_flag_variable_outcome_summaries(
    df = numerical_outcome_df,
    variables = colnames(numerical_df),
    outcome_var = outcome_var,
    correlation_warning = correlation_warning
  )

  # Joining these together, then creating the final 'Mean summary' summary
  full_summary <- dplyr::inner_join(
    non_outcome_summary,
    outcome_summary,
    by = "Variable"
  ) %>%
    dplyr::mutate_(
      `Mean Difference` = ~abs(`Class 0 Mean` - `Class 1 Mean`) /
                          Mean
    )

  # Getting the columns into the desired order
  full_summary <- full_summary %>%
    dplyr::select_(
      .dots = c(
        "Variable",
        "`Num Unique Values`",
        "`Non Missing`",
        "`Above 0`",
        "`Class 1 Above 0`",
        "`Class 0 Above 0`",
        "`Class 1 Zero or below`",
        "`Class 0 Zero or below`",
        "Mean",
        "`Class 1 Mean`",
        "`Class 0 Mean`",
        "`Mean Difference`",
        "Correlation",
        "`Diagnostic Odds`",
        "`Class 1 Min`",
        "`Class 1 P25`",
        "`Class 1 P50`",
        "`Class 1 P75`",
        "`Class 1 Max`",
        "`Class 0 Min`",
        "`Class 0 P25`",
        "`Class 0 P50`",
        "`Class 0 P75`",
        "`Class 0 Max`"
      )
    )

  # Checking the directories and file names and then saving

  # Checking that the directory doesn't end in '/'
  output_dir <- file.path(output_dir)

  # Checking if the output_dir exists, and making it if it doesn't
  if (!dir.exists(output_dir)) {
    dir.create(output_dir)
  }

  # Checking that the prefix parameter doesn't end in ".csv"
  if (tools::file_ext(prefix) == "csv") {
    prefix <- tools::file_path_sans_ext(prefix)
  }

  bivar_y_flag_output_file <- file.path(
    output_dir,
    paste0(prefix, "bivar_stats_y_flag.csv")
  )

  if (output_csv) {
    readr::write_csv(full_summary, bivar_y_flag_output_file)
  }

  full_summary

}

#' Create the summaries from all values of the variables
#'
#' This first helper function only calculates the summaries that are not
#' dependent on the different values of the outcome variable. This involves
#' gathering the data around the different variables, and then getting summaries
#' based on the variable groups
#'
#' @param numerical_df The numerical subset of the input data
#' @return A dataframe of the whole variable summaries
#'
bivar_stats_flag_variable_summaries <- function(numerical_df) {

  # Gathering the columns and then collecting summary statistics per variable
  numerical_df_gathered <- numerical_df %>%
    tidyr::gather_(key_col = "Variable",
                   value_col = "Values",
                   gather_cols = colnames(numerical_df))

  # Getting the variable summaries
  summary_df <- numerical_df_gathered %>%
    dplyr::group_by_("Variable") %>%
    dplyr::summarise_(`Num Unique Values` = ~n_distinct(Values),
                      `Non Missing` = ~sum(!is.na(Values)),
                      `Above 0` = ~sum(Values > 0, na.rm = TRUE),
                      Mean = ~mean(Values, na.rm = TRUE)) %>%
    dplyr::ungroup()

  summary_df
}

#' Get summaries at the different binary outcome variables
#'
#' This helper function creates all of the summaries that are dependent on the
#' binary values of the outcome variable. This is carried out in a series of
#' stages: the data must be gathered around both the numerical variables and the
#' outcome variable, then the data can be grouped at the different levels of
#' these. Some renaming and combining of column information is then required so
#' that the final columns are correct, and after the summary information is
#' calculated, this information is then reshaped into tidy format, with a single
#' row for each numerical variable. A few summaries are calculated outside this
#' procedure: the correlations are performed by only grouping on the numerical
#' varibles, and the Diagnostic Odds have to be calculated on the summary data
#' after it is in tidy format
#'
#' @param df A dataframe containing the numerical and outcome variable
#' information
#' @param variables A character vector of the numerical variables
#' @param outcome_var A character string of the outcome variable
#' @param correlation_warning Boolean. States if a warnings that can occur
#' during the correlation calculations should be hidden or not
#' @return A dataframe of all the summary information based on the different
#' levels of the outcome variable
#'
bivar_stats_flag_variable_outcome_summaries <- function(df, variables,
                                                        outcome_var,
                                                        correlation_warning) {

  # Performing double checks on the inputs
  if (!all(variables %in% colnames(df))) {
    stop("Entries in 'variables' not in the input data")
  }

  if (!outcome_var %in% colnames(df)) {
    stop("The 'outcome_var' value is not in the input data")
  }

  # Gathering the columns around the outcome variable, and changing the name of
  # the outcome variable
  df_gathered <- df %>%
    tidyr::gather_(key_col = "Variable",
                   value_col = "Values",
                   gather_cols = variables)

  new_outcome_formula <- lazyeval::interp(~paste0("Class ", var),
                                          var = as.name(outcome_var))

  df_gathered_outcome_name <- df_gathered %>%
    dplyr::mutate_(.dots = setNames(list(new_outcome_formula),
                                    outcome_var))

  # Creating the different summaries at the different levels of the outcome_var
  summary_df <- df_gathered_outcome_name %>%
    dplyr::group_by_(.dots = c("Variable", outcome_var)) %>%
    dplyr::summarise_(`Above 0` = ~sum(Values > 0, na.rm = TRUE),
                      `Zero or below` = ~sum(Values <= 0, na.rm = TRUE),
                      Mean = ~mean(Values, na.rm = TRUE),
                      Min = ~min(Values, na.rm = TRUE),
                      P25 = ~stats::quantile(Values, 0.25, na.rm = TRUE),
                      P50 = ~stats::quantile(Values, 0.5, na.rm = TRUE),
                      P75 = ~stats::quantile(Values, 0.75, na.rm = TRUE),
                      Max = ~max(Values, na.rm = TRUE))

  metric_cols <- setdiff(colnames(summary_df), c("Variable", outcome_var))

  # Gathering this information, and uniting the outcome_var and metric columns
  # then spreading to get the tidy (flat) information
  summary_gathered <- summary_df %>%
    tidyr::gather_(key_col = "Metric",
                   value_col = "SummaryValues",
                   gather_cols = metric_cols) %>%
    tidyr::unite_(col = "Headers",
                  from = c(outcome_var, "Metric"),
                  sep = " ")

  summary_spread <- summary_gathered %>%
    tidyr::spread_(key_col = "Headers",
                   value_col = "SummaryValues")


  # Getting the correlation information from the first gathered df
  correlation_summary <- get_correlation_summary(
    df_gathered,
    outcome_var,
    correlation_warning
  )

  # Putting these two summaries together
  full_summary_df <- dplyr::inner_join(
    summary_spread,
    correlation_summary,
    by = "Variable"
  )

  # Adding in the diagnostic odds
  full_summary_df <- full_summary_df %>%
    dplyr::mutate_(
      `Diagnostic Odds` = ~(`Class 1 Above 0` / `Class 0 Above 0`) /
                           (`Class 1 Zero or below` / `Class 0 Zero or below`)
    )

  full_summary_df
}

#' Get the correlation summary column
#'
#' This helper function gets the summary column for the spearman correlation.
#' An extra function is being used as it takes up a large amount of space due to
#' the fact that it is either wrapped around a suppressWarnings or not
#'
#' @param df_gathered A dataframe of the gathered summary that has already been
#' created in an earlier summary
#' @param outcome_var A character string of the outcome variable
#' @param correlation_warning Boolean. States if a warnings that can occur
#' during the correlation calculations should be hidden or not
#' @return A single column dataframe summary of the spearman correlations, set
#' to 2 decimal places
#'
get_correlation_summary <- function(df_gathered, outcome_var,
                                    correlation_warning) {

  if (correlation_warning) {
    correlation_summary <- df_gathered %>%
      dplyr::group_by_("Variable") %>%
      dplyr::do_(~broom::tidy(stats::cor.test(
        .[["Values"]],
        .[[outcome_var]],
        method = 'spearman'
      ))["estimate"]) %>%
      dplyr::rename_(Correlation = ~estimate) %>%
      dplyr::mutate_(Correlation = ~round(Correlation, digits = 2))
  } else {
    suppressWarnings(
      correlation_summary <- df_gathered %>%
        dplyr::group_by_("Variable") %>%
        dplyr::do_(~broom::tidy(stats::cor.test(
          .[["Values"]],
          .[[outcome_var]],
          method = 'spearman'
        ))["estimate"]) %>%
        dplyr::rename_(Correlation = ~estimate) %>%
        dplyr::mutate_(Correlation = ~round(Correlation, digits = 2))
    )
  }

  correlation_summary
}
