#' Check the Level Counts of a variable
#'
#' This function will check that a specified variable in a dataframe has a
#' suitable number of different unique values
#'
#' @param input_df A dataframe with the input data
#' @param variable A character string of the variable to check
#' @param count A numeric value that is the count threshold
#' @param ltgt Default \code{lt}. A character string that must take one of the
#' following values:
#' \describe{
#'   \item{lt}{The number of unique values of \code{variable} should be less
#'   than \code{count}}
#'   \item{gt}{The number of unique values of \code{variable} should be greater
#'   than \code{count}}
#' }
#' @return This will result in a warning given to the user if the conditions are
#' not met. Otherwise silent
#'
check_level_count <- function(input_df, variable, count, ltgt = "lt") {

  # Check that input_df is a dataframe
  if (!is.data.frame(input_df)) {
    stop("The 'input_df' variable must be a dataframe")
  }

  # Checking that the variable is a character
  if (!is.character(variable)) {
    stop("'variable' must be a character string'")
  }

  # Checking that count is an numeric
  if (!is.numeric(count)) {
    stop("'count' must be a numeric input")
  }

  # Checking that the ltgt function has an accepted value
  ltgt <- match.arg(ltgt, choices = c("lt", "gt"))

  # Checking that the variable is in the dataframe
  if (!(variable %in% colnames(input_df))) {
    stop("'variable' must be a column in 'input_df'")
  }

  # Getting the number of levels of the variable
  num_levels <- length(unique(input_df[[variable]]))

  if (ltgt == "lt" & num_levels > count) {
    warning_message <- sprintf(
      "The number of unique levels in '%s' is greater than %d",
      variable,
      count
    )
    warning(warning_message)
  } else if (ltgt == "gt" & num_levels < count) {
    warning_message <- sprintf(
      "The number of unique levels in '%s' is less than %d",
      variable,
      count
    )
    warning(warning_message)
  }
}


















