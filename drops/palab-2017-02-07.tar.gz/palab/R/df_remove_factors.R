#' Remove factor variable columns from a dataframe
#'
#' This function identifies any columns in a dataframe that have factor
#' datatypes, and then returns a new dataframe with these as character
#' datatypes
#'
#' @param input_df An input dataframe
#' @return A new dataframe where the factor variables as character datatypes
#'
df_remove_factors <- function(input_df) {

  output_df <- input_df
  input_factors <- vapply(input_df, is.factor, TRUE)
  output_df[input_factors] <- lapply(output_df[input_factors], as.character)

  # Converting blank strings to NA
  output_df[output_df == ""] <- NA

  output_df
}
