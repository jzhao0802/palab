#' Make dummy variables from the Categorical subset of input variables
#'
#' This function will convert all of the categorical variables from the input
#' data (as specified in \code{var_config}) into dummy/indicator variables
#' containing either the values 0 or 1. For each variable, the values will be
#' ordered either alphabetically or in an ascending numeric sequence, with the
#' first value always treated as the "baseline" value.
#'
#' @param input A dataframe of the transformed output from
#' \code{\link{read_transform}}
#' @param var_config A character string of a file path to a csv file containing
#' a summary dataframe describing the input types. The function
#' \code{\link{var_config_generator}} provides a template for this, which needs
#' to be checked by the user before use. The first column must have the header
#' \code{Column} and the second must have \code{Type}
#' @param dummy_var_config Default NULL. A character string of a file path to a
#' csv file containing a summary dataframe of the categorical variables that are
#' to be used, and a specification of the value that is to be used as the
#' 'baseline' for each of these variables. If no value is entered, then all of
#' the categorical variables will be used, and the baseline set as the lowest
#' alphanumeric value automatically by R
#' @param name_desc Default FALSE. A boolean to state if a more detailed
#' description of the new dummy variables should be saved to a file. This file
#' provides additional information on the newly created dummy variables
#' @param prefix A character string that provides the prefix for the all of the
#' output files
#' @param output_dir A character string of the path to the directory where the
#' output file is to be saved. The separator for the directories must be "/",
#' and not "\\" that is common on the Windows operating system
#' Default is current directory
#' @param output_csv A boolean to indicate if the outputs should be written
#' to the output file. Default FALSE
#' @return A list with 2 or 3 elements (dependant on a value being provided
#' for \code{name_desc}):
#' \describe{
#'   \item{dummyfied}{A new dataframe containing all of the original input
#'   variables, but with the categorical subset replaced with the dummy values}
#'   \item{var_config}{A dataframe containing the same columns as the original
#'   \code{var_config} dataframe, but with the categorical variables replaced
#'   with the names of the dummy variables}
#'   \item{name_desc}{A dataframe providing descriptions of all of the names
#'   that have been given to the new dummy variables}
#' }
#' @export dummy_vars
#'
dummy_vars <- function(input, var_config, dummy_var_config = NULL,
                       name_desc = FALSE, prefix = "", output_dir = ".",
                       output_csv = FALSE) {

  # Performing some checks on the inputs
  if (missing(input) || !is.data.frame(input)) {
    stop("A dataframe is required for the 'input'argument")
  }

  if (missing(var_config) || !is.character(var_config) ||
      length(var_config) != 1) {
    stop("'var_config' must be a character string input")
  }

  if (!file.exists(var_config)) {
    var_config_file_error <- sprintf(
      "No 'var_config' file found at '%s'", var_config
    )
    stop(var_config_file_error)
  }

  # Checking the input for dummy_var_config if one has been entered
  if (!is.null(dummy_var_config)) {
    if (!is.character(dummy_var_config) || length(dummy_var_config) != 1) {
      stop("'dummy_var_config' must be a character string input")
    }

    if (!file.exists(dummy_var_config)) {
      dummy_var_config_file_error <- sprintf(
        "No 'dummy_var_config' file found at '%s'", dummy_var_config
      )
      stop(dummy_var_config_file_error)
    }
  }

  if (!is.logical(name_desc) || length(name_desc) != 1 || is.na(name_desc)) {
    stop("'name_desc' argument must be a single value of TRUE or FALSE")
  }

  if (!is.character(prefix) || length(prefix) != 1) {
    stop("'prefix' argument must be a character string")
  }

  if (!is.character(output_dir) || length(output_dir) != 1) {
    stop("'output_dir' argument must be a character string of the save path")
  }

  if (!is.logical(output_csv) || length(output_csv) != 1 || is.na(output_csv)) {
    stop("'output_csv' argument must be a single value of TRUE or FALSE")
  }

  # Loading in the var_config dataframe and checking column names
  var_config <- suppressMessages(readr::read_csv(var_config))
  if (!all(c("Column", "Type") %in% colnames(var_config))) {
    stop(
    "The var_config dataframe must contain the columns 'Column' and 'Type'"
    )
  }

  # Removing any possible factor columns from the input dataframes
  # While factors will be used later for the analysis, this is done to ensure
  # that no errors occur when subsetting the data
  input <- df_remove_factors(input)
  var_config <- df_remove_factors(var_config)

  # Splitting the inputs into numerical, categorical, key, and 'other'
  input_key <- get_key_variable(input, var_config)
  input_other <- get_all_other_variables(input, var_config)
  input_numerical <- get_numerical_variables(input, var_config)
  input_categorical <- get_categorical_variables(input, var_config)

  # Check that there are some categorical variables and raising error if there
  # are none
  if (ncol(input_categorical) == 0) {
    stop("There are no categorical variables present")
  }


  # Checking that none of the categories has only 1 unique value, as these
  # cannot be converted into dummy variables. A warning will be given that
  # these columns are being removed, but an error will occur if all of the
  # categorical variables contain only unique values
  is_unique_categorical <- vapply(
    input_categorical,
    function(x) {length(unique(stats::na.omit(x))) == 1},
    TRUE
  )

  if (all(is_unique_categorical)) {
    stop("All of the categorical variables contain only unique values")
  }

  if (any(is_unique_categorical)) {
    problem_unique_cols <- colnames(input_categorical)[is_unique_categorical]
    problem_unique_cols_quotes <- paste0(
      "'",
      problem_unique_cols,
      "'"
    )
    problem_unique_cols_string <- paste(
      problem_unique_cols_quotes,
      collapse = ", "
    )
    problem_unique_cols_message <- sprintf(
      "Column(s) %s removed due to unique values (not possible for dummy vars)",
      problem_unique_cols_string
    )

    # Removing these columns from input_categorical
    input_categorical <- input_categorical[!is_unique_categorical]
    warning(problem_unique_cols_message)
  }

  # All the analysis and column name creation requires that the values of the
  # categorical variables are converted to factors.
  # The different variables and factor levels will be chosen based on whether
  # a dummy_var_config parameter was entered or not
  if (!is.null(dummy_var_config)) {
    factor_categorical <- select_vars_and_change_reference(
      input_categorical,
      dummy_var_config
    )
  } else {
    factor_categorical <- dplyr::as_data_frame(
      lapply(input_categorical, factor)
    )
  }

  # Setting any NA values to an explicit level called "missing"
  factor_categorical <- dplyr::as_data_frame(
    lapply(
      factor_categorical,
      function(x) {
        forcats::fct_explicit_na(x, na_level = "missing")
      }
    )
  )


  # Getting the dummy names for all of the different variables
  # This is done using lapply and therefore creates a nested list, which
  # extracted afterwards
  all_dummy_names_list <- lapply(
    colnames(factor_categorical),
    get_dummy_names,
    factor_df = factor_categorical
  )

  # Converting all the main list elements to dataframes, then binding together
  # by row to get the final information
  all_dummy_names_dfs <- lapply(
    all_dummy_names_list,
    dplyr::as_data_frame
  )

  # The bind_rows function in dplyr automatically aligns by column name
  # just in case they are not in order
  all_dummy_info_df <- dplyr::bind_rows(all_dummy_names_dfs)

  # Getting the dummy variables and setting the correct names
  dummy_df <- get_dummy_variables(factor_categorical)
  colnames(dummy_df) <- all_dummy_info_df$var_values

  # Combining this back with the numerical variables
  dummyfied_df <- dplyr::bind_cols(input_key,
                                   input_other,
                                   input_numerical,
                                   dummy_df)

  # Making the changes to the var_config file
  dummy_var_config_output <- change_var_config(
    var_config_orig = var_config[c("Column", "Type")],
    new_categorical_values = all_dummy_info_df$var_values
  )

  # Getting the description file if required
  if (name_desc) {
    name_desc_df <- dplyr::data_frame(
      Var = all_dummy_info_df$var_values,
      Name = all_dummy_info_df$name_values,
      Desc = all_dummy_info_df$desc_values
    )

    dummy_return_list <- list(dummyfied = dummyfied_df,
                              var_config = dummy_var_config_output,
                              name_desc = name_desc_df)
  } else {
    dummy_return_list <- list(dummyfied = dummyfied_df,
                              var_config = dummy_var_config_output)
  }

  # Writing out the files. The new dummyfied var_config info is always written
  # out, and all the other files are written if output_csv == TRUE
  output_dir <- file.path(output_dir)

  # Checking if the output_dir exists, and making it if it doesn't
  if (!dir.exists(output_dir)) {
    dir.create(output_dir, recursive = TRUE)
  }

  if (tools::file_ext(prefix) == "csv") {
    prefix <- tools::file_path_sans_ext(prefix)
  }

  dummy_var_config_df_output <- paste0(prefix, "var_config_dummyfied.csv")
  dummy_var_config_df_path <- file.path(output_dir,
                                        dummy_var_config_df_output)
  readr::write_csv(dummy_var_config_output, dummy_var_config_df_path)

  if (output_csv) {
    dummyfied_df_output <- paste0(prefix, "dummyfied.csv")
    dummyfied_df_path <- file.path(output_dir, dummyfied_df_output)

    readr::write_csv(dummyfied_df, dummyfied_df_path)

    if (name_desc) {
      name_desc_df_output <- paste0(prefix, "name_desc_dummyfied.csv")
      name_desc_df_path <- file.path(output_dir, name_desc_df_output)

      readr::write_csv(name_desc_df, name_desc_df_path)
    }
  }

  dummy_return_list
}

#' Get the name information for the dummy variables
#'
#' This function will create the names that are used for the new dummy
#' variables; made by combining the variable names with the levels.
#' This function also provides the descriptions that are required if
#' \code{name_desc} is not FALSE
#' @param column_name A character string of the column name of the variable
#' that is to be given new dummy names
#' @param factor_df A dataframe of the categorical inputs. IMPORTANT: all of the
#' values in this dataframe MUST be factors
#' @return A list containing character vectors with the following names:
#' \describe{
#'   \item{var_values}{These are the same as the column names that will feature
#'   in the output dataframe}
#'   \item{name_values}{A short description of each dummy variable}
#'   \item{desc_values}{A longer description of each dummy variable}
#' }
#'
get_dummy_names <- function(column_name, factor_df) {

  # Extracting the name and level information from the column
  column_data <- factor_df[[column_name]]
  column_levels <- levels(column_data)
  baseline <- column_levels[1]
  comparisons <- column_levels[2:length(column_levels)]
  var_columns <- paste(column_name, comparisons, baseline, sep = "_")
  name_columns <- paste0(
    column_name,
    ": ",
    comparisons,
    " vs ",
    baseline
  )
  desc_columns <- paste0(
    "Categorical variable: ",
    column_name,
    ", ",
    "level ",
    comparisons,
    " vs level ",
    baseline
  )

  # Putting all of this information into a list, converting the factor data
  # types back to character vectors

  list(
    var_values = as.character(var_columns),
    name_values = as.character(name_columns),
    desc_values = as.character(desc_columns)
  )
}

#' Get the dummy varibles from the categorical subset of the data
#'
#' This function actually makes the conversion between the categorical levels
#' and the dummy variables. It is essentially that all of the data in the
#' columns contains factors. This works by first creating a model frame, using
#' a function from the stats module, which allows for the correct treatment of
#' NA values to be specified. Then another function from the stats module,
#' model.matrix, can be used to get the dummy variables for the whole factor
#' frame. This is the function that is used "under the hood" to prepare factor
#' variables for analysis in many R models. Of note, the correct output is
#' obtained when the R "contrasts" setting is "treatment". This is the default,
#' but it is explicitly stated here just in case the global environment has
#' been changed at all
#'
#' @param factor_df A dataframe of the categorical subset of the variables (as
#' designated by \code{var_config}) with the data in each column as a factor
#' @param remove_intercept A boolean value. Default TRUE. As the model.matrix
#' function always provides an "Intercept" column as the first column, this
#' parameter states if it should be removed
#' @return A dataframe with the categorical variables replaced with dummy
#' variables
#'
get_dummy_variables <- function(factor_df, remove_intercept = TRUE) {

  # Getting all of the contrasts using model.matrix. Then assigining
  # to a dataframe, and removing the intercept, which is always the 1st column
  model_df <- dplyr::as_data_frame(
    stats::model.matrix(~ ., factor_df, contrasts.arg = "treatment")
  )

  # Removing the intercept if required. First getting the index of the intercept
  # column, which really should be 1 - but worth checking
  if (remove_intercept) {
    intercept_index <- grep(".*[Ii]ntercept.*", colnames(model_df))
    model_df <- model_df[, -intercept_index]
    if (intercept_index != 1) {
      warning(
        "The first column was not the intercept. Please check your output"
      )
    }
  }

  model_df
}

#' Replace categorical variables in var_config with the dummy variables
#'
#' This function swaps out the original categorical variable names and returns
#' a new var_config dataframe with the new names of the dummy variables to
#' represent the categorical variables
#'
#' @param var_config_orig The original \code{var_config} dataframe, originally
#' adapted from the output from \code{var_config_generator} and entered
#' into the main \code{dummy_vars} function
#' @param new_categorical_values A character vector of the names used as the
#' column names for the new dummy variables
#' @return A dataframe with the same 2 column as \code{var_config}, but with
#' the names of the categorical variables swapped out for the new dummy
#' variable names
#'
change_var_config <- function(var_config_orig, new_categorical_values) {

  # Removing the categorical variables from the original var_config
  var_config_no_cat <- var_config_orig %>%
    dplyr::filter_(~Type != "categorical")

  var_config_cat <- dplyr::data_frame(
    Column = new_categorical_values,
    Type = "categorical"
  )

  new_var_config <- dplyr::bind_rows(
    var_config_no_cat,
    var_config_cat
  )

  new_var_config
}

#' Select categorical variables and set the reference level value
#'
#' This function is only used if the user has entered a value for the
#' 'dummy_var_config' parameter. This file will be loaded and checked to make
#' sure that it contains the correct relevant information. The column names must
#' be 'ColumnName' and 'ReferenceCategory'. It will then check that all the
#' variables listed appear in the categorical dataset, and will raise an error
#' if not
#'
#' @param input_categorical The categorical subset of the input data
#' @param dummy_var_config A character string with the path to the
#' dummy_var_config dataframe
select_vars_and_change_reference <- function(input_categorical,
                                             dummy_var_config) {

  # Reading in the dummy_var_config dataframe and checking column names
  dvc_df <- suppressMessages(
    readr::read_csv(dummy_var_config)
  )

  if (!all(colnames(dvc_df) %in% c("ColumnName",
                                  "ReferenceCategory"))) {
    dvc_column_error <- paste(
      "The column names in the 'dummy_var_config' dataframe must be:",
      "'ColumnName' and 'ReferenceCategory'"
    )
    stop(dvc_column_error)
  }

  dvc_df$ReferenceCategory <- as.character(dvc_df$ReferenceCategory)

  # Checking that all ColumnNames are in the original data
  wrong_vars <- !(dvc_df$ColumnName %in% colnames(input_categorical))

  if (any(wrong_vars)) {
    wrong_var_names <- dvc_df$ColumnName[wrong_vars]
    raise_quoted_error(
      wrong_var_names,
      "appear in 'dummy_var_config' but not in the input dataframe"
    )
  }

  # Removing any variable from the input if they are not in dummy_var_config
  input_categorical <- input_categorical %>%
    dplyr::select_(.dots = dvc_df$ColumnName)

  # Converting to factors
  factor_categorical <- dplyr::as_data_frame(
    lapply(input_categorical, factor)
  )

  # Releveling those that require different reference values
  if (!all(is.na(dvc_df$ReferenceCategory))) {
    dvc_df_relevels <- dvc_df %>%
      dplyr::filter_(~!is.na(ReferenceCategory))

    # Checking for invalid reference levels
    input_categorical <- input_categorical %>%
      tidyr::gather_(
        key_col = "ColumnName",
        value_col = "ReferenceCategory",
        gather_cols = colnames(input_categorical)
      ) %>%
      dplyr::mutate_(ReferenceCategory = ~as.character(ReferenceCategory))

    joined_data <- dplyr::inner_join(
      input_categorical,
      dvc_df_relevels,
      by = c("ColumnName", "ReferenceCategory")
    )

    wrong_var_levels <- dplyr::setdiff(
      dvc_df_relevels$ColumnName,
      unique(joined_data$ColumnName)
    )

    if (length(wrong_var_levels) != 0) {
      raise_quoted_error(
        wrong_var_levels,
        "variables contain invalid values in 'dummy_var_config'"
      )
    }

    for (i in seq_len(nrow(dvc_df_relevels))) {
      var_name <- dvc_df_relevels$ColumnName[i]
      ref_level <- dvc_df_relevels$ReferenceCategory[i]
      factor_categorical[var_name] <- forcats::fct_relevel(
        factor_categorical[[var_name]], ref_level
      )
    }
  }

  factor_categorical
}
