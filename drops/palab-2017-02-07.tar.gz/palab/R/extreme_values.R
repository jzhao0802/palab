#' Replace extreme values in numerical variables
#'
#' This function will replace the extreme values in the numerical subset of the
#' input data. The limit will either be defined as a global percentile, that is
#' applied to all of the numerical variables, or an additional file can
#' be loaded in to determine if any of the variables require either custom
#' thresholds, or should be immune to the global percentile threshold
#'
#' @param input A dataframe of the transformed output from \code{read_transform}
#' @param var_config A summary dataframe describing the input types. The
#' function \code{\link{var_config_generator}} provides a template for this,
#' which needs to be checked by the user before use. The first column
#' must have the header \code{Column} and the second must have \code{Type}
#' @param pth A numerical value between 0 and 1 that determines the quantile
#' value of the threshold \eqn{(percentile / 100)}
#' @param ex_val_thrsh A character string with the path to information about
#' custom treatment of any numerical variables. This must be a comma separated
#' file, containing 2 columns with the following names and information:
#' \describe{
#'   \item{Variable}{The name of the numerical variable. All of these must
#'   feature in the \code{input} dataframe}
#'   \item{Thrsh}{A numerical value which represents a user-defined threshold
#'   at which the variable should be capped. A flag of "N" indicates that the
#'   variable should not be capped}
#' }
#' If left as the default value as NULL, the assumption is made that all
#' variables should be capped at the global value
#' @param prefix A character string of the prefix that will be given to the
#' file where the outputs will be saved
#' @param output_dir A character string of the path to the directory where the
#' output file is to be saved. The separator for the directories must be "/",
#' and not "\\" that is common on the Windows operating system
#' Default is current directory
#' @param output_csv A boolean to indicate if the outputs should be written
#' to the output file
#' @return A list with the following either 1 or 2 dataframes. If there is no
#' file specified for \code{ex_val_thrsh}, then only the \code{data} value is
#' in the list
#' \describe{
#'   \item{data}{The transformed data with the capped values}
#'   \item{report}{A dataframe of the variable names and the value that
#'   they were capped at}
#' }
#' @examples
#' \dontrun{
#' extreme_values(input = transformed_df, var_config = var_config,
#'                pth = 0.99, ex_val_thrsh = "ex_val_thrsh.csv",
#'                prefix = "capped_data", output_dir = "data",
#'                output_csv = TRUE)
#' }
#' @export extreme_values
#'
extreme_values <- function(input, var_config, pth = 0.99, ex_val_thrsh = NULL,
                           prefix = "", output_dir = ".", output_csv = FALSE) {

  # Performing some checks on the inputs
  if (missing(input) || !is.data.frame(input)) {
    stop("A dataframe is required for the 'input'argument")
  }

  if (missing(var_config) || !is.character(var_config) ||
      length(var_config) != 1) {
    stop("'var_config' must be a character string input")
  }

  if (!file.exists(var_config)) {
    var_config_file_error <- sprintf(
      "No 'var_config' file found at '%s'", var_config
    )
    stop(var_config_file_error)
  }

  if (!is.numeric(pth) || length(pth) != 1) {
    stop("The 'pth' argument must be a numeric between 0 and 1")
  }

  # Checking that pth makes logical sense
  if (pth < 0 | pth > 1) {
    stop("The 'pth' argument must be between 0 and 1")
  }

  # Carrying out the required checks on any ex_val_thrsh file if it is present
  if (!is.null(ex_val_thrsh)) {
    if (!is.character(ex_val_thrsh) || length(ex_val_thrsh) != 1) {
      stop("'ex_val_thrsh' must be a character string input")
    }
    if (file.exists(ex_val_thrsh)) {
      loaded_thrsh_df <- readr::read_csv(ex_val_thrsh)

      # The following function performs the checks and returns a copy of
      # thrsh_df with any modifications that may have had to be performed
      thrsh_df <- check_thrsh_df(
        thrsh_df = loaded_thrsh_df,
        input = input,
        file_name = ex_val_thrsh
      )
    } else {
      thrsh_file_error <- sprintf(
        "The file: '%s' does not exist", ex_val_thrsh
      )
      stop(thrsh_file_error)
    }
  } else {
    thrsh_df <- NULL
  }

  if (!is.character(prefix) || length(prefix) != 1) {
    stop("'prefix' argument must be a character string")
  }

  if (!is.character(output_dir) || length(output_dir) != 1) {
    stop("'output_dir' argument must be a character string of the save path")
  }

  if (!is.logical(output_csv) || length(output_csv) != 1 || is.na(output_csv)) {
    stop("'output_csv' argument must be a single value of TRUE or FALSE")
  }

  # Loading in the var_config dataframe and checking column names
  var_config <- suppressMessages(readr::read_csv(var_config))
  if (!all(c("Column", "Type") %in% colnames(var_config))) {
    stop(
    "The var_config dataframe must contain the columns 'Column' and 'Type'"
    )
  }

  # Removing any possible factor columns from the input dataframes
  # Using a function from a different file
  input <- df_remove_factors(input)
  var_config <- df_remove_factors(var_config)

  # Transforming the data. The following function returns a list
  transform_output_list <- threshold_transform(
    input = input,
    var_config = var_config,
    pth = pth,
    thrsh_df = thrsh_df
  )

  # Writing these outputs to a file if required
  if (output_csv) {
    write_extreme_values(transform_output_list, prefix, output_dir)
  }

  transform_output_list
}

#' Calculate the capped values after checks have been completed
#'
#' This function performs the initial steps needed for the capping
#' transformation. It then passes on the remainder to different helper
#' functions dependant on whether there are custom thresholds or not
#'
#' @param input A dataframe of the transformed output from \code{read_transform}
#' @param var_config The dataframe with the datatypes information
#' @param pth A numeric between 0 and 1. The value of the global quantile
#' threshold
#' @param thrsh_df A dataframe of any custom thresholds for different values. If
#' there are none, then the default if NULL
#'
threshold_transform <- function(input, var_config,
                                pth, thrsh_df = NULL) {

  # Splitting the input into numerical, categorical, other, and key
  input_numerical <- get_numerical_variables(input, var_config)
  input_categorical <- get_categorical_variables(input, var_config)
  input_other <- get_all_other_variables(input, var_config)
  input_key <- get_key_variable(input, var_config)

  # Raising an error if there are no numerical variables, as it does not make
  # any sense to run this function if there aren't any
  if (ncol(input_numerical) == 0) {
    stop("There are no numerical variables present")
  }


  # The key is then set to an ordered factor to preserve the order
  # This is possible due to it having unique values
  key_name <- colnames(input_key)[1]
  input_key[key_name] <- factor(input_key[[key_name]],
                                levels = input_key[[key_name]])

  # Adding the key information to the numerical variables
  num_key <- dplyr::bind_cols(input_key, input_numerical)

  # Gathering this information around the numerical variables
  num_key_gathered <- num_key %>%
    tidyr::gather_(key_col = "Variable",
                   value_col = "Value",
                   gather_cols = colnames(input_numerical))

  # Setting the max quantile value per variable
  num_key_gathered_quantile <- num_key_gathered %>%
    dplyr::group_by_("Variable") %>%
    dplyr::mutate_(Quantile = ~stats::quantile(Value, pth, na.rm = TRUE)) %>%
    dplyr::ungroup()

  # Getting the different numerical summaries based on whether there are
  # custom values or not
  if (is.null(thrsh_df)) {
    transformed_numerical <- transform_only_quantiles(
      input_quantile = num_key_gathered_quantile,
      key_name = key_name
    )
  } else {
    transformed_numerical_output <- transform_with_custom_values(
      input_quantile = num_key_gathered_quantile,
      thrsh_df = thrsh_df,
      key_name = key_name
    )
    # The output is a list, so the data is extracted
    transformed_numerical <- transformed_numerical_output$data
    capped_values <- transformed_numerical_output$report
  }


  # Incorporating this back in with the categorical variables
  transformed_input <- dplyr::bind_cols(
    transformed_numerical,
    input_categorical,
    input_other
  )

  # Getting the columns back into the original order
  transformed_input <- transformed_input[colnames(input)]

  # Setting the output list based on whether the report is needed or not
  if (is.null(thrsh_df)) {
    output_list <- list(data = transformed_input)
  } else {
    output_list <- list(data = transformed_input,
                        report = capped_values)
  }

  output_list
}

#' Perform transformations with only the global quantile threshold
#'
#' This function carries out the transformation that limits all of the
#' numerical variables to their values based on the global quantile
#'
#' @param input_quantile A dataframe of the inputs, gathered around the
#' numerical variable names, with a column of the cutoff values for these
#' inputs based on the global quantile
#' @param key_name A character string of the name given to the key column
#' in the input data
#'
transform_only_quantiles <- function(input_quantile, key_name) {

  # Making a new column with the capped values
  input_quantile_capped <- input_quantile %>%
    dplyr::mutate_(Max_value = ~ifelse(Value <= Quantile, Value, Quantile))

  # Making a vector of the columns to retain before spreading
  # This next function will add backticks to the key name if needed
  keep_columns <- c(key_name, "Variable", "Max_value")

  # The next line adds backticks to any variables that could contain
  # problem characters like spaces or hyphens
  keep_columns <- lapply(keep_columns, as.name)

  # Keeping only these columns and then spreading the output
  input_capped_spread <- input_quantile_capped %>%
    dplyr::select_(.dots = keep_columns) %>%
    tidyr::spread_(key_col = "Variable",
                   value_col = "Max_value")

  # Finally setting the key column to be a character datatype again
  input_capped_spread[key_name] <- as.character(input_capped_spread[[key_name]])

  input_capped_spread
}

#' Perform the transformations with the additional custom thresholds
#'
#' This function transforms the data, based on the global quantile threshold
#' and with the additional custom inputs for certain variables in thrsh_df
#'
#' @param input_quantile A dataframe of the inputs, gathered around the
#' numerical variable names, with a column of the cutoff values for these
#' inputs based on the global quantile
#' @param thrsh_df A dataframe of the checked values for the custom
#' threshold values
#' @param key_name A character string of the name given to the key column
#' in the input data
#'
transform_with_custom_values <- function(input_quantile, thrsh_df, key_name) {

  # Setting any "N" flags in thrsh_df to be Inf
  thrsh_df <- thrsh_df %>%
    dplyr::mutate_(Max_value = ~as.numeric(ifelse(Thrsh == "N", Inf, Thrsh)))

  # Making a full join of this information with the inputs
  inputs_and_thrsh <- dplyr::full_join(
    input_quantile,
    thrsh_df,
    by = "Variable"
  )

  # This results in NAs in the Thrsh and Max_value columns, which are now set
  # to be the quantiles
  inputs_and_thrsh_all_quantiles <- inputs_and_thrsh %>%
    dplyr::mutate_(
      Thrsh = ~ifelse(is.na(Thrsh), Quantile, Thrsh),
      Max_value = ~ifelse(is.na(Max_value), Quantile, Max_value)
    )

  # Getting the information from this about the capping values
  capped_values_summary <- inputs_and_thrsh_all_quantiles %>%
    dplyr::select_(.dots = c("Variable", "Thrsh"))

  # Removing the many duplicate rows
  capped_values_summary <-
    capped_values_summary[!duplicated(capped_values_summary),]

  # Selecting the columns to keep - one of these will be made in the next
  # operation
  keep_columns <- c(key_name, "Variable", "Final_max")

  # Getting the final maximum - custom value or quantile
  inputs_and_thrsh_final_max <- inputs_and_thrsh_all_quantiles %>%
    dplyr::mutate_(
      Final_max = ~ifelse(Value <= Max_value, Value, Max_value)
    ) %>%
    dplyr::select_(.dots = keep_columns)

  # Spreading this to get the final output and then setting the key column
  # to have character datatypes again
  custom_limit_summary <- inputs_and_thrsh_final_max %>%
    tidyr::spread_(key_col = "Variable",
                   value_col = "Final_max")

  custom_limit_summary[key_name] <-
    as.character(custom_limit_summary[[key_name]])

  list(data = custom_limit_summary, report = capped_values_summary)
}

#' Check the inputs of the data in the ex_val_thrsh file
#'
#' This function carries out the required tests on the ex_val_thrsh dataframe
#' resulting in either errors or warnings:
#' \describe{
#'   \item{Not 2 columns}{Error}
#'   \item{No rows of data}{Error}
#'   \item{Not using stated columns names}{Warning}
#'   \item{Variable not in the input dataframe}{Error}
#' }
#'
#' @param thrsh_df A dataframe with the custom threshold values
#' @param file_name A character string of the file and path that was used to
#' create \code{thrsh_df}
#' @param input A dataframe of the input values - the output from the
#' \code{read_transform} function
#' @return A dataframe of thrsh_df. If the column names were correct, this will
#' not have changed, but if they were (raising a warning), then this new
#' dataframe will have the correct columns
#'
check_thrsh_df <- function(thrsh_df, file_name, input) {

  # Checking the columns of the dataframe
  if (ncol(thrsh_df) != 2) {
    column_error <- sprintf(
      "The information in '%s' does not contain 2 columns", file_name
    )
    stop(column_error)
  }

  # Checking the rows of the dataframe
  if (!(nrow(thrsh_df) > 0)) {
    row_error <- sprintf(
      "The information in '%s' does not contain any rows of data", file_name
    )
    stop(row_error)
  }

  # Checking the names of the columns, and raising a warning if these are wrong
  correct_names <- c("Variable", "Thrsh")

  if (!all(colnames(thrsh_df) == correct_names)) {
    colname_warning <- sprintf(
      "The column names in %s data have been changed to 'Variable' and 'Thrsh'",
      file_name
    )
    colnames(thrsh_df) <- correct_names
    warning(colname_warning)
  }

  # Checking that all of the Variables in the thrsh_df are in the dataset
  present_in_input <- thrsh_df$Variable %in% colnames(input)

  if (any(!present_in_input)) {
    problem_vars <- thrsh_df$Variable[!present_in_input]
    problem_vars_quoted <- paste0("'", problem_vars, "'")
    problem_var_string <- paste(problem_vars_quoted, collapse = ", ")
    variable_error <- sprintf(
      "The following variables in '%s' are not present in the input data: %s",
      file_name,
      problem_var_string
    )
    stop(variable_error)
  }

  thrsh_df
}

write_extreme_values <- function(output_list, prefix, output_dir) {

  # Check if the directory exists, and making it if not
  output_dir <- file.path(output_dir)
  if (!dir.exists(output_dir)) {
    dir.create(output_dir)
  }

  # Checking that the prefix variable doesn't have a file ending
  if (tools::file_ext(prefix) == "csv") {
    prefix <- tools::file_path_sans_ext(prefix)
  }

  # Adding on the required suffices, making the path and saving
  if (length(output_list) == 2) {

    # Writing the data first
    data_output <- paste(prefix, "ex.csv", sep = "_")
    data_output_path <- file.path(output_dir, data_output)
    readr::write_csv(output_list$data, data_output_path)

    # Writing the report
    report_output <- paste(prefix, "ex_val_thrsh_out.csv", sep = "_")
    report_output_path <- file.path(output_dir, report_output)
    readr::write_csv(output_list$report, report_output_path)
  } else {

    # Just writing the data
    data_output <- paste(prefix, "ex.csv", sep = "_")
    data_output_path <- file.path(output_dir, data_output)
    readr::write_csv(output_list$data, data_output_path)
  }
}
