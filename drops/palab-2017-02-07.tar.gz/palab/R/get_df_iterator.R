#' Get iterators of pairwise columns of a dataframe
#'
#' This function creates an iterator object that returns the pairwise column
#' subsets of a dataframe. This allows for faster analysis of all the different
#' pairwise combinations of columns in a dataframe. The function can accept
#' matrices that either contain 2 or 3 columns depending on whether an outcome
#' variable is to be included in the output or not
#'
#' @param column_pairs A matrix containing the column pairs that are to be
#' extracted from the \code{df} and output in the iterator. These can also
#' contain the outcome variable as a column
#' @param df A dataframe containing the date variable information, either with
#' or without a outcome variable column
#' @return An iterator that returns a new pairwise combination of a dataframe
#' See documentation for the 'iterpc' and 'iterations' packages
#'
#'
get_df_iterator <- function(column_pairs, df) {

  # Creating the wrapper iterator function
  df_iterator <- function(pairs, df) {

    # Creating an iterator of the column pairs
    pairs_it <- iterators::iter(pairs, by = "row")

    # Making the custom iterator
    nextEl <- function() {
      # Get the next pair from the iterator of column pairs
      next_cols <- iterators::nextElem(pairs_it)

      # Selecting these columns from the dataframe and returning this subset
      return_df <- df[, c(next_cols)]

      return_df
    }

    # Returning this wrapped function as an iter object
    obj <- list(nextElem = nextEl)
    class(obj) <- c("df_iterator", "abstractiter", "iter")

    obj
  }

  # Creating an instance of the iterator, and return this from the function
  it <- df_iterator(column_pairs, df)

  it
}
