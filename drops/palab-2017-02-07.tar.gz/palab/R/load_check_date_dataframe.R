#' Load in the event data and check that it contains date information
#'
#' This function loads in the file that should contain the date information.
#' It also requires information about which columns do not contain dates, in
#' addition to which values should be treated as missing values. It then
#' isolates out the columns that should contain dates, and checks to see if
#' readr::read_csv has indeed parsed them as dates. If it has not, then an error
#' is raised, as the dates in the file should be in ISO8601 format.
#'
#' @param event_dates A character string. The same that is entered into the main
#' function
#' @param user_missing_values A character vector of all the values in the csv
#' file to be treated as missing values when loading and parsing. This is
#' processing in the main function
#' @param id_column A character string of the name of the id column
#' @param outcome_var A character string of the outcome variable if present. The
#' default value is NULL if there is not outcome variable in the data
#'
load_check_date_dataframe <- function(event_dates,
                                      user_missing_values = c("", "NA"),
                                      id_column,
                                      outcome_var = NULL) {

  # Reading in the data and checking that all columns other than the identifier
  # and outcome_var (if present) are in date format
  event_dates_df <- suppressMessages(
    readr::read_csv(event_dates, na = user_missing_values)
  )

  # Checking that the id_column is in the dataframe
  if (!(id_column %in% colnames(event_dates_df))) {
    id_column_error <- sprintf("The column '%s' is not in the data", id_column)
    stop(id_column_error)
  }

  # Checking that the outcome_var is in the dataframe if it has been entered
  if (!is.null(outcome_var) && !(outcome_var %in% colnames(event_dates_df))) {
    outcome_var_column_error <- sprintf(
      "The column '%s' is not in the data", outcome_var
    )
    stop(outcome_var_column_error)
  }

  # Checking that the outcome_var is binary if present
  if (!is.null(outcome_var)) {
    outcome_var_values <- unique(event_dates_df[[outcome_var]])
    if (!all(outcome_var_values %in% c(0, 1))){
      stop("The 'outcome_var' column does not contain only 0 and 1 values")
    }
  }

  if (!is.null(outcome_var)) {
    date_cols_indices <- colnames(event_dates_df) %in% c(id_column, outcome_var)
    date_cols <- colnames(event_dates_df)[!date_cols_indices]
  } else {
    date_cols_indices <- colnames(event_dates_df) %in% c(id_column)
    date_cols <- colnames(event_dates_df)[!date_cols_indices]
  }

  date_df <- event_dates_df %>%
    dplyr::select_(.dots = date_cols)

  # Checking that all of the columns are dates
  date_types <- vapply(date_df, lubridate::is.Date, TRUE)

  if (!all(date_types)) {
    wrong_date_message <- paste0(
      "Date columns not parsing as dates.",
      " Check missing values and date format\n",
      "and if there is an outcome variable present"
    )
    stop(wrong_date_message)
  }

  event_dates_df
}
