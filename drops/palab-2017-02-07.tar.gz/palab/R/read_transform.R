#' Transform and check the dataset for further analysis
#'
#' This function carries out the series of checks in the Outline
#'
#' @param input_csv Character string of full path to input data in .csv
#' format. The file must be comma separated, with the top line as the variable
#' names, and it must not contain a column of row names or numbers.
#' @param var_config_csv Character string of a full path to a .csv file
#' outlining the data types of the columns in \code{input_csv}. The first column
#' must have the header \code{Column} and the second must have \code{Type}
#' @param missing_values A comma separated character string with all of the
#' values that are to be considered as missing data. Whitespace is accepted.
#' Default is an empty character string if no coding for missing values is
#' required. An error will be thrown if this contains any missing values
#' eg \code{"-99,,-999"}
#' @param max_levels Int. The maximum number of unique levels that can be
#' present in any variable that is labelled as "categorical". Default 100
#' @param prefix Character string to use as the prefix of the output .csv file.
#' Default "transformed_data"
#' @param output_dir Character string of the directory to save the outputs.
#' Default "."
#' This must be written using "/" to separate the directories, and not "\\" as
#' is practice on the Windows operating system.
#' @param output_csv Boolean. States if the output is to be saved or not.
#' Default FALSE
#' @param outcome_var A character string of the name of any column that is to
#' be used as the outcome variable. Default NULL.
#' @param use_base_loading A logical value to select if the base R read.csv
#' should be used instead of readr::read_csv. This is due to an unfortunate
#' error that is occurring with large datasets
#' @return A list with the following elements
#' \describe{
#'   \item{data}{The transformed output from the function}
#'   \item{report}{The report of the transformations that were made}
#' }
#' @examples
#' \dontrun{
#' read_transform(input_csv = "mtcars.csv", var_config_csv = "var_config.csv",
#'                missing_values = "-99, -999", output_csv = TRUE,
#'                output_dir = "data")
#' }
#' @export read_transform
#'
read_transform <- function(input_csv, var_config_csv, missing_values = "",
                           max_levels = 100, prefix = "transformed_data",
                           output_dir = ".", output_csv = FALSE,
                           outcome_var = NULL, use_base_loading = FALSE){


  # Check that the user has entered values for input_csv and var_config
  # This is done in a separate function as there are many checks
  check_input_file_variables(input_csv, var_config_csv)

  # Doing the checks on the other input variables
  if (!is.numeric(max_levels) || length(max_levels) == 0) {
    stop("'max_levels' argument must be a numeric whole number")
  }
  if(is.numeric(max_levels) & max_levels %% 1 != 0) {
    stop("'max_levels' argument must be a numeric whole number")
  }
  if (!is.character(missing_values) || is.null(missing_values) ||
      is.na(missing_values) || length(missing_values) != 1) {
    stop("'missing_values' argument must be a character string")
  }
  if (!is.character(prefix) || is.null(prefix) || is.na(prefix) ||
      length(prefix) != 1) {
    stop("'prefix' argument must be a character string")
  }
  if (!is.character(output_dir) || is.null(output_dir) || is.na(output_dir) ||
      length(output_dir) != 1) {
    stop("'output_dir' argument must be a character string")
  }
  if (!is.logical(output_csv) || length(output_csv) != 1 ||
      is.na(output_csv) || is.null(output_csv)) {
    stop("'output_csv' argument must be either TRUE or FALSE")
  }
  if ((!is.null(outcome_var) & !is.character(outcome_var) &
      length(outcome_var) > 0)) {
    stop("If entering a value for 'outcome_var', it must be a character string")
  }

  # Splitting missing value string and removing whitespace
  user_missing_values <- strsplit(missing_values, split = ',')[[1]]
  user_missing_values <- trimws(user_missing_values)

  # Raising an error is any of these are empty values
  if (any(nchar(user_missing_values) == 0)) {
    stop("'missing_values' contains empty values")
  }

  # Adding NA and empty string to this list (to keep with readr standard)
  all_missing_values <- c("", "NA", user_missing_values)


  # Reading in the data silently
  if (!use_base_loading) {
    input_df <- suppressMessages(readr::read_csv(
      input_csv, na = all_missing_values)
    )
  } else {
    input_df <- read.csv(input_csv, stringsAsFactors = FALSE,
                         check.names = FALSE, na.strings = all_missing_values)
  }

  var_config_df <- suppressMessages(readr::read_csv(
    var_config_csv, na = all_missing_values)
  )

  # Checking the dimensions  and contents of these input dataframes
  check_dataframe_contents(input_df, var_config_df)

  # Checking the contents of the var_config 'Type' column
  # There is no renaming here, as it is likely that no change is made to
  # the contents, as long as they have been entered correctly
  var_config_df <- check_var_config_column_types(var_config_df)

  # Getting the number of original observations for output report
  original_observations <- nrow(input_df)
  original_variables <- ncol(input_df)

  # Identifying any variables in var_config that are not in the input data
  missing_var_config_rows <- setdiff(var_config_df$Column, colnames(input_df))

  # Removing any of these from the var_config dataframe as they are not needed
  if (length(missing_var_config_rows) > 0) {
    wrong_var_config_rows <- which(
      var_config_df$Column %in% missing_var_config_rows
    )
    var_config_df <- var_config_df[-wrong_var_config_rows,]
  }

  # Checking that the outcome variable is in the data if stated
  if (!is.null(outcome_var)) {
    if (!outcome_var %in% colnames(input_df)){
      outcome_error <- sprintf("The outcome_var '%s' is not in the data",
                               outcome_var)
      stop(outcome_error)
    }
  }

  # Checking that all variables intended to be numerical contain numeric data
  problem_columns <- find_problem_numeric_variables(input_df, var_config_df)
  if (length(problem_columns) > 0) {
    problem_columns <- paste0("'", problem_columns, "'")
    problem_column_string <- paste(problem_columns, collapse = ", ")
    numeric_problem_message <- paste(problem_column_string,
                                     "contain non numeric data", sep = ", ")
    stop(numeric_problem_message)
  }

  # Checking that all of the columns in input_df are specified in var_config_df
  # and removing them if they are not. Saving the number of dropped columns
  not_in_var_config <- setdiff(colnames(input_df), var_config_df$Column)
  if (length(not_in_var_config) > 0) {
    var_checked_input_df <- drop_non_listed_columns(input_df, var_config_df)
    quoted_columns <- paste0("'", not_in_var_config, "'")
    quoted_columns_string <- paste(quoted_columns, collapse = ", ")
    quoted_column_warning <- sprintf(
      "%s variables being removed as they are not in the var_config file",
      quoted_columns_string
    )
    warning(quoted_column_warning)
  } else {
    var_checked_input_df <- input_df
  }

  # Checking that none of the variables labelled as categorical contains more
  # unique values than specified in max_levels
  exceed_max_levels <- check_categorical_levels(var_checked_input_df,
                                                var_config_df,
                                                max_levels)
  if (length(exceed_max_levels) > 0) {
    max_level_string <- paste(exceed_max_levels, collapse = ", ")
    max_level_warning <- paste(max_level_string,
                               "contain more unique values than 'max_levels'",
                               sep = " ")
    warning(max_level_warning)
  }

  # Checking that there is 1, and only 1, variable specified as the 'key'
  # in var_config_df, and that this column has all unique values
  key_check_output <- check_key_information(var_checked_input_df, var_config_df)
  if (length(key_check_output > 0)) {
    stop(key_check_output)
  }

  # Removing any rows where the outcome var is set to NA
  if (!is.null(outcome_var) && any(is.na(var_checked_input_df[[outcome_var]]))){
    missing_outcomes <- is.na(var_checked_input_df[[outcome_var]])
    transformed_df <- var_checked_input_df[!missing_outcomes,]
    dropped_outcome_row_count <- sum(missing_outcomes)
  } else {
    transformed_df <- var_checked_input_df
    dropped_outcome_row_count <- 0
  }

  # Setting any coded missing values in var_checked_df as NA and storing
  # how many rows are removed if an outcome variable is specified
  # Only needed if a value is given for missing_values
  # if (nchar(trimws(missing_values)) > 0) {
  #   recoded_missing_value_list <- remove_coded_missing_values(
  #     var_checked_input_df, missing_values, outcome_var
  #   )
  #   transformed_df <- recoded_missing_value_list$output
  #   dropped_outcome_row_count <- recoded_missing_value_list$rows_removed
  # } else {
  #   warning("No missing values have been provided")
  #   transformed_df <- var_checked_input_df
  #   dropped_outcome_row_count <- 0
  # }

  # Getting extra output report information
  remaining_observations <- nrow(transformed_df)
  remaining_variables <- ncol(transformed_df)

  # Splitting the remaining data into numerical, categorical and other
  # Using an external function to allow for testing
  var_config_remaining_info <- remaining_var_config_information(
    transformed_df, var_config_df
  )

  remaining_categorical <- var_config_remaining_info$categorical_count
  remaining_numerical <- var_config_remaining_info$numerical_count
  remaining_other <- var_config_remaining_info$other_count

  # Writing strings containing where variables were not in sync between
  # transformed_df and var_config_df
  dropped_columns_string <- paste(not_in_var_config, collapse = ", ")
  missing_var_config_rows_string <- paste(missing_var_config_rows,
                                          collapse = ", ")

  output_report_data_frame <- dplyr::data_frame(
    Information = c(
      "Number of observations in original data",
      "Number of observations in transformed data",
      "Number of observations in original data where the outcome was missing",
      "Number of columns in original data",
      "Number of columns in transformed data",
      "Number of categorical columns in transformed data",
      "Number of numerical columns in transformed data",
      "Number of other columns in transformed data",
      "Columns in metadata but not in input data",
      "Columns in input data but not in metadata"
    ),
    Values = c(
      original_observations,
      remaining_observations,
      dropped_outcome_row_count,
      original_variables,
      remaining_variables,
      remaining_categorical,
      remaining_numerical,
      remaining_other,
      missing_var_config_rows_string,
      dropped_columns_string
    )
  )

  # Writing the outputs if required
  # Checking that the output dir doesn't end in '/'
  # Using file.path automatically removes it, if it is present
  output_dir <- file.path(output_dir)

  # Making the output directory if required
  if (output_csv) {
    if (!dir.exists(output_dir)) {
      dir.create(output_dir)
    }
  }

  # Writing the output. Making sure that it has a .csv extension
  if (tools::file_ext(prefix) != "csv") {
    prefix <- paste0(prefix, ".csv")
  }

  if (output_csv) {
    output_filename  <- paste0(
      tools::file_path_sans_ext(prefix),
      "data",
      ".csv"
    )
    output_file <- file.path(output_dir, output_filename)
    readr::write_csv(transformed_df, output_file)

    # Writing the report file
    report_filename <- paste0(
      tools::file_path_sans_ext(prefix),
      "report",
      ".csv"
    )
    report_file <- file.path(output_dir, report_filename)
    readr::write_csv(output_report_data_frame, report_file)
  }

  # Returning the transformed information
  list(data = transformed_df, report = output_report_data_frame)
}

#' Checking the user provided input values
#'
#' This function checks that the user has entered values for input_csv and
#' var_config, and then checks to see if they actually exists. Errors are
#' thrown if there are no inputs or the files do not exist
#'
#' @param input_csv The full path to the input file
#' @param var_config The full path the the var_config file
#' @return NULL
#'
check_input_file_variables <- function(input_csv, var_config) {
  # Check that the user has entered values for input_csv and var_config
  if (missing(input_csv) & missing(var_config)) {
    stop("You need to enter values for 'input_csv' and 'var_config'")
  } else if (missing(input_csv) & !missing(var_config)) {
    stop("You need to enter a value for 'input_csv'")
  } else if (!missing(input_csv) & missing(var_config)) {
    stop("You need to enter a value for 'var_config'")
  }

  # Checking that these inputs are actually character strings
  if (!is.character(input_csv) || length(input_csv) == 0 ||
      is.null(input_csv) || is.na(input_csv)) {
    stop("'input_df' argument must be a character string")
  }
  if (!is.character(var_config) || length(var_config) == 0 ||
      is.null(var_config) || is.na(var_config)) {
    stop("'var_config_csv' argument must be a character string")
  }

  # Check that both of the input files actually exist
  if (!file.exists(input_csv) & !file.exists(var_config)) {
    error_message <- sprintf("Both files '%s' and '%s' do not exist",
                             input_csv, var_config)
    stop(error_message)
  } else if (!file.exists(input_csv) & file.exists(var_config)){
    error_message <- sprintf("File '%s' does not exist", input_csv)
    stop(error_message)
  } else if (file.exists(input_csv) & !file.exists(var_config)) {
    error_message <- sprintf("File '%s' does not exist", var_config)
    stop(error_message)
  }
}

#' Check the contents of the loaded data
#'
#' This function will provide a quick check of the data contained within
#' the dataframes after they have been loaded. If they are empty, or if they
#' contain no information for different samples (no rows) then an error
#' will be thrown. It will also check that var_config has a first column called
#' \code{Column} and a second called \code{Type}
#' @param input_df A dataframe containing the input information, read in from
#' the \code{input_csv} file in the \code{read_transform} function.
#' @param var_config A dataframe with the \code{input_df} column names and
#' the intended data types
#' @return NULL
#'
check_dataframe_contents <- function(input_df, var_config) {

  # Checking if both files are empty
  if (nrow(input_df) == 0 & ncol(input_df) == 0 &
      nrow(var_config) == 0 & ncol(var_config) == 0) {
    stop("Both 'input_csv' and 'var_config' are empty files")
  }

  #  the dimensions of these input dataframe
  if (nrow(input_df) == 0 & ncol(input_df) == 0) {
    stop("The 'input_csv' dataframe contains no rows or columns")
  } else if (nrow(input_df) == 0) {
    stop("The 'input_csv' dataframe contains no rows")
  }

  # Checking the dimensions of these var_config dataframe
  if (nrow(var_config) == 0 & ncol(var_config) == 0) {
    stop("The 'var_config' dataframe contains no rows or columns")
  } else if (nrow(var_config) == 0) {
    stop("The 'var_config' dataframe contains no rows")
  }

  # Checking the names of the var_config columns
  if (ncol(var_config) < 2) {
    stop("'var_config' must have at least 2 columns: 'Column' and 'Type'")
  } else if (colnames(var_config)[1] != "Column") {
    stop("The first column of 'var_config' must be called 'Column'")
  } else if (colnames(var_config)[2] != "Type") {
    stop("The second column of 'var_config' must be called 'Type'")
  }
}

#' Check that the column Type in var_config contains the correct value names
#'
#' This function will just check that all of the entries in the var_config
#' dataframe contain only: \code{numerical}, \code{categorical}, \code{key} or
#' \code{other}. Any others will be changed to \code{other} and a warning will
#' be raised
#' @param var_config A dataframe with the \code{input_df} column names and
#' the inteded data types
check_var_config_column_types <- function(var_config) {

  # Checking the values in the Type column
  accepted_inputs <- c("numerical", "categorical", "other", "key")
  accepted_inputs_used <- var_config$Type %in% accepted_inputs
  if (all(accepted_inputs_used)) {
    checked_var_config <- var_config
  } else {
    checked_var_config <- var_config
    checked_var_config$Type[!accepted_inputs_used] <- 'other'
    wrong_type_warning <- sprintf("%d Type row entries replaced by 'other'",
                                  sum(!accepted_inputs_used))
    warning(wrong_type_warning)
  }

  checked_var_config
}

#' Identify misclassified numeric columns
#'
#' This function will identify if any of the columns intended to contain
#' numerical data do not contain data that is compatible with an R numeric
#'
#' @param input_df A dataframe containing the input information, read in from
#' the \code{input_csv} file in the \code{read_transform} function.
#' @param data_type_df A dataframe with the \code{input_df} column names and
#' the intended data types. This must contain columns with the names
#' \code{Column} and \code{Type}
#' @return A vector of any columns that should be numerical but don't contain
#' numerical data
#'
find_problem_numeric_variables <- function(input_df, data_type_df) {
  data_type_df_numerical <- data_type_df %>%
    dplyr::filter_(~Type == "numerical")

  numeric_columns <- data_type_df_numerical$Column
  input_df_numerical <- input_df[numeric_columns]

  # If any column is completely NA, make it a numeric datatype
  all_na <- vapply(input_df_numerical, function(x) all(is.na(x)), TRUE)

  if (any(all_na)) {
    input_df_numerical[, all_na] <- lapply(
      input_df_numerical[, all_na],
      function(x) as.numeric(x)
    )
  }

  input_df_numerical_dtypes <- vapply(input_df_numerical, class, "")
  numeric_error <- !(input_df_numerical_dtypes %in%
                       c("numeric", "integer"))
  numeric_columns[numeric_error]
}

#' Check input data for non-specified columns
#'
#' This function checks to see if all of the columns in \code{input_df} are
#' listed in the \code{var_config} file containing the intended datatypes
#'
#' @param input_df A dataframe containing the input information, read in from
#' the \code{input_csv} file in the \code{read_transform} function.
#' @param data_type_df A dataframe with the \code{input_df} column names and
#' the intended data types. This must contain columns with the names
#' \code{Column} and \code{Type}
#' @return A list containing the following information:
#' \describe{
#'   \item{\code{output}}{A dataframe. If \code{input_df} contained columns
#'   not listed in \code{data_type_df}, then this contains the non-dropped
#'   columns. Otherwise, this is the same as \code{input_df}}
#'   \item{\code{columns_removed}}{The number of dropped columns from
#'   \code{input_df}. 0 if none dropped}
#'   \item{\code{dropped_columns}}{A vector containing the names of the columns
#'   that were dropped. Empty if none dropped}
#' }
#'
drop_non_listed_columns <- function(input_df, data_type_df) {
  # Getting the counts of variables to see if this changes
  orig_column_number <- ncol(input_df)
  listed_columns_bool <- colnames(input_df) %in% data_type_df$Column
  listed_columns <- colnames(input_df)[listed_columns_bool]
  non_listed_columns <- colnames(input_df)[!listed_columns_bool]

  output_df <- input_df %>%
    dplyr::select_(.dots = listed_columns)

  output_df
}

#' Checking the number of unique entries for categorical variables
#'
#' This function selects only those variables that are labelled as categorical
#' from the \code{var_config} dataframe. It then reports if any of the columns
#' contain more unique values than specified in \code{max_levels}
#'
#' @param input_df A dataframe containing the input information, read in from
#' the \code{input_csv} file in the \code{read_transform} function.
#' @param data_type_df A dataframe with the \code{input_df} column names and
#' the intended data types. This must contain columns with the names
#' \code{Column} and \code{Type}
#' @param max_levels An integer value. The maximum number of levels that a
#' variable labelled as categorical in the data_metadata can have
#' @return A vector with the rows names of any columns that contain categorical
#' information that has a number of unique values greater than \code{max_levels}
#' If there are none, then this is an empty vector
#'
check_categorical_levels <- function(input_df, data_type_df, max_levels) {
  if (any(data_type_df$Type == "categorical")) {
    data_type_df_categorical <- data_type_df %>%
      dplyr::filter_(~Type == "categorical")

    categorical_columns <- data_type_df_categorical$Column
    input_df_categorical <- input_df[categorical_columns]

    # Getting the number of unique levels in each column
    unique_count_df <- input_df_categorical %>%
      dplyr::summarise_all(dplyr::n_distinct)

    # Scanning if any are greater than max_levels
    exceeds_max_levels <- unique_count_df > max_levels
    exceeded_values <- colnames(input_df_categorical)[exceeds_max_levels]
    exceeded_values
  } else {
    character(0)
  }
}

#' Checking that there is a key variable and that this contains correct info
#'
#' This function checks to see that there is strictly 1 variable labelled as
#' the key variable, and that this contains all unique values
#'
#' @param input_df A dataframe containing the input information, read in from
#' the \code{input_csv} file in the \code{read_transform} function.
#' @param data_type_df A dataframe with the \code{input_df} column names and
#' the intended data types. This must contain columns with the names
#' \code{Column} and \code{Type}
#' @return An empty character vector if all of the conditions are met,
#' otherwise a character string description of the various problems, or the
#' names of the columns if there are multiple columns labelled as the key
#'
check_key_information <- function(input_df, data_type_df) {
  # Checking that there is at least one variable labelled as the key
  if (any(data_type_df$Type == 'key')) {
    data_type_df_key <- data_type_df %>%
      dplyr::filter_(~Type == "key")
  } else {
    return("There is no variable listed with a Type value of 'key'")
  }

  # Checking that the number of keys does not exceed 1
  number_of_keys <- nrow(data_type_df_key)
  if (number_of_keys > 1) {
    quoted_columns <- paste0("'", data_type_df_key$Column, "'")
    key_columns <- paste(quoted_columns, collapse = ', ')
    return(paste0("Columns: ", key_columns, ", are labelled as 'key'"))
  }

  # Checking that this contains all unique values
  key_name <- data_type_df_key$Column[1]
  number_unique_key_entries <- length(unique(input_df[[key_name]]))
  number_input_df_rows <- nrow(input_df)

  if (number_unique_key_entries < number_input_df_rows) {
    return(sprintf("There are %d entries but only %d unique values",
                   number_input_df_rows, number_unique_key_entries))
  } else {
    return(character(0))
  }
}

#' Summarising the variables that remain after any transformations
#'
#' This function creates a summary of the variables that remain after any
#' possible transformations.
#'
#' @param transformed_df A dataframe containing the column names and values of
#' any variables that remain after any transformation processes
#' @param var_config_df The dataframe which was read in from the file in
#' \code{var_config} in the \code{read_transform} function
#' @return A list with the following information:
#' \describe{
#'   \item{\code{categorical_count}}{The number of remaining variables that are
#'   described as "categorical"}
#'   \item{\code{numerical_count}}{The number of remaining variables that are
#'   described as "numerical"}
#'   \item{\code{other_count}}{The number of remaining variables that are
#'   described as "other"}
#' }
#'
remaining_var_config_information <- function(transformed_df, var_config_df) {
  # Keeping only the remaining variables in var_config_df
  var_config_df_remaining <- var_config_df %>%
    dplyr::filter_(~Column %in% colnames(transformed_df))

  # Getting the categorical, numerical, and other counts
  categorical_count <- sum(var_config_df_remaining$Type == "categorical")
  numerical_count <- sum(var_config_df_remaining$Type == "numerical")
  other_count <- sum(var_config_df_remaining$Type == "other")

  list(
    categorical_count = categorical_count,
    numerical_count = numerical_count,
    other_count = other_count
  )
}

utils::globalVariables("n_distinct")

