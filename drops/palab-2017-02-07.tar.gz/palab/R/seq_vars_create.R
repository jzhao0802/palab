#' Create sequence variables and provide a flagged summary
#'
#' This function creates a flagged summary from a series of pre-defined pairwise
#' comparisons. These pairwise comparisons assess if events take place before,
#' after or at the same time as other events. All of the comparisons that are to
#' be carried out must feature in the \code{seq_vars_selection} dataframe.
#'
#' @param event_dates A character string giving the name and path to a csv file
#' containing the date variable information. This dataframe must also contain
#' an id column with unique identifiers, and an optional binary outcome
#' variable column
#' @param seq_vars_selection A character string giving the name an path to a csv
#' file that contains 5 columns: The first 2 columns must be named 'A', and 'B',
#' which contain the pairs of date variables to consider. The remaining 3 MUST
#' have the names 'Before', 'After', and 'Equal' and must only contain logical
#' values of TRUE and FALSE
#' @param id_column A character string with the name of the column to use as the
#' identifier for each row. Synonymous with a Primary Key in SQL
#' @param outcome_var A character string of the variable to use as an outcome
#' variable if required. Default NULL
#' @param missing_values A comma separated character string with all of the
#' values that are to be considered as missing data. Whitespace is accepted.
#' Default is an empty character string if no coding for missing values is
#' required. An error will be thrown if this contains any missing values
#' eg \code{"-99,,-999"}. Default empty string - meaning no values
#' @param prefix A character string of the prefix that will be given to the
#' file where the outputs will be saved
#' @param output_dir Character string of the directory to save the outputs.
#' Default "."
#' @param output_csv A boolean to indicate if the outputs should be written
#' to the output file
#' @export seq_vars_create
#'
seq_vars_create <- function(event_dates, seq_vars_selection, id_column,
                            outcome_var = NULL, missing_values = "",
                            prefix = "", output_dir = ".", output_csv = FALSE) {

  # Checking that event_dates is a character string and that it exists
  if (missing(event_dates) || !is.character(event_dates) ||
    length(event_dates) != 1) {
    stop("'event_dates' must be entered and must be a character string")
  }

  # Checking that it actually exists
  if (!file.exists(event_dates)) {
    event_dates_exist_error <- sprintf(
      "The file '%s' does not exist",
      event_dates
    )
    stop(event_dates_exist_error)
  }

  # Checking that seq_vars_selection is a character string and that it exists
  if (missing(seq_vars_selection) || !is.character(seq_vars_selection) ||
    length(seq_vars_selection) != 1) {
    stop("'seq_vars_selection' must be entered and must be a character string")
  }

  # Checking that it actually exists
  if (!file.exists(seq_vars_selection)) {
    seq_vars_selection_exist_error <- sprintf(
      "The file '%s' does not exist",
      seq_vars_selection
    )
    stop(seq_vars_selection_exist_error)
  }

  # Checking that id_column is a character string and that it exists
  if (missing(id_column) || !is.character(id_column) ||
      length(id_column) != 1) {
    stop("'id_column' must be entered and must be a character string")
  }

  # Checking that the outcome variable is a string if one has been entered
  if (!is.null(outcome_var) && (!is.character(outcome_var) ||
      length(outcome_var) != 1)) {
    outcome_var_error <- paste(
      "If a value is entered for 'outcome_var'",
      "then it must be a character string"
    )
    stop(outcome_var_error)
  }

  # Checking that missing_values is a character string
  if (!is.character(missing_values)) {
    stop("'missing_values' must be a comma separated string")
  }

  # Splitting missing value string and removing whitespace
  user_missing_values <- strsplit(missing_values, split = ',')[[1]]
  user_missing_values <- trimws(user_missing_values)

  # Raising an error is any of these are empty values
  if (any(nchar(user_missing_values) == 0)) {
    stop("'missing_values' contains empty values")
  }

  if (!is.character(prefix) || length(prefix) != 1) {
    stop("'prefix' argument must be a character string")
  }

  # Making sure that an empty string and NA are also included in these
  user_missing_values <- c("", "NA", user_missing_values)

  # Loading in the data, and checking that date values are parsed correctly
  # Using a function in a different file, as it is also used by seq_vars_ds
  event_dates_df <- load_check_date_dataframe(event_dates, user_missing_values,
                                              id_column, outcome_var)

  # Loading in the seq_vars_selection information
  seq_vars_selection_df <- check_and_load_seq_vars_selection(
    seq_vars_selection = seq_vars_selection,
    event_dates_df = event_dates_df
  )

  # Getting the flag summary from all of the listed pairs and their comparison
  # methods
  full_flag_summary <- get_full_flag_summary(
    event_dates_df = event_dates_df,
    seq_vars_selection_df = seq_vars_selection_df,
    id_column = id_column
  )

  # Writing out the file if output_csv is TRUE
  if (output_csv) {
    output_dir <- file.path(output_dir)

    # Checking if the output_dir exists, and making it if it doesn't
    if (!dir.exists(output_dir)) {
      dir.create(output_dir, recursive = TRUE)
    }

    if (tools::file_ext(prefix) == "csv") {
      prefix <- tools::file_path_sans_ext(prefix)
    }

    seq_var_output <- paste0(prefix, "seq_vars_feats.csv")
    seq_var_output_path <- file.path(output_dir, seq_var_output)
    readr::write_csv(full_flag_summary, seq_var_output_path)
  }

  full_flag_summary
}

#' Load and check the seq_vars_selection information
#'
#' This function loads in the information file from the seq_vars_selection
#' argument and carries out a number of checks. These are: checking that it
#' contains 5 columns, that it contains the columns, 'Before', 'After', and
#' 'Equal', and that all of those 3 columns contain only logical values. Any of
#' those failing results in an error being raised. Then it checks to see that
#' each row contains at least one TRUE value in any of these 3 columns. If not,
#' a warning is given and the row is removed from the analysis
#'
#' @param seq_vars_selection A character string pointing to the filename
#' containing the seq_vars_selection dataframe information
#' @param event_dates_df The dataframe that was loaded in from the event_dates
#' parameter in the main function. This is required to check that all of the
#' variables in the seq_vars_selection information is in the main data
#' @return A dataframe with the seq_vars_selection information, with any rows
#' removed if the rows condition mention above is not met
#'
check_and_load_seq_vars_selection <- function(seq_vars_selection,
                                              event_dates_df) {

  # Loading in the dataframe
  seq_vars_selection_df <- suppressMessages(
    readr::read_csv(seq_vars_selection)
  )

  if (ncol(seq_vars_selection_df) != 5) {
    stop("The 'seq_vars_selection' dataframe must contain 5 columns of data")
  }

  # Checking the columns 'A' and 'B' appear in this information
  if (!all(c("A", "B") %in% colnames(seq_vars_selection_df))) {
    stop("'seq_vars_selection' must contain the columns 'A' and 'B'")
  }

  # Getting the 3 columns with the logical information
  info_columns <- c("Before", "After", "Equal")

  if (!all(info_columns %in% colnames(seq_vars_selection_df))) {
    stop("'seq_vars_selection' must have columns: 'Before', 'After' and 'Equal")
  }

  # Checking that all of the variables listed in 'A' and 'B' are contained
  # in the event_dates information

  date_variable_ind <- vapply(event_dates_df, lubridate::is.Date, TRUE)
  date_variables <- colnames(event_dates_df)[date_variable_ind]

  all_pairwise_vars <- union(seq_vars_selection_df$A, seq_vars_selection_df$B)

  if (!all(all_pairwise_vars %in% date_variables)) {
    pairwise_var_error <- paste(
      "'seq_var_selections' contain variables not included in 'event_dates"
    )
    stop(pairwise_var_error)
  }

  seq_var_info <- seq_vars_selection_df %>%
    dplyr::select_(.dots = info_columns)

  # Checking that all of these columns contain logical values
  all_logical <- vapply(seq_var_info, is.logical, TRUE)

  if (!all(all_logical)) {
    all_logical_error <- paste(
      "The 'Before', 'After', and 'Equal' columns in 'seq_vars_selection'",
      "must be TRUE or FALSE only"
    )
    stop(all_logical_error)
  }

  # Getting the rowSums to check that every row contains at least one TRUE value
  true_check <- rowSums(seq_var_info)
  none_true <- which(true_check == 0)

  if (any(none_true)) {
    warning_suffix <- paste(
      "Row numbers do not contain any TRUE values in 'seq_vars_selection'.\n",
      "These rows are being removed."
    )
    raise_quoted_error(none_true, warning_suffix, action = "warning")

    seq_vars_selection_df <- seq_vars_selection_df %>%
      dplyr::filter_(~!row_number() %in% none_true)
  }

  seq_vars_selection_df
}

#' Get the full summary of the flagged information
#'
#' This is the main function that gets the summaries for all of the different
#' methods of 'Before', 'After', and 'Equal'. It identifies the variable pairs
#' for the various comparisons, and then uses other helper functions to create
#' the summaries
#'
#' @param event_dates_df The dataframe loaded in from the event_dates parameter
#' in the main function
#' @param seq_vars_selection_df The dataframe loaded in from the
#' seq_vars_selection parameter in the main function
#' @param id_column The column name for the id_column
#' @return A dataframe with the complete summary information
#'
get_full_flag_summary <- function(event_dates_df, seq_vars_selection_df,
                                  id_column) {

  # Getting all the summaries of the 3 different methods. All of these are
  # returning list of single column dataframes
  before <- get_single_flag_summary(event_dates_df, seq_vars_selection_df,
                                    method = "Before")
  after <- get_single_flag_summary(event_dates_df, seq_vars_selection_df,
                                   method = "After")
  equal <- get_single_flag_summary(event_dates_df, seq_vars_selection_df,
                                   method = "Equal")

  # Making a list of these and removing any if they are empty, then converting
  # to a dataframe
  all_summary_li <- list(before, after, equal)
  all_summary_li <- Filter(length, all_summary_li)

  # The next call 'flattens' out the nested list structure
  all_summary_li <- do.call("append", all_summary_li)

  all_summary_df <- dplyr::bind_cols(all_summary_li)

  # Including the id_column back into the full summary
  all_summary_df <- dplyr::bind_cols(
    event_dates_df[id_column],
    all_summary_df
  )

  all_summary_df
}

#' Get the summary for a single method type: 'Before', 'After', or 'Equal'
#'
#' This function calculates the summary for a stated method. It creates an
#' iterator of all of the relevant pairs of variables and then gets the flagged
#' summaries for all of these pairs. This function returns a list, as all of the
#' summaries for all of the methods is done in \code{get_full_flag_summary}
#'
#' @param event_dates_df The dataframe loaded in from the event_dates parameter
#' in the main function
#' @param seq_vars_selection_df The dataframe loaded in from the
#' seq_vars_selection parameter in the main function
#' @param method A character string. Either 'Before', 'After', or 'Equal'
#' @return A list of the relevant pairwise summaries. Each element of this list
#' contains a single column of information
#'
get_single_flag_summary <- function(event_dates_df, seq_vars_selection_df,
                                    method) {

  # Making sure that the method is a valid input
  if (!(method %in% c("Before", "After", "Equal"))) {
    method_error <- sprintf(
      "'%s' is not a valid value for 'method'",
      method
    )
    stop(method_error)
  }


  # Getting the subsets of variable pairs required for the method summary
  method_filter <- lazyeval::interp(~var == TRUE, var = as.name(method))
  subset_df <- seq_vars_selection_df %>%
    dplyr::filter_(method_filter) %>%
    dplyr::select_(.dots = c("A", "B"))

  # Getting the matrix of the pairs and creating the iterator object
  subset_pairs <- as.matrix(subset_df)
  subset_it <- get_df_iterator(subset_pairs, event_dates_df)

  # Getting the flagged summaries for all the pairs
  summary_li <- lapply(subset_it, get_flag_column, method = method)

  summary_li
}

#' Get the summary for a single pair of variables
#'
#' This function calculates the summary flag values for a single pair of
#' variables, using the relevant method required: 'Before', 'After', or 'Equal'.
#' It also creates the required column name for this information
#'
#' @param pair_df A 2 column dataframe, the output from the iterator object
#' @param method A character string. Either 'Before', 'After', or 'Equal'
#' @return A single column dataframe
#'
get_flag_column <- function(pair_df, method) {

  # Making sure that the method is a valid input
  if (!(method %in% c("Before", "After", "Equal"))) {
    method_error <- sprintf(
      "'%s' is not a valid value for 'method'",
      method
    )
    stop(method_error)
  }

  # Raising an error if the dataframe does not have 2 columns
  if (ncol(pair_df) != 2) {
    stop("The dataframe input to 'get_flag_column' does not have 2 columns")
  }

  # Getting the variable pair from the column names
  var_pair <- colnames(pair_df)

  # Creating the column name and formula based on the method required
  if (method == "Before") {
    new_colname <- paste(var_pair, collapse = "_BEFORE_")
    summary_formula <- lazyeval::interp(~as.numeric(var1 < var2),
                                        var1 = as.name(var_pair[1]),
                                        var2 = as.name(var_pair[2]))
  } else if (method == "After") {
    new_colname <- paste(var_pair, collapse = "_AFTER_")
    summary_formula <- lazyeval::interp(~as.numeric(var1 > var2),
                                        var1 = as.name(var_pair[1]),
                                        var2 = as.name(var_pair[2]))
  } else if (method == "Equal") {
    new_colname <- paste(var_pair, collapse = "_EQUAL_")
    summary_formula <- lazyeval::interp(~as.numeric(var1 == var2),
                                        var1 = as.name(var_pair[1]),
                                        var2 = as.name(var_pair[2]))

  }

  summary_df <- pair_df %>%
    dplyr::mutate_(.dots = setNames(list(summary_formula), new_colname)) %>%
    dplyr::select_(.dots = new_colname)

  summary_df
}
