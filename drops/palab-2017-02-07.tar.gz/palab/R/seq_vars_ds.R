#' Create paired sequence variables
#'
#' This function creates summaries of pairwise comparisons between variables
#' containing date information. The main input to this function is a filename
#' to a csv file that loads in a dataframe that must consist of the following:
#' \itemize{
#'   \item{An id column which consists of a unique identifier for that row.
#'   Analagous to a 'Primary Key' in SQL}
#'   \item{*If required* A binary outcome variable that consists of only 0s and
#'   1s. If this column is present, then the name of it MUST be provided in the
#'   \code{outcome_var} argument}
#'   \item{All remaining columns must consist of date information in ISO8601
#'   format. An values in any of these columns that are used to imply missing
#'   values MUST be included in the \code{missing_values} argument}
#' }
#' The function then calculates the pairwise summaries. One summary is always
#' returned and calculates the following:
#' \itemize{
#'   \item{The count of all co-occurring instances - ie, where there are
#'   non-missing values present for the particular pairwise comparison}
#'   \item{The proportion of the co-occurring instances - ie, the previous
#'   value divided by all of the row entries from the input dataframe}
#'   \item{The number of instances where the first listed variable occurs
#'   before the second}
#'   \item{The proportion of these entries - ie. the following value divided by
#'   the total number of co-occurring instances of the two variables}
#'   \item{The same information as the following 2 points, but for when the
#'   second variable occurs before the first}
#'   \item{The same pair of information points, but for when both variables
#'   occur on exactly the same day}
#' }
#' The second summary is only performed if there a binary outcome variable, and
#' consists of the same information as listed above, but summarised for both
#' levels of the outcome variable. In addition a series of 'Delta' columns are
#' calculated, which show the absolute differences between the proportion values
#' at the 2 outcome variable levels
#'
#' @param event_dates A character string of a file containing a .csv file of a
#' dataframe where every column represents a variable and every row is an
#' observation. If there is an outcome variable, then this should contain only
#' binary values {0, 1}. For all of the other variables, the non-missing values
#' should be in ISO8601 data format.
#' @param id_column A character string with the name of the column to use as the
#' identifier for each row. Synonymous with a Primary Key in SQL
#' @param outcome_var A character string of the variable to use as an outcome
#' variable if required. Default NULL
#' @param missing_values A comma separated character string with all of the
#' values that are to be considered as missing data. Whitespace is accepted.
#' Default is an empty character string if no coding for missing values is
#' required. An error will be thrown if this contains any missing values
#' eg \code{"-99,,-999"}. Default empty string - meaning no values
#' @param freq_thrsh A numeric value between 0 and 1 that defines how frequent
#' a pair of events need to be so that it will output as a sequence variable.
#' The default value is 0.01, representing 1\%. If no outcome variable is
#' provided, then this will be applied to the proportion of entries where there
#' is an entry for both date variables. If there is an outcome variable, then
#' this will only be applied to the proportion of co-occurring values when the
#' outcome variable is positive. This value will also be initially applied to
#' the separate date variables to assess if they contain at least this
#' proportion of non-missing values
#' @param xfreq_thrsh A numeric value between 0 and 1. This is only used for
#' cases where there is a binary outcome variable, and it defines the minimum
#' required difference in the class-specific frequency of a sequence variable.
#' e.g. if the frequency of a variable is 10\% for level 1 and 25\% for level
#' two then the difference is 15\%. The default value is 0.05, representing 5\%
#' @param prefix A character string of the prefix that will be given to the
#' file where the outputs will be saved
#' @param output_dir Character string of the directory to save the outputs.
#' Default "."
#' @param output_csv A boolean to indicate if the outputs should be written
#' to the output file
#' @param parallel A logical value to denote if parallel processing should be
#' used. Default FALSE
#' @param cores An integer value that allows a user to manually state how many
#' cores will be used. Take care not to assign too many, as this will affect
#' other processes running on your system. Default 2
#'
#' @export seq_vars_ds
#'
seq_vars_ds <- function(event_dates, id_column, outcome_var = NULL,
                        missing_values = "", freq_thrsh = 0.01,
                        xfreq_thrsh = 0.05, prefix = "", output_dir = ".",
                        output_csv = FALSE, parallel = FALSE, cores = 2){

  # Checking that event_dates is a character string and that it exists
  if (missing(event_dates) || !is.character(event_dates) ||
    length(event_dates) != 1) {
    stop("'event_dates' must be entered and must be a character string")
  }

  # Checking that it actually exists
  if (!file.exists(event_dates)) {
    event_dates_exist_error <- sprintf(
      "The file '%s' does not exist",
      event_dates
    )
    stop(event_dates_exist_error)
  }

  # Checking that id_column is a character string and that it exists
  if (missing(id_column) || !is.character(id_column) ||
      length(id_column) != 1) {
    stop("'id_column' must be entered and must be a character string")
  }

  # Checking that the outcome variable is a string if one has been entered
  if (!is.null(outcome_var) && (!is.character(outcome_var) ||
      length(outcome_var) != 1)) {
    outcome_var_error <- paste(
      "If a value is entered for 'outcome_var'",
      "then it must be a character string"
    )
    stop(outcome_var_error)
  }

  # Checking that missing_values is a character string
  if (!is.character(missing_values)) {
    stop("'missing_values' must be a comma separated string")
  }

  # Checking that the 2 threshold arguments are numerics between 0 and 1
  if (!is.numeric(freq_thrsh) || freq_thrsh < 0 || freq_thrsh > 1) {
    stop("'freq_thrsh' must be a numeric value between 0 and 1")
  }

  if (!is.numeric(xfreq_thrsh) || xfreq_thrsh < 0 || xfreq_thrsh > 1) {
    stop("'xfreq_thrsh' must be a numeric value between 0 and 1")
  }

  # Checking that the output and output_dir arguments are character strings
  if (!is.character(prefix) | length(prefix) != 1) {
    stop("'prefix' must be a character string")
  }

  if (!is.character(output_dir) | length(output_dir) != 1) {
    stop("'output_dir' must be a character string")
  }


  # Splitting missing value string and removing whitespace
  user_missing_values <- strsplit(missing_values, split = ',')[[1]]
  user_missing_values <- trimws(user_missing_values)

  # Raising an error is any of these are empty values
  if (any(nchar(user_missing_values) == 0)) {
    stop("'missing_values' contains empty values")
  }

  # Making sure that an empty string and NA are also included in these
  user_missing_values <- c("", "NA", user_missing_values)

  # Raise an error if the parallel argument is not logical TRUE or FALSE
  if (!is.logical(parallel) || length(parallel) != 1) {
    stop("'parallel' must be a logical input - either TRUE or FALSE")
  }

  # Checking that cores is numeric and divisible by 1
  if (!is.numeric(cores) || !(cores %% 1 == 0) || length(cores) != 1) {
    stop("'cores' argument must be a whole number")
  }

  # Checking that the number of cores entered is not too high
  available_cores <- parallel::detectCores() - 1
  if(parallel & cores > available_cores) {
    cores <- available_cores
    core_warning <- sprintf(
      "The value entered for 'cores' was too high, changing to %d",
      available_cores
    )
    warning(core_warning)
  }

  # Loading in the data, and checking that date values are parsed correctly
  # Using a function in a different file, as it is also used by seq_vars_create
  event_dates_df <- load_check_date_dataframe(event_dates, user_missing_values,
                                              id_column, outcome_var)

  # Doing the initial variable selection on freq_thrsh
  is_non_date <- function(x) !lubridate::is.Date(x)
  is_date <- function(x) lubridate::is.Date(x)
  prop_fun <- function(x) sum(is.na(x)) / length(x)

  non_date_df <- event_dates_df %>%
    dplyr::select_if(is_non_date)

  date_df <- event_dates_df %>%
    dplyr::select_if(is_date)

  meets_thrsh <- date_df %>%
    dplyr::summarise_all(prop_fun)

  date_df <- date_df %>%
    dplyr::select_if(meets_thrsh > freq_thrsh)

  # Raising an error if this has removed all of the data
  if (ncol(date_df) == 0) {
    initial_freq_thrsh_error <- sprintf(
      "'freq_thrsh' value of '%s' has removed all of the data",
      as.character(freq_thrsh)
    )
    stop(initial_freq_thrsh_error)
  }

  # Combining this information back together
  event_dates_df <- dplyr::bind_cols(
    non_date_df,
    date_df
  )

  # Getting the first section of the summary. This is performed regardless of
  # the presence of an outcome variable
  first_summary <- get_overall_first_summary(
    event_dates_df = event_dates_df,
    parallel = parallel,
    cores = cores
  )

  if (!is.null(outcome_var)) {
    second_summary <- get_overall_second_summary(
      event_dates_df = event_dates_df,
      outcome_var = outcome_var,
      parallel = parallel,
      cores = cores
    )

    # Joining the summaries together and filtering on the 2 threshold values
    # The freq_thrsh value is being used only on the summary of outcome level 1
    full_summary <- dplyr::inner_join(first_summary,
                                      second_summary,
                                      by = c("A", "B")) %>%
      dplyr::filter_(~`A and B Proportion Level_1` > freq_thrsh,
                     ~`Delta A and B` > xfreq_thrsh)
  } else {

    # Only using the first summary and filtering on freq_thrsh only
    full_summary <- first_summary %>%
      dplyr::filter_(~`Proportion A and B (total obs)` > freq_thrsh)
  }

  # Adding an error if these filters have removed all of the data
  if (nrow(full_summary) == 0) {
    stop("The threshold values given have removed all the summary information")
  }

  # Writing out the file if output_csv is TRUE
  if (output_csv) {
    output_dir <- file.path(output_dir)

    # Checking if the output_dir exists, and making it if it doesn't
    if (!dir.exists(output_dir)) {
      dir.create(output_dir, recursive = TRUE)
    }

    if (tools::file_ext(prefix) == "csv") {
      prefix <- tools::file_path_sans_ext(prefix)
    }

    seq_var_output <- paste0(prefix, "seq_vars_descriptives.csv")
    seq_var_output_path <- file.path(output_dir, seq_var_output)
    readr::write_csv(full_summary, seq_var_output_path)
  }

  full_summary
}

#' Get the full first summary of the pairwise combinations of date variables
#'
#' This function creates the first summary that is performed on all of the
#' date variables, regardless of the presence of an outcome variable. This
#' function makes use of iterators, which allow the full dataframe to be
#' broken up into subsets of 2 column dataframes of each pair. And these can
#' also be used with parallel processing if desired
#'
#' @param event_dates_df The full dataframe loaded in by the main function
#' @param parallel A logical value to state if parallel processing is to be used
#' @param cores The number of cores to use if parallel processing is required
#' @return A dataframe of the first summary, calculated without the outcome
#' variable
#'
get_overall_first_summary <- function(event_dates_df, parallel, cores) {

  # Getting the and date information from this subsetted information
  date_df <- event_dates_df %>%
    dplyr::select_if(lubridate::is.Date)

  # Getting all of the pairwise combinations of date variables. This function
  # returns a matrix where the pairwise combinations are in columns, but this
  # is then transposed so that they are listed by columns. This is because in
  # later procedures, the information will be taken from rows of a dataframe
  pairwise_vars <- utils::combn(
    colnames(date_df),
    2
  )

  pairwise_vars <- t(pairwise_vars)

  # Creating the iterator which produces pairwise subsets of the date variables
  # This makes use of a helper function in a different file
  date_it <- get_df_iterator(pairwise_vars, date_df)

  # Getting the results either using parallel or serial processing
  if (parallel) {
    `%dopar%` <- foreach::`%dopar%`
    pair_number <- length(pairwise_vars)
    cl <- snow::makeCluster(cores, type = "SOCK")
    doSNOW::registerDoSNOW(cl)

    first_summary <- foreach::foreach(
      this_df = date_it
    ) %dopar% {
      get_date_variable_summaries(this_df)
    }
    snow::stopCluster(cl)
  } else {
    first_summary <- lapply(date_it,
                            get_date_variable_summaries)
  }

  # As this is a list of dataframes, it is now converted into a dataframe
  first_summary <- dplyr::bind_rows(first_summary)

  first_summary
}

#' Get the full first summary of a pair of date variables
#'
#' This function calculates the summaries for a single pair of data variables.
#' As the variables are always referred to by strings, the dplyr functions need
#' to make use of Standard Evaluation, and this requires that formulae are
#' written. This is different from the usual interactive use of dplyr.
#'
#' @param df A 2 column dataframe containing date variable information. An
#' error will be raised if this does not contain 2 columns
#' @return A single row dataframe with the full first summary of one pair of
#' date variables
#'
get_date_variable_summaries <- function(df) {

  # This function makes use of column names in the dataframe. As these are
  # character strings, dplyr needs to use Standard Evaluation, and therefore
  # needs all of the summaries to be written as formulae

  if (ncol(df) != 2) {
    stop("The input dataframe for the pairwise summary does not have 2 columns")
  }

  var_pair <- colnames(df)

  a_and_b <- lazyeval::interp(~sum(!is.na(var1) & !is.na(var2)),
                              var1 = as.name(var_pair[1]),
                              var2 = as.name(var_pair[2]))

  not_a_and_b <- lazyeval::interp(~sum(is.na(var1) & is.na(var2)),
                                  var1 = as.name(var_pair[1]),
                                  var2 = as.name(var_pair[2]))

  a_before_b <- lazyeval::interp(~sum(var1 < var2, na.rm = TRUE),
                                 var1 = as.name(var_pair[1]),
                                 var2 = as.name(var_pair[2]))

  b_before_a <- lazyeval::interp(~sum(var1 > var2, na.rm = TRUE),
                                 var1 = as.name(var_pair[1]),
                                 var2 = as.name(var_pair[2]))

  a_equal_b <- lazyeval::interp(~sum(var1 == var2, na.rm = TRUE),
                                 var1 = as.name(var_pair[1]),
                                 var2 = as.name(var_pair[2]))



  summary_df <- dplyr::summarise_(df,
      A = ~var_pair[1],
      B = ~var_pair[2],
      `A and B` = a_and_b,
      `Proportion A and B (total obs)` = ~`A and B` / n(),
      `Missing A and B` = not_a_and_b,
      `A before B` = a_before_b,
      `Proportion A before B` = ~`A before B` / `A and B`,
      `B before A` = b_before_a,
      `Proportion B before A` = ~`B before A` / `A and B`,
      `A equal B` = a_equal_b,
      `Proportion A equal B` = ~`A equal B` / `A and B`
    )

  summary_df
}

#' Get the full second summary of the pairwise combinations of date variables
#'
#' This function calculates the second summary, which is the summaries of the
#' pairwise comparisons of date variables at the 2 different levels of the
#' outcome variable, if there is a binary outcome variable provided. This
#' function also makes use of custom iterator objects, as was done in the first
#' summary, but this function requires that each dataframe subset that is
#' made also has the outcome_var information - resulting in outputs of 3-column
#' dataframes.
#'
#' @param event_dates_df The full dataframe loaded in by the main function
#' @param outcome_var A character string of the outcome variable
#' @param parallel A logical value to state if parallel processing is to be used
#' @param cores A single integer value to state how many cores of the machine
#' should be used
#' @return A dataframe of the full second summary, calculated at the different
#' levels of the outcome variable
#'
get_overall_second_summary <- function(event_dates_df, outcome_var, parallel,
                                       cores) {

  # Getting the outcome and date dataframe, together with the date variables
  outcome_var_and_date_li <- get_outcome_and_date_variables(
    event_dates_df = event_dates_df,
    outcome_var = outcome_var
  )

  outcome_var_and_date_df <- outcome_var_and_date_li$df
  date_variables <- outcome_var_and_date_li$date_cols

  # Making the pairwise vars matrix from these date columns. Also using the
  # transpose so that these are diplayed by row
  pairwise_vars <- utils::combn(
    date_variables,
    2
  )

  pairwise_vars <- t(pairwise_vars)

  # The pairwise vars need the outcome var to be added as the first column
  outcome_and_pairwise_vars <- cbind(
    rep(outcome_var, nrow(pairwise_vars)),
    pairwise_vars
  )

  # Creating the iterator which produces pairwise subsets of the date variables
  # This makes use of a helper function in a different file
  date_it <- get_df_iterator(
    outcome_and_pairwise_vars,
    outcome_var_and_date_df)

  if (parallel) {
    `%dopar%` <- foreach::`%dopar%`
    pair_number <- length(pairwise_vars)
    cl <- snow::makeCluster(cores, type = "SOCK")
    doSNOW::registerDoSNOW(cl)

    second_summary <- foreach::foreach(
      this_df = date_it
    ) %dopar% {
      get_date_variable_summaries_by_outcome(this_df, outcome_var)
    }
    snow::stopCluster(cl)
  } else {
    second_summary <- lapply(
      date_it,
      get_date_variable_summaries_by_outcome,
      outcome_var = "outcome_var"
    )
  }

  second_summary <- dplyr::bind_rows(second_summary)

  second_summary
}

#' Get the full second summary of a pair of date variables
#'
#' This function calculates the summaries for a single pair of data variables.
#' As the variables are always referred to by strings, the dplyr functions need
#' to make use of Standard Evaluation, and this requires that formulae are
#' written. This is different from the usual interactive use of dplyr.
#'
#' @param df A 3 column dataframe containing date variable information. The
#' first column always contained the binary outcome variable, and the remaining
#' columns contain the information for a single pair of date variables
#' @param outcome_var The column name for the outcome variable
#' @return A single row dataframe with the full second summary of one pair of
#' date variables
#'
get_date_variable_summaries_by_outcome <- function(df, outcome_var) {

  # This function makes use of column names in the dataframe. As these are
  # character strings, dplyr needs to use Standard Evaluation, and therefore
  # needs all of the summaries to be written as formulae

  if (ncol(df) != 3) {
    pairwise_and_outcome_column_error <- paste(
      "The input dataframe from the pairwise summary by outcome",
      "does not have 3 columns"
    )
    stop(pairwise_and_outcome_column_error)
  }

  # Getting the 2 variables: the non-outcome columns
  var_pair <- colnames(df)[2:3]

  a_and_b <- lazyeval::interp(~sum(!is.na(var1) & !is.na(var2)),
                                   var1 = as.name(var_pair[1]),
                                   var2 = as.name(var_pair[2]))
  not_a_and_b <- lazyeval::interp(~sum(is.na(var1) & is.na(var2)),
                                  var1 = as.name(var_pair[1]),
                                  var2 = as.name(var_pair[2]))

  a_before_b <- lazyeval::interp(~sum(var1 < var2, na.rm = TRUE),
                                 var1 = as.name(var_pair[1]),
                                 var2 = as.name(var_pair[2]))

  b_before_a <- lazyeval::interp(~sum(var1 > var2, na.rm = TRUE),
                                 var1 = as.name(var_pair[1]),
                                 var2 = as.name(var_pair[2]))

  a_equal_b <- lazyeval::interp(~sum(var1 == var2, na.rm = TRUE),
                                var1 = as.name(var_pair[1]),
                                var2 = as.name(var_pair[2]))

  summary_df <- df %>%
    dplyr::group_by_(outcome_var) %>%
    dplyr::summarise_(A = ~var_pair[1],
                      B = ~var_pair[2],
                      `A and B Level` = a_and_b,
                      `A and B Proportion Level` = ~`A and B Level` / n(),
                      `A before B Level` = a_before_b,
                      `A before B Proportion Level` = ~`A before B Level` / n(),
                      `Missing A and B Level` = not_a_and_b,
                      `B before A Level` = b_before_a,
                      `B before A Proportion Level` = ~`B before A Level` / n(),
                      `A equal B Level` = a_equal_b,
                      `A equal B Proportion Level` = ~`A equal B Level` /
                        n()) %>%
    dplyr::ungroup() %>%
    dplyr::arrange_(outcome_var)

  # Splitting this into 2 different dataframes based on the outcome var level
  summary_df_col_number <- ncol(summary_df)
  summary_df0 <- summary_df[1, 2:summary_df_col_number]
  summary_df1 <- summary_df[2, 4:summary_df_col_number]

  # Changing the column names and then column binding
  colnames(summary_df0)[3: ncol(summary_df0)] <- paste0(
    colnames(summary_df0)[3: ncol(summary_df0)],
    sep = "_0"
  )

  colnames(summary_df1) <- paste0(
    colnames(summary_df1),
    sep = "_1"
  )

  summary_df <- cbind(summary_df0, summary_df1)

  # Adding in the Delta columns
  summary_df <- summary_df %>%
    dplyr::mutate_(
      `Delta A and B` = ~abs(`A and B Proportion Level_0` -
                               `A and B Proportion Level_1`),
      `Delta A before B` = ~abs(`A before B Proportion Level_0` -
                                  `A before B Proportion Level_1`),
      `Delta B before A` = ~abs(`B before A Proportion Level_0` -
                                  `B before A Proportion Level_1`),
      `Delta A equal B` = ~abs(`A equal B Proportion Level_0` -
                                 `A equal B Proportion Level_1`)) %>%

    # Getting the columns into the desired order
    dplyr::select_(.dots = c("A",
                             "B",
                             "`A and B Level_0`",
                             "`A and B Proportion Level_0`",
                             "`Missing A and B Level_0`",
                             "`A and B Level_1`",
                             "`A and B Proportion Level_1`",
                             "`Missing A and B Level_1`",
                             "`Delta A and B`",
                             "`A before B Level_0`",
                             "`A before B Proportion Level_0`",
                             "`A before B Level_1`",
                             "`A before B Proportion Level_1`",
                             "`Delta A before B`",
                             "`B before A Level_0`",
                             "`B before A Proportion Level_0`",
                             "`B before A Level_1`",
                             "`B before A Proportion Level_1`",
                             "`Delta B before A`",
                             "`A equal B Level_0`",
                             "`A equal B Proportion Level_0`",
                             "`A equal B Level_1`",
                             "`A equal B Proportion Level_1`",
                             "`Delta A equal B`"))

  summary_df
}

#' Get the outcome variable and date variable subset dataframe and date columns
#'
#' This small function takes the original loaded dataframe, and returns a new
#' dataframe with only the information from the outcome variable and the date
#' variables, together with a list of the date columns, required to make the
#' iterator. This is the original dataframe with the id column removed, and is
#' used for the second summary where the summaries are carried out at the
#' different levels of the outcome variable
#'
#' @param event_dates_df A dataframe of the whole dataset
#' @param outcome_var A character string of the outcome variable column name
#' @return A list containing a dataframe with the outcome and date variables and
#' a vector of the date variables
get_outcome_and_date_variables <- function(event_dates_df, outcome_var) {

  # Getting the logical index of date columns
  date_cols_inds <- vapply(
    event_dates_df,
    lubridate::is.Date,
    TRUE
  )

  # Getting the required columns for this information
  date_cols <- colnames(event_dates_df)[date_cols_inds]
  selected_columns <- c(outcome_var, date_cols)

  outcome_and_date_df <- event_dates_df %>%
    dplyr::select_(.dots = selected_columns)

  list(df = outcome_and_date_df, date_cols = date_cols)
}

utils::globalVariables(c("this_df"))
