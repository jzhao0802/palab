context("Binning the continuous/numerical variables")

# Reading in the information required for the analysis
transformed_data <- suppressMessages(
  readr::read_csv('transformed_data.csv')
)

transformed_data_with_index_date <- suppressMessages(
  readr::read_csv("transformed_data_with_index_date.csv")
)

binning_small_output <- suppressMessages(
  readr::read_csv("binning_small_output.csv")
)

binning_small_output_with_index_date <- suppressMessages(
  readr::read_csv("binning_small_output_with_index_date.csv")
)

binning_small_output_qsec_na <- suppressMessages(
  readr::read_csv("binning_small_output_qsec_na.csv")
)

# Testing the functions
test_that("The output with the provided config file is correct", {
  binning_function_output <- binning(
    transformed_data,
    "var_config_generated_with_key.csv",
    "binning_config.csv"
  )
  expect_equal(binning_small_output, binning_function_output)
})

test_that("The output with the provided config file is correct with index date", {
  binning_function_output <- binning(
    transformed_data_with_index_date,
    "var_config_generated_with_key.csv",
    "binning_config.csv"
  )
  expect_equal(binning_function_output, binning_small_output_with_index_date)
})

test_that("The output with the provided config file is correct with NA qsec", {
  transformed_data_qsec_na <- transformed_data
  transformed_data_qsec_na$qsec[1:4] <- NA
  binning_function_output <- binning(
    transformed_data_qsec_na,
    "var_config_generated_with_key.csv",
    "binning_config.csv"
  )
  expect_equal(binning_small_output_qsec_na, binning_function_output)
})

test_that("An error occurs if binning_config_csv contains wrong variables", {
  expect_error(binning(
    transformed_data,
    "var_config_generated_with_key.csv",
    "binning_config_wrong_variable.csv"
  ), "'llamas' values in binning_config_csv not in the numerical input data")
})

test_that("An error occurs if NumBins has any non-integers", {
  expect_error(binning(
    transformed_data,
    "var_config_generated_with_key.csv",
    "binning_config_non_integer_numbin.csv"
  ), "'mpg' contain non-integer 'NumBin' information")
})

test_that("An error occurs if Method column contains values not 'q' or 'r'", {
  expect_error(binning(
    transformed_data,
    "var_config_generated_with_key.csv",
    "binning_config_wrong_method.csv"
  ), "'mpg' contain non valid entries for 'Method'")
})

test_that("An error occurs if the CutPoints column contains single numerics", {
  expect_error(binning(
    transformed_data,
    "var_config_generated_with_key.csv",
    "binning_config_numeric_cutpoints.csv"
  ),
  "Check that the values in the CutPoints column are comma separated numbers")
})

test_that("An error occurs if CutPoints contain non-numeric information", {
  expect_error(binning(
    transformed_data,
    "var_config_generated_with_key.csv",
    "binning_config_non_numeric_cutpoint.csv"
  ), "'mpg', 'wt' contain non-numeric CutPoints information")
})

test_that("An error occurs if CutPoints for quantiles are not 0-1 values", {
  expect_error(binning(
    transformed_data,
    "var_config_generated_with_key.csv",
    "binning_config_wrong_quantile_cutoff.csv"
  ), "'hp', 'drat' contain values not between 0 and 1 for quantile purposes")
})

test_that("An error occurs if ReplaceVal contains values not 'm' or 'o'", {
  expect_error(binning(
    transformed_data,
    "var_config_generated_with_key.csv",
    "binning_config_wrong_replaceval.csv"
  ), "'mpg', 'drat' contain non-valid entries for 'ReplaceVal'")
})


test_that("Error if there is not exclusive entries for Numbins or CutPoints", {
  expect_error(binning(
    transformed_data,
    "var_config_generated_with_key.csv",
    "binning_config_wrong_numbins_and_cutpoints.csv"
  ),
"'mpg', 'drat' do not contain an exclusive entry for 'NumBins' or 'CutPoints'")
})

test_that("An error occurs if the prefix argument is not a character string", {
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    binning_config_csv = "binning_config.csv",
    prefix = TRUE
  ), "'prefix' argument must be a character string")
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    binning_config_csv = "binning_config.csv",
    prefix = 99
  ), "'prefix' argument must be a character string")
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    binning_config_csv = "binning_config.csv",
    prefix = c("Hello", "World")
  ), "'prefix' argument must be a character string")
})

test_that("An error occurs if the output_dir is not a character string of the save path", {
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    binning_config_csv = "binning_config.csv",
    output_dir = TRUE
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    binning_config_csv = "binning_config.csv",
    output_dir = 99
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    binning_config_csv = "binning_config.csv",
    output_dir = c("Hello", "World")
  ), "'output_dir' argument must be a character string of the save path")
})

test_that("The output_csv argument is a single logical value", {
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    binning_config_csv = "binning_config.csv",
    output_csv = "Monkeys"
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    binning_config_csv = "binning_config.csv",
    output_csv = c(FALSE, TRUE)
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    binning_config_csv = "binning_config.csv",
    output_csv = NULL
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    binning_config_csv = "binning_config.csv",
    output_csv = NA
  ), "'output_csv' argument must be a single value of TRUE or FALSE")
})

test_that("An error occurs if 'Column' and 'Type' are not in var_config", {
  expect_error(binning(
    input = transformed_data,
    var_config = "var_config_wrong_Column_name.csv",
    binning_config_csv = "binning_config.csv"
  ), "The var_config dataframe must contain the columns 'Column' and 'Type'")
})
