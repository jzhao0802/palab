context("Testing the bivar_stats_y_flag function")

# Loading in data used for testing
transformed_data <- suppressMessages(
  readr::read_csv("transformed_data.csv")
)

transformed_data_numerical <- suppressMessages(
  readr::read_csv("transformed_data_numerical.csv")
)

transformed_data_numerical_and_vs <- suppressMessages(
  readr::read_csv("transformed_data_numerical_and_vs.csv")
)

expected_output <- suppressMessages(
  readr::read_csv("bivar_stats_y_flag_output_vs.csv")
)

## Performing the tests

# Testing the outputs
test_that("The output with the vs outcome variable is as expected", {
  bivar_stats_y_flag_output <- bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = "vs",
    correlation_warning = FALSE
  )

  expect_equal(bivar_stats_y_flag_output, expected_output)
})

test_that("The flag variable summaries are as expected", {
  expected_flag_variable_output <- suppressMessages(
    readr::read_csv("bivar_stats_flag_variable_summaries.csv")
  )
  flag_variable_output <- bivar_stats_flag_variable_summaries(
    transformed_data_numerical
  )
  expect_equal(flag_variable_output, expected_flag_variable_output)
})

# Testing the user entered inputs
test_that("An error occurs if the input argument is not a dataframe", {
  expect_error(bivar_stats_y_flag(
    var_config = "var_config.csv",
    outcome_var = "vs"
  ), "A dataframe is required for the 'input'argument")
  expect_error(bivar_stats_y_flag(
    input = "not a dataframe",
    var_config = "var_config.csv",
    outcome_var = "vs"
  ), "A dataframe is required for the 'input'argument")
})

test_that("An error occurs if no var_config is given", {
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    outcome_var = "vs"
  ), "'var_config' must be a character string input")
})

test_that("An error occurs if var_config is not a character string", {
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = 32,
    outcome_var = "vs"
  ), "'var_config' must be a character string input")

  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = c("Not", "cool", "at", "all"),
    outcome_var = "vs"
  ), "'var_config' must be a character string input")
})

test_that("An error occurs if the var_config file doesn't exist", {
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "not_here.csv",
    outcome_var = "vs"
  ), "No 'var_config' file found at 'not_here.csv'")
})

test_that("An error occurs if 'Column' and 'Type' are not in var_config", {
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config_wrong_Column_name.csv",
    outcome_var = "vs"
  ), "The var_config dataframe must contain the columns 'Column' and 'Type'")
})

test_that("An error occurs if the outcome_var argument is not a character string", {
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = c("Hello", "World")
  ), "'outcome_var' argument must be a character string")
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = NA
  ), "'outcome_var' argument must be a character string")
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = NULL
  ), "'outcome_var' argument must be a character string")
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = 999
  ), "'outcome_var' argument must be a character string")
})

test_that("An error is raised if the outcome var is not binary", {
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = "carb"
  ), "The values in the 'carb' column contain values that are not 0 or 1")
})

test_that("An error occurs if the prefix argument is not a character string", {
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = "vs",
    prefix = c("Hello", "World")
  ), "'prefix' argument must be a character string")
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = "vs",
    prefix = NA
  ), "'prefix' argument must be a character string")
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = "vs",
    prefix = NULL
  ), "'prefix' argument must be a character string")
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = "vs",
    prefix = 999
  ), "'prefix' argument must be a character string")
})

test_that("An error occurs if output_dir argument is not a character string", {
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = "vs",
    output_dir = c("Hello", "World")
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = "vs",
    output_dir = NA
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = "vs",
    output_dir = NULL
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivar_stats_y_flag(
    input = transformed_data,
    var_config = "var_config.csv",
    outcome_var = "vs",
    output_dir = 999
  ), "'output_dir' argument must be a character string of the save path")
})

# Testing mid-process functions - these really should not fail
test_that("Testing errorsin bivar_stats_flag_variable_outcome_summaries", {
  expect_error(
    bivar_stats_flag_variable_outcome_summaries(
      transformed_data_numerical_and_vs,
      c("mpg", "qsec", "donkeys"),
      "vs",
      TRUE
    ), "Entries in 'variables' not in the input data"
  )
  expect_error(
    bivar_stats_flag_variable_outcome_summaries(
      transformed_data_numerical,
      c("mpg", "disp", "hp", "drat", "wt", "qsec"),
      "vs",
      TRUE
    ), "The 'outcome_var' value is not in the input data"
  )
})






