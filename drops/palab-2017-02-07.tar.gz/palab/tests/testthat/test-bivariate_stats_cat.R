context("Testing Bivariate Statistics for Categorical Variables")

# Loading in data used for testing
transformed_data <- suppressMessages(
  readr::read_csv("transformed_data.csv")
)

transformed_data_categorical <- suppressMessages(
  readr::read_csv("transformed_data_categorical.csv")
)

cat_cat_output_expected <- suppressMessages(
  readr::read_csv("bivar_stats_y_cat_x_cat_test_input.csv",
                  col_types = "ccnnnnnn")
)

# Getting the correct datatypes for numerical summary read in
num_dtypes <- paste(c("c", rep("n", 34)), collapse = "")
cat_num_output_expected <- suppressMessages(
  readr::read_csv("bivar_stats_y_cat_x_num_test_input.csv",
                  col_types = num_dtypes)
)

cat_cat_gathered_output_expected <- suppressMessages(
  readr::read_csv("bivar_cat_cat_gathered_summary.csv")
)

cat_cat_count_summary_expected <- suppressMessages(
  readr::read_csv("bivar_cat_cat_count_summary.csv", col_types = "ccnn")
)

cat_cat_prop_level_summary_expected <- suppressMessages(
  readr::read_csv("bivar_cat_cat_prop_level_summary.csv")
)

cat_cat_prop_outcome_summary_expected <- suppressMessages(
  readr::read_csv("bivar_cat_cat_prop_outcome_summary.csv")
)

## Performing the tests
# Testing the user entered inputs
test_that("An error occurs if the input argument is not a dataframe", {
  expect_error(bivariate_stats_cat(
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs"
  ), "A dataframe is required for the 'input'argument")
  expect_error(bivariate_stats_cat(
    input = "not a dataframe",
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs"
  ), "A dataframe is required for the 'input'argument")
})

test_that("An error occurs if no var_config is given", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    outcome_var = "vs"
  ), "'var_config' must be a character string input")
})

test_that("An error occurs if var_config is not a character string", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = 32,
    outcome_var = "vs"
  ), "'var_config' must be a character string input")

  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = c("Not", "cool", "at", "all"),
    outcome_var = "vs"
  ), "'var_config' must be a character string input")
})

test_that("An error occurs if the var_config file doesn't exist", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "not_here.csv",
    outcome_var = "vs"
  ), "No 'var_config' file found at 'not_here.csv'")
})

test_that("An error occurs if 'Column' and 'Type' are not in var_config", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_wrong_Column_name.csv",
    outcome_var = "vs"
  ), "The var_config dataframe must contain the columns 'Column' and 'Type'")
})

test_that("An error occurs if there are no categorical variables", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key_all_num.csv",
    outcome_var = "vs"
  ), "There are no categorical variables present")
})

test_that("An error occurs is no outcome_var argument is provided",{
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv"
  ), "A character string must be given for the 'outcome_var' argument")
})


test_that("An error occurs if the outcome_var argument is not a character string", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = c("Hello", "World")
  ), "'outcome_var' argument must be a character string")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = NA
  ), "'outcome_var' argument must be a character string")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = NULL
  ), "'outcome_var' argument must be a character string")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = 999
  ), "'outcome_var' argument must be a character string")
})

test_that("An error occurs if the prefix argument is not a character string", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    prefix = c("Hello", "World")
  ), "'prefix' argument must be a character string")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    prefix = NA
  ), "'prefix' argument must be a character string")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    prefix = NULL
  ), "'prefix' argument must be a character string")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    prefix = 999
  ), "'prefix' argument must be a character string")
})

test_that("An error occurs if output_dir argument is not a character string", {
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    output_dir = c("Hello", "World")
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    output_dir = NA
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    output_dir = NULL
  ), "'output_dir' argument must be a character string of the save path")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    output_dir = 999
  ), "'output_dir' argument must be a character string of the save path")
})

test_that("An error occurs if the count argument is not a whole number",{
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    count = c(1, 12)
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    count = NA
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    count = NULL
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    count = 87.4
  ), "'count' argument must be a numeric whole number")
  expect_error(bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs",
    count = "bananas"
  ), "'count' argument must be a numeric whole number")
})

test_that("A warning is given if the outcome variable is not categorical", {
  expect_warning(
    bivariate_stats_cat(
      input = transformed_data,
      var_config = "var_config_generated_with_key.csv",
      outcome_var = "mpg"
    ), "The outcome_var 'mpg' is not classified as a categorical variable"
  )
})

test_that("An error occurs when the outcome_var isn't in the dataframe",{
  expect_error(bivariate_stats_cat(
    input = transformed_data_categorical
    ,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "honeybee"
  ), "'honeybee' is not a variable in the input data")
})

test_that("An warning is given if the outcome var has too few levels", {
  var_level_check_df <- dplyr::data_frame(
    one = seq(6),
    two = rep(c("Hello", "World"), 3)
  )

  expect_warning(check_level_count(
    input_df = var_level_check_df,
    variable = "one",
    count = 4,
    ltgt = "lt"
  ), "The number of unique levels in 'one' is greater than 4")

  expect_warning(check_level_count(
    input_df = var_level_check_df,
    variable = "two",
    count = 4,
    ltgt = "gt"
  ), "The number of unique levels in 'two' is less than 4")
})


test_that("The cat-cat gathered summary is correct", {
  cat_cat_summary_output <- get_gathered_summary_df(
    input = transformed_data_categorical,
    outcome_var = "vs"
  )
  # At this point, the first column in the data is a factor, but it must
  # be a character type for the tests
  cat_cat_summary_output$`Categorical variable` <-
    as.character(cat_cat_summary_output$`Categorical variable`)
  expect_equal(cat_cat_summary_output, cat_cat_gathered_output_expected)
})

test_that("The count summary for cat-cat is correct", {
  cat_cat_count_summary <- get_level_count_information(
    summary_input = cat_cat_gathered_output_expected,
    outcome_var = "vs"
  )
  # At this point, the first column in the data is a factor, but it must
  # be a character type for the tests
  cat_cat_count_summary$`Categorical variable` <-
    as.character(cat_cat_count_summary$`Categorical variable`)
  expect_equal(cat_cat_count_summary, cat_cat_count_summary_expected)
})

test_that("The level proportion summary for cat-cat is correct", {
  cat_cat_prop_level_summary <- get_proportion_information(
    summary_input = cat_cat_gathered_output_expected,
    outcome_var = "vs",
    divisor_column = "Total_outcome_level",
    prefix = "Proportion of Level_"
  )
  expect_equal(cat_cat_prop_level_summary, cat_cat_prop_level_summary_expected)
})

test_that("The outcome proportion summary for cat-cat is correct", {
  cat_cat_prop_outcome_summary <- get_proportion_information(
    summary_input = cat_cat_gathered_output_expected,
    outcome_var = "vs",
    divisor_column = "Total_variable_level",
    prefix = "Proportion of Outcome_"
  )
  expect_equal(cat_cat_prop_outcome_summary,
               cat_cat_prop_outcome_summary_expected)
})

test_that("The cat summary is as expected", {
  cat_cat_output <- bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs"
  )$cat
  cat_cat_output <- as.data.frame(cat_cat_output)

  # Have to do a test of equivalence here as the attributes were not matching
  # The values are exactly the same, it's just that the data transformations
  # must be causing an issue
  expect_equivalent(cat_cat_output, cat_cat_output_expected)
})

test_that("The num summary is as expected", {
  cat_num_output <- bivariate_stats_cat(
    input = transformed_data,
    var_config = "var_config_generated_with_key.csv",
    outcome_var = "vs"
  )$num

  # Removing the 'spec' attribute from the expected output, as this is causing
  # the testing error, and expect_equivalent cannot be used as it won't accept
  # a tolerance argument. Also changing to base data.frames
  cat_num_output <- as.data.frame(cat_num_output)
  cat_num_output_expected <- as.data.frame(cat_num_output_expected)
  attr(cat_num_output_expected, "spec") <- NULL
  expect_equal(cat_num_output, cat_num_output_expected, tolerance = 1e-2)
})


unlink("bivar_stats_y_cat_x_cat.csv")
unlink("bivar_stats_y_cat_x_num.csv")
