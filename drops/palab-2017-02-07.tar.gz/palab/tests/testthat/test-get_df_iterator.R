context("The iterators to get column subsets are working")

# Loading in the date information
event_dates_df <- suppressMessages(
  readr::read_csv("event_dates.csv")
)

test_that("The pairwise iterators are returning the correct information", {
  date_df <- event_dates_df[, -c(1, 2)]
  pairwise_cols <- utils::combn(colnames(date_df), 2)

  # Transposing these so that the iterator can calculate them by row
  pairwise_cols <- t(pairwise_cols)

  df_iterator <- get_df_iterator(pairwise_cols, date_df)
  expect_equal(iterators::nextElem(df_iterator),
               date_df[, pairwise_cols[1,]])
  expect_equal(iterators::nextElem(df_iterator),
               date_df[, pairwise_cols[2,]])
  expect_equal(iterators::nextElem(df_iterator),
               date_df[, pairwise_cols[3,]])
  expect_error(iterators::nextElem(df_iterator), "StopIteration")
})

test_that("The function is also working when the outcome variable is used", {
  date_df <- event_dates_df[, -c(1, 2)]
  outcome_and_date_df <- event_dates_df[, -1]
  pairwise_cols <- utils::combn(colnames(date_df), 2)

  # Transposing these so that the iterator can calculate them by row
  pairwise_cols <- t(pairwise_cols)

  outcome_and_pairs <- cbind(
    rep("outcome_var", nrow(pairwise_cols)),
    pairwise_cols
  )

  df_iterator <- get_df_iterator(outcome_and_pairs, outcome_and_date_df)
  expect_equal(iterators::nextElem(df_iterator),
               outcome_and_date_df[, outcome_and_pairs[1,]])
  expect_equal(iterators::nextElem(df_iterator),
               outcome_and_date_df[, outcome_and_pairs[2,]])
  expect_equal(iterators::nextElem(df_iterator),
               outcome_and_date_df[, outcome_and_pairs[3,]])
  expect_error(iterators::nextElem(df_iterator), "StopIteration")
})
