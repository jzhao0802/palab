context("Testing the loading and checking of date information")

# Loading in required data
event_dates_df <- suppressMessages(
  readr::read_csv("event_dates.csv", na = c("nil"))
)

event_dates_no_outcome <- suppressMessages(
  readr::read_csv("event_dates_no_outcome.csv", na = c("nil"))
)

# Testing
test_that("An error is raised if the event data cannot be parsed into dates", {
  expect_error(load_check_date_dataframe(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var"
  ), "Date columns not parsing as dates. Check missing values and date format")

  expect_error(load_check_date_dataframe(
    event_dates = "event_dates_no_outcome.csv",
    id_column = "patient_id"
  ), "Date columns not parsing as dates. Check missing values and date format")
})

test_that("An error occurs if the id_column is not in the dataframe", {
  expect_error(load_check_date_dataframe(
    event_dates = "event_dates.csv",
    id_column = "bananas"
  ), "The column 'bananas' is not in the data")
})

test_that("An error occurs if the outcome_var is not in the dataframe", {
  expect_error(load_check_date_dataframe(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "lentils"
  ), "The column 'lentils' is not in the data")
})

test_that("An error occurs if the outcome var column is not binary", {
  expect_error(load_check_date_dataframe(
    event_dates = "event_dates_non_binary.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var"
  ), "The 'outcome_var' column does not contain only 0 and 1 values")
})
test_that("The event data loads correctly when there are no errors", {
  event_dates_df_output <- load_check_date_dataframe(
    event_dates = "event_dates.csv",
    user_missing_values = c("nil"),
    id_column = "patient_id",
    outcome_var = "outcome_var"
  )
  expect_equal(event_dates_df, event_dates_df_output)

  event_dates_df_output_no_outcome <- load_check_date_dataframe(
    event_dates = "event_dates_no_outcome.csv",
    user_missing_values = c("nil"),
    id_column = "patient_id"
  )
  expect_equal(event_dates_no_outcome, event_dates_df_output_no_outcome)
})
