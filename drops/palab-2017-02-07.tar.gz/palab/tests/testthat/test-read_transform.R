context("Reading and Transforming")

## This first section loads in all of the data needed for testing

# This file contains a column of row warnings, which needs to be removed
expected_df <- suppressWarnings(suppressMessages(
  readr::read_csv("transformed_data.csv")))

expected_df_nill_in_mpg <- suppressWarnings(suppressMessages(
  readr::read_csv("mtcars_nill_in_mpg_expected.csv")
))

# Loading in the mtcars with the rows removed with the missing values for gears
mtcars_gears_missing <- suppressMessages(
  readr::read_csv("mtcars_missing_gear_removed.csv")
)

# Loading in the mtcars with the vs and am columns removed
mtcars_vs_am_removed <- suppressMessages(
  readr::read_csv("mtcars_vs_am_removed.csv")
)

# Loading in the original var_config information
var_config_orig <- suppressMessages(readr::read_csv("var_config.csv"))

# var_config with vs and am removed
var_config_vs_am_removed <- suppressMessages(
  readr::read_csv("var_config_vs_am_removed.csv")
)


## The remaining section contains all the tests

test_that("mtcars df results in expected df with nothing wrong", {
  read_transform_output <- read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config.csv",
    missing_values = "-99, -999"
  )
  expect_equal(read_transform_output$data, expected_df)
})

test_that("mtcars df results in expected df with nothing wrong, read.csv", {
  read_transform_output <- read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config.csv",
    missing_values = "-99, -999",
    use_base_loading = TRUE
  )
  expect_equivalent(read_transform_output$data, expected_df)
})

test_that("mtcars df results in expected df with nothing wrong with outcome_var", {
  read_transform_output <- read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config.csv",
    missing_values = "-99, -999",
    outcome_var = "disp"
  )
  expect_equal(read_transform_output$data, expected_df)
})

test_that("All is expected with missing values in numeric variables", {
  read_transform_output_nill_in_mpg <- read_transform(
    input_csv = "mtcars_nill_in_mpg.csv",
    var_config_csv = "var_config.csv",
    missing_values = "-99, -999, Nill"
  )
  expect_equal(read_transform_output_nill_in_mpg$data,
               expected_df_nill_in_mpg)
})

test_that("A warning is raised if columns are dropped", {
  expect_warning(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config_no_qsec_vs.csv",
    missing_values = "-99, -999"
  ),
  "'qsec', 'am' variables being removed as they are not in the var_config file")
})

# The following 3 tests are actually carried out by the helper function
# check_input_file_variables, but is checked by calling the main function

test_that("Errors occur when no values for the input files are given", {
  both_null <- "You need to enter values for 'input_csv' and 'var_config'"
  input_null <- "You need to enter a value for 'input_csv'"
  var_config_null <- "You need to enter a value for 'var_config'"
  expect_error(read_transform(), both_null)
  expect_error(read_transform(var_config_csv = "var_config.csv"), input_null)
  expect_error(read_transform(input_csv = "mtcars.csv"), var_config_null)
})

test_that("Errors occur in the input files are not character strings", {
  input_character_error <- "'input_df' argument must be a character string"
  var_config_character_error <-
    "'var_config_csv' argument must be a character string"
  expect_error(read_transform(123, "var_config.csv"), input_character_error)
  expect_error(read_transform(NA, "var_config.csv"), input_character_error)
  expect_error(read_transform(NULL, "var_config.csv"), input_character_error)
  expect_error(read_transform("mtcars.csv", 123), var_config_character_error)
  expect_error(read_transform("mtcars.csv", NA), var_config_character_error)
  expect_error(read_transform("mtcars.csv", NULL), var_config_character_error)
})

test_that("Errors occur if the input files don't exist", {
  wrong_input <- "this/does/not/exist/input.csv"
  wrong_var_config <- "this/does/not/exist/var_config.csv"
  both_error_message <- sprintf("Both files '%s' and '%s' do not exist",
                                wrong_input, wrong_var_config)
  input_error_message <- sprintf("File '%s' does not exist", wrong_input)
  var_config_error_message <- sprintf("File '%s' does not exist",
                                      wrong_var_config)

  # When both files don't exist
  expect_error(read_transform(
    input_csv = wrong_input,
    var_config_csv = wrong_var_config
  ), both_error_message)

  # When only the input file doesn't exist
  expect_error(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = wrong_var_config
  ), var_config_error_message)

  # When only the var_config file doesn't exist
  expect_error(read_transform(
    input_csv = wrong_input,
    var_config_csv = "var_config.csv"
  ), input_error_message)
})

test_that("Errors occur if max_levels is not a whole number", {
  max_levels_error_message <-
    "'max_levels' argument must be a numeric whole number"
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              max_levels = "bananas"), max_levels_error_message)
   expect_error(read_transform("mtcars.csv", "var_config.csv",
                               max_levels = numeric(0)),
                max_levels_error_message)
   expect_error(read_transform("mtcars.csv", "var_config.csv",
                               max_levels = 1.12), max_levels_error_message)
})

test_that("Errors occur if the prefix argument is not a character string", {
  prefix_error_message <- "'prefix' argument must be a character string"
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              prefix = 123), prefix_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              prefix = character(0)), prefix_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              prefix = NA), prefix_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              prefix = NULL), prefix_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              prefix = c(NA, NA)), prefix_error_message)
})

test_that("Errors occur if missing_values argument is not a character string", {
  missing_values_error_message <-
    "'missing_values' argument must be a character string"
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              missing_values = 123),
               missing_values_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              missing_values = character(0)),
               missing_values_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              missing_values = NA),
               missing_values_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              missing_values = NULL),
               missing_values_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              missing_values = c(NA, NA)),
               missing_values_error_message)
})

test_that("Errors occur if output_dir argument is not a character string", {
  output_dir_error_message <- "'output_dir' argument must be a character string"
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              output_dir = 123), output_dir_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              output_dir = character(0)),
               output_dir_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              output_dir = NA), output_dir_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              output_dir = NULL), output_dir_error_message)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              output_dir = c(NA, NA)), output_dir_error_message)
})

test_that("Errors occur if output_csv if not a logical value", {
  output_csv_error <- "'output_csv' argument must be either TRUE or FALSE"
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              output_csv = "wizards"), output_csv_error)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              output_csv = c(TRUE, FALSE)),
               output_csv_error)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              output_csv = NULL), output_csv_error)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              output_csv = NA), output_csv_error)
})

test_that("Errors occur if outcome_var is not either NULL or character", {
  outcome_var_error <-
    "If entering a value for 'outcome_var', it must be a character string"
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              outcome_var = NA), outcome_var_error)
  expect_error(read_transform("mtcars.csv", "var_config.csv",
                              outcome_var = 99), outcome_var_error)
})

test_that("Errors occur if the input files are empty or have no row info", {

  # Both files are empty
  expect_error(read_transform(
    input_csv = "empty.csv",
    var_config_csv = "empty.csv"
  ), "Both 'input_csv' and 'var_config' are empty files")

  # The input_df is empty
  expect_error(read_transform(
    input_csv = "empty.csv",
    var_config_csv = "var_config.csv"
  ), "The 'input_csv' dataframe contains no rows or columns")

  # The input_df has no rows
  expect_error(read_transform(
    input_csv = "mtcars_no_rows.csv",
    var_config_csv = "var_config.csv"
  ), "The 'input_csv' dataframe contains no rows")

  # The var_config dataframe is empty
  expect_error(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "empty.csv"
  ), "The 'var_config' dataframe contains no rows or columns")

  # The var_config dataframe has no rows
  expect_error(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config_no_rows.csv"
  ), "The 'var_config' dataframe contains no rows")
})

test_that("The column names in 'var_config' are correct", {
  expect_error(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config_one_column.csv"
  ), "'var_config' must have at least 2 columns: 'Column' and 'Type'")

  expect_error(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config_wrong_Column_name.csv"
  ), "The first column of 'var_config' must be called 'Column'")

  expect_error(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config_wrong_Type_name.csv"
  ), "The second column of 'var_config' must be called 'Type'")
})

# Checking the inputs of the Type column in var_config. This is carried out
# by check_var_config_column_types, but is being tested using the main function

test_that("Entries in the Type column are replaced if needed", {
  expect_warning(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config_wrong_Type_entries.csv"
  ), "3 Type row entries replaced by 'other'")
})


test_that("Error when numeric variable contains non-numeric values", {
  expect_error(read_transform(
      input_csv = "mtcars_mpg_disp_not_numeric.csv",
      var_config_csv = "var_config.csv",
      missing_values = "-99, -999"
    ), regexp = "contain non numeric data$"
  )
})

test_that("Error thrown when outcome_var is not in the data", {
  expect_error(read_transform(
      input_csv = "mtcars.csv",
      var_config_csv = "var_config.csv",
      missing_values = "-99, -999",
      outcome_var = "Dragons"
    ), "The outcome_var 'Dragons' is not in the data"
  )
})

test_that("Warning raised when max_levels is exceeded by a categorical input", {
  expect_warning(read_transform(
      input_csv = "mtcars.csv",
      var_config_csv = "var_config.csv",
      missing_values = "-99, -999",
      max_levels = 2
    ), regexp = "contain more unique values than 'max_levels'$"
  )
})

test_that("Error thrown if no key variable is provided", {
  expect_error(read_transform(
      input_csv = "mtcars.csv",
      var_config_csv = "var_config_no_key.csv",
      missing_values = "-99, -999"
    ), "There is no variable listed with a Type value of 'key'"
  )
})

test_that("Error thrown if multiple keys are provided", {
  expect_error(read_transform(
      input_csv = "mtcars.csv",
      var_config_csv = "var_config_multiple_keys.csv",
      missing_values = "-99, -999"
    ), regexp = "are labelled as 'key'$"
  )
})

test_that("Correct rows are removed with missing values for outcome variable", {
  read_transform_output_outcome_gears <- read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config.csv",
    missing_values = "-99, -999",
    outcome_var = "gear"
  )
  expect_equal(read_transform_output_outcome_gears$data, mtcars_gears_missing)
})

test_that("Correct columns are removed if not listed in var_config", {
  read_transform_out_vs_am_removed <- suppressWarnings(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config_vs_am_removed.csv",
    missing_values = "-99, -999"
  )
  )
  expect_equal(read_transform_out_vs_am_removed$data, mtcars_vs_am_removed)
})

test_that("Numerical variables must contain numeric information", {
  numerical_and_categorical_df <- dplyr::data_frame(
    one = seq(1, 3),
    two = seq(4, 6),
    three = c("Hello", "World", "Universe"),
    four = c("Goodbye", "Galaxy", "Again")
  )
  correct_var_info_df <- dplyr::data_frame(
    Column = c("one", "two", "three", "four"),
    Type = c("numerical", "numerical", "categorical", "categorical")
  )
  wrong_var_info_df <- dplyr::data_frame(
    Column = c("one", "two", "three", "four"),
    Type = rep("numerical", 4)
  )
  numeric_check_correct <- find_problem_numeric_variables(
    numerical_and_categorical_df, correct_var_info_df
  )
  expect_length(numeric_check_correct, 0)

  numeric_check_wrong <- find_problem_numeric_variables(
    numerical_and_categorical_df, wrong_var_info_df
  )
  expect_length(numeric_check_wrong, 2)
})

test_that("Columns not specified in var_config are removed", {
  input_df_complete <- dplyr::data_frame(
    "one" = seq(1, 10),
    "two" = seq(1, 10),
    "three" = seq(1, 10)
  )
  var_config_df_complete <- dplyr::data_frame(
    Column = c("one", "two", "three"),
    Type = rep("numerical", 3)
  )
  complete_df_result <- drop_non_listed_columns(input_df_complete,
                                                var_config_df_complete)
  complete_df_output <- complete_df_result
  expect_equal(input_df_complete, complete_df_output)

  input_df_dropped <- input_df_complete[, -3]
  var_config_dropped <- var_config_df_complete[-3,]
  dropped_df_result <- drop_non_listed_columns(input_df_complete,
                                             var_config_dropped)
  dropped_df_output <- dropped_df_result
  expect_equal(input_df_dropped, dropped_df_output)
})

test_that("Categorical variables exceeding max_levels", {
  max_levels <- 3
  numerical_and_categorical_df_within <- dplyr::data_frame(
    one = seq(1, 4),
    two = seq(5, 8),
    three = c("Hello", "World", "Universe", "Hello"),
    four = c("Goodbye", "Galaxy", "Again", "Goodbye")
  )
  numerical_and_categorical_df_outside <- dplyr::data_frame(
    one = seq(1, 4),
    two = seq(5, 8),
    three = c("Hello", "World", "Universe", "Nebula"),
    four = c("Goodbye", "Galaxy", "Again", "Nebula")
  )
  var_info_df <- dplyr::data_frame(
    Column = c("one", "two", "three", "four"),
    Type = c("numerical", "numerical", "categorical", "categorical")
  )
  within_max_levels <- check_categorical_levels(
    numerical_and_categorical_df_within, var_info_df, max_levels
  )
  expect_length(within_max_levels, 0)

  outside_max_levels <- check_categorical_levels(
    numerical_and_categorical_df_outside, var_info_df, max_levels
  )
  expect_length(outside_max_levels, 2)

  # Checking that it can cope with inputs with no categorical data
  numeric_data <- numerical_and_categorical_df_outside[, c(1, 2)]
  numeric_var_info_df <- var_info_df[c(1, 2), ]

  all_numeric_result <- check_categorical_levels(
    numeric_data, numeric_var_info_df, max_levels
  )
  expect_length(all_numeric_result, 0)
})

test_that("There must be 1, but only 1 key variable. With unique values", {
  input_df_keys <- dplyr::data_frame(
    one = c("Apples", "Oranges", "Bananas", "Mangoes"),
    two = c("Elm", "Oak", "Ash", "Ash"),
    three = seq(1, 4)
  )
  key_var_info_no_key <- dplyr::data_frame(
    Column = c("one", "two", "three"),
    Type = c("categorical", "categorical", "numerical")
  )
  key_var_info_too_many <- dplyr::data_frame(
    Column = c("one", "two", "three"),
    Type = c("key", "key", "numerical")
  )
  key_var_info_not_unique <- dplyr::data_frame(
    Column = c("one", "two", "three"),
    Type = c("categorical", "key", "numerical")
  )
  key_var_info_correct <- dplyr::data_frame(
    Column = c("one", "two", "three"),
    Type = c("key", "categorical", "numerical")
  )

  # Testing situation when no variable is listed as a key
  result_no_key <- check_key_information(
    input_df_keys, key_var_info_no_key
  )
  expect_equal(result_no_key, "There is no variable listed with a Type value of 'key'")

  # Testing situation where there are 2 or more variables labelled as keys
  result_two_keys <- check_key_information(
    input_df_keys, key_var_info_too_many
  )
  expect_equal(result_two_keys, "Columns: 'one', 'two', are labelled as 'key'")

  # Testing the situation where the values in the key column are not unique
  result_non_unique_key_values <- check_key_information(
    input_df_keys, key_var_info_not_unique
  )
  expect_equal(result_non_unique_key_values,
               "There are 4 entries but only 3 unique values")

  # And testing when it's working correctly
  result_keys_correct <- check_key_information(
    input_df_keys, key_var_info_correct
  )
  expect_length(result_keys_correct, 0)
})

test_that("The missing_values input is checked properly", {
  # An error is thrown if missing_values contains empty values
  # This error is actually thrown in remove_coded_missing_values, but is being
  # tested from the parent function of read_transform
  expect_error(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config.csv",
    missing_values = "-99,,-999"
  ), "'missing_values' contains empty values")
})

test_that("Correct type information after transformation is returned", {
  # Only the index_date row removed
  read_transform_output <- read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config.csv",
    missing_values = "-99, -999"
  )
  remaining_info <- remaining_var_config_information(
    read_transform_output$data,
    var_config_orig
  )
  expect_equal(remaining_info$categorical_count, 5)
  expect_equal(remaining_info$numerical_count, 6)
  expect_equal(remaining_info$other_count, 0)

  # Testing the situation when the vs and am categories are removed
  read_transform_output <- suppressWarnings(read_transform(
    input_csv = "mtcars.csv",
    var_config_csv = "var_config_vs_am_removed.csv",
    missing_values = "-99, -999"
  )
  )
  remaining_info <- remaining_var_config_information(
    read_transform_output$data,
    var_config_vs_am_removed
  )
  expect_equal(remaining_info$categorical_count, 3)
  expect_equal(remaining_info$numerical_count, 6)
  expect_equal(remaining_info$other_count, 0)
})

