context("Testing the seq_vars_create function")

# Loading in required data
event_dates_df <- suppressMessages(
  readr::read_csv("event_dates.csv", na = c("nil"))
)

seq_var_selection_df <- suppressMessages(
  readr::read_csv("seq_vars_selection.csv")
)

# Testing
test_that("An error occurs if no event_dates argument is entered", {
  expect_error(seq_vars_create(
    id_column = "patient_id"
  ), "'event_dates' must be entered and must be a character string")

  expect_error(seq_vars_create(
    event_dates = c("Not", "single", "string"),
    id_column = "patient_id"
  ), "'event_dates' must be entered and must be a character string")

  expect_error(seq_vars_create(
    event_dates = 12,
    id_column = "patient_id"
  ), "'event_dates' must be entered and must be a character string")
})

test_that("An error occurs if the event_dates file does not exist", {
  expect_error(seq_vars_create(
    event_dates = "not_here.csv",
    seq_vars_selection = "seq_vars_selection.csv"
  ), "The file 'not_here.csv' does not exist")
})

test_that("An error occurs if no seq_vars_selection argument is entered", {
  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    id_column = "patient_id"
  ), "'seq_vars_selection' must be entered and must be a character string")

  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    seq_vars_selection = c("Not", "single", "string"),
    id_column = "patient_id"
  ), "'seq_vars_selection' must be entered and must be a character string")

  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    seq_vars_selection = 12,
    id_column = "patient_id"
  ), "'seq_vars_selection' must be entered and must be a character string")
})

test_that("An error occurs if the seq_vars_selection file does not exist", {
  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    seq_vars_selection = "not_here.csv"
  ), "The file 'not_here.csv' does not exist")
})

test_that("An error occurs if no id_column argument is entered", {
  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    seq_vars_selection = "seq_vars_selection.csv"
  ), "'id_column' must be entered and must be a character string")

  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    seq_vars_selection = "seq_vars_selection.csv",
    id_column = c("hello", "world")
  ), "'id_column' must be entered and must be a character string")

  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    seq_vars_selection = "seq_vars_selection.csv",
    id_column = TRUE
  ), "'id_column' must be entered and must be a character string")
})

test_that("an error occurs if outcome_var argument is not a character string", {
  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    seq_vars_selection = "seq_vars_selection.csv",
    outcome_var = c("banana", "republic")
  ), "If a value is entered for 'outcome_var' then it must be a character string")

  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    seq_vars_selection = "seq_vars_selection.csv",
    outcome_var = TRUE
  ), "If a value is entered for 'outcome_var' then it must be a character string")

  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    seq_vars_selection = "seq_vars_selection.csv",
    id_column = "patient_id",
    outcome_var = 123
  ), "If a value is entered for 'outcome_var' then it must be a character string")
})

test_that("an error occurs if missing_values is not a character string", {
  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    seq_vars_selection = "seq_vars_selection.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    missing_values = TRUE
  ), "'missing_values' must be a comma separated string")

  expect_error(seq_vars_create(
    event_dates = "event_dates.csv",
    seq_vars_selection = "seq_vars_selection.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    missing_values = 123
  ), "'missing_values' must be a comma separated string")
})

test_that("An error is raised if seq_vars_selection does not have 5 columns", {
  expect_error(check_and_load_seq_vars_selection(
    seq_vars_selection = "seq_vars_selection_4_columns.csv",
    event_dates_df = event_dates_df
  ), "The 'seq_vars_selection' dataframe must contain 5 columns of data")
})

test_that("An error is raised if seq_vars_selection does not contain A and B", {
  expect_error(check_and_load_seq_vars_selection(
    seq_vars_selection = "seq_vars_selection_not_AB.csv",
    event_dates_df = event_dates_df
  ), "'seq_vars_selection' must contain the columns 'A' and 'B'")
})

test_that("An error is raised if Before, After and Equal are not in seq_vars_selection", {
  expect_error(check_and_load_seq_vars_selection(
    seq_vars_selection = "seq_vars_selection_wrong_methods.csv",
    event_dates_df = event_dates_df
  ), "'seq_vars_selection' must have columns: 'Before', 'After' and 'Equal")
})

test_that("An error is raised if seq_var_selections contains variables not in main data", {
  expect_error(check_and_load_seq_vars_selection(
    seq_vars_selection = "seq_vars_selection_wrong_var.csv",
    event_dates_df = event_dates_df
  ), "'seq_var_selections' contain variables not included in 'event_dates")
})

test_that("An error occurs with non-logical entries in seq_vars_selection", {
  all_logical_error <- paste(
    "The 'Before', 'After', and 'Equal' columns in 'seq_vars_selection'",
    "must be TRUE or FALSE only"
  )
  expect_error(check_and_load_seq_vars_selection(
    seq_vars_selection = "seq_vars_selection_wrong_method_value.csv",
    event_dates_df = event_dates_df
  ), all_logical_error)
})

test_that("A warning is raised if a row is removed from seq_var_selections", {
  warning_message <- paste(
    "'3'",
    "Row numbers do not contain any TRUE values in 'seq_vars_selection'.\n",
    "These rows are being removed."
  )
  expect_warning(check_and_load_seq_vars_selection(
    seq_vars_selection = "seq_vars_selection_no_true.csv",
    event_dates_df
  ), warning_message)
})

test_that("The loading of seq_vars_selection goes fine with no error", {
  seq_var_output <- check_and_load_seq_vars_selection(
    seq_vars_selection = "seq_vars_selection.csv",
    event_dates_df = event_dates_df
  )
  expect_equal(seq_var_output, seq_var_selection_df)
})

test_that("The output from the single flag summary is correct", {
  pair_df <- event_dates_df[, c("sympx", "procx")]
  output_flag_before <- get_flag_column(pair_df, "Before")
  output_flag_after <- get_flag_column(pair_df, "After")
  output_flag_equal <- get_flag_column(pair_df, "Equal")
  expect_equal(colnames(output_flag_before), "sympx_BEFORE_procx")
  expect_equal(colnames(output_flag_after), "sympx_AFTER_procx")
  expect_equal(colnames(output_flag_equal), "sympx_EQUAL_procx")
})

test_that("Errors occur if the method parameter is incorrect", {
  pair_df <- event_dates_df[, c("sympx", "procx")]
  expect_error(get_flag_column(pair_df, "before"),
               "'before' is not a valid value for 'method'")
  expect_error(get_single_flag_summary(
    event_dates_df = event_dates_df,
    seq_vars_selection_df = seq_var_selection_df,
    method = "before"
  ), "'before' is not a valid value for 'method'")
})



















