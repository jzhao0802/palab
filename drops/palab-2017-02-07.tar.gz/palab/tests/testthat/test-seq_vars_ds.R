context("Testing the seq_var_ds function")

# Loading in required data
event_dates_df <- suppressMessages(
  readr::read_csv("event_dates.csv", na = c("nil"))
)

event_dates_no_outcome <- suppressMessages(
  readr::read_csv("event_dates_no_outcome.csv", na = c("nil"))
)

# Testing
test_that("An error occurs if no event_dates argument is entered", {
  expect_error(seq_vars_ds(
    id_column = "patient_id"
  ), "'event_dates' must be entered and must be a character string")

  expect_error(seq_vars_ds(
    event_dates = c("Not", "single", "string"),
    id_column = "patient_id"
  ), "'event_dates' must be entered and must be a character string")

  expect_error(seq_vars_ds(
    event_dates = 12,
    id_column = "patient_id"
  ), "'event_dates' must be entered and must be a character string")
})

test_that("An error occurs if no id_column argument is entered", {
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv"
  ), "'id_column' must be entered and must be a character string")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = c("hello", "world")
  ), "'id_column' must be entered and must be a character string")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = TRUE
  ), "'id_column' must be entered and must be a character string")
})

test_that("an error occurs if outcome_var argument is not a character string", {
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = c("banana", "republic")
  ), "If a value is entered for 'outcome_var' then it must be a character string")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = TRUE
  ), "If a value is entered for 'outcome_var' then it must be a character string")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = 123
  ), "If a value is entered for 'outcome_var' then it must be a character string")
})

test_that("an error occurs if missing_values is not a character string", {
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    missing_values = TRUE
  ), "'missing_values' must be a comma separated string")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    missing_values = 123
  ), "'missing_values' must be a comma separated string")
})

test_that("An error occurs if freq_thrsh is not a numeric between 0 and 1", {
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    freq_thrsh = 1.1
  ), "'freq_thrsh' must be a numeric value between 0 and 1")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    freq_thrsh = -0.1
  ), "'freq_thrsh' must be a numeric value between 0 and 1")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    freq_thrsh = "bananas"
  ), "'freq_thrsh' must be a numeric value between 0 and 1")
})

test_that("An error occurs if xfreq_thrsh is not a numeric between 0 and 1", {
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    freq_thrsh = 0.5,
    xfreq_thrsh = 1.1
  ), "'xfreq_thrsh' must be a numeric value between 0 and 1")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    freq_thrsh = 0.5,
    xfreq_thrsh = -0.1
  ), "'xfreq_thrsh' must be a numeric value between 0 and 1")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    freq_thrsh = 0.5,
    xfreq_thrsh = "bananas"
  ), "'xfreq_thrsh' must be a numeric value between 0 and 1")
})

test_that("An error occurs if prefix is not a character string", {
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    xfreq_thrsh = 0.2,
    prefix = 12
  ), "'prefix' must be a character string")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    xfreq_thrsh = 0.2,
    prefix = c("hello", "world")
  ), "'prefix' must be a character string")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    xfreq_thrsh = 0.2,
    prefix = FALSE
  ), "'prefix' must be a character string")
})

test_that("An error occurs if output_dir is not a character string", {
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    xfreq_thrsh = 0.2,
    output_dir = 12
  ), "'output_dir' must be a character string")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    xfreq_thrsh = 0.2,
    output_dir = c("hello", "world")
  ), "'output_dir' must be a character string")

  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    xfreq_thrsh = 0.2,
    output_dir = FALSE
  ), "'output_dir' must be a character string")
})

test_that("An error occurs if the event_dates file does not exist", {
  expect_error(seq_vars_ds(
    event_dates = "Imnothere.csv"
  ), "The file 'Imnothere.csv' does not exist")
})

test_that("An error occurs if 'parallel' is not logical", {
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    parallel = "universe"
  ), "'parallel' must be a logical input - either TRUE or FALSE")
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    parallel = c(TRUE, FALSE)
  ), "'parallel' must be a logical input - either TRUE or FALSE")
})

test_that("An error occurs if 'cores' is not a single integer", {
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    parallel = TRUE,
    cores = 1.7
  ), "'cores' argument must be a whole number")
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    parallel = TRUE,
    cores = "apple"
  ), "'cores' argument must be a whole number")
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    parallel = TRUE,
    cores = c(1, 2, 3)
  ), "'cores' argument must be a whole number")
})

test_that("The first summary functions error if dataframe is not 2 columns", {
  date_df <- event_dates_df[, -c(1, 2)]
  expect_error(
    get_date_variable_summaries(date_df),
    "The input dataframe for the pairwise summary does not have 2 columns"
  )
})

test_that("The outcome_var and date information is correctly selected", {
  expected_df <- event_dates_df[, -1]
  outcome_var_and_date_li <- get_outcome_and_date_variables(
    event_dates_df = event_dates_df,
    outcome_var = "outcome_var"
  )
  outcome_df <- outcome_var_and_date_li$df
  date_cols <- outcome_var_and_date_li$date_cols
  expect_equal(outcome_df, expected_df)
  expect_equal(date_cols, c("sympx", "procx", "drugx"))
})

test_that("The overall first summary returns the correct size dataframe", {
  summary_full <- get_overall_first_summary(
    event_dates_df = event_dates_df,
    parallel = FALSE,
    cores = 2
  )
  expect_equal(dim(summary_full), c(3, 11))
})

test_that("The overall second summary returns the correct size dataframe", {
  summary_full <- get_overall_second_summary(
    event_dates_df = event_dates_df,
    outcome_var = "outcome_var",
    parallel = F,
    cores = 2
  )
  expect_equal(dim(summary_full), c(3, 24))
})

test_that("Getting a warning if too many cores are entered", {
  # Getting the available number of cores
  available_cores <- parallel::detectCores() - 1
  warning_message <- sprintf(
    "The value entered for 'cores' was too high, changing to %d",
    available_cores
  )

  expect_warning(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    missing_values = "nil",
    parallel = TRUE,
    cores = 12345
  ), warning_message)
})

test_that("An error is raised if the thrsh values remove all the data", {
  expect_error(seq_vars_ds(
    event_dates = "event_dates.csv",
    id_column = "patient_id",
    outcome_var = "outcome_var",
    missing_values = "nil",
    freq_thrsh = 0.4,
    xfreq_thrsh = 0.39
  ), "'freq_thrsh' value of '0.4' has removed all of the data")
})













