context("Testing the var config filtering to handle capital letters")

## Loading in the required data for the tests
transformed_data <- suppressMessages(
  readr::read_csv("transformed_data.csv")
)

var_config_with_capitals <- suppressMessages(
  readr::read_csv("var_config_with_capitals.csv")
)

transformed_data_categorical <- suppressMessages(
  readr::read_csv("transformed_data_categorical.csv")
)

transformed_data_numerical <- suppressMessages(
  readr::read_csv("transformed_data_numerical.csv")
)

transformed_data_key <- suppressMessages(
  readr::read_csv("transformed_data_key.csv")
)

test_that("The correct categorical values are returned", {
  cat_variables <- get_categorical_variables(
    transformed_data,
    var_config_with_capitals
  )
  expect_equal(cat_variables, transformed_data_categorical)
})

test_that("The correct numerical values are returned", {
  num_variables <- get_numerical_variables(
    transformed_data,
    var_config_with_capitals
  )
  expect_equal(num_variables, transformed_data_numerical)
})

test_that("The correct key value is returned", {
  key_variable <- get_key_variable(
    transformed_data,
    var_config_with_capitals
  )
  expect_equal(key_variable, transformed_data_key)
})





















